"""Billing and receipt workflow for CaféSync.

This module keeps the current CSV-first architecture and uses the persisted order
and order line data as the source of truth. Bills are generated without changing
order totals or creating a competing sales record.
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path

import pandas as pd

from modules.orders import get_order_detail

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
BILLS_PATH = DATA_DIR / "bills.csv"
PAYMENTS_PATH = DATA_DIR / "payments.csv"

BILL_COLUMNS = [
    "bill_id",
    "cafe_id",
    "order_id",
    "issued_at",
    "subtotal",
    "tax_amount",
    "discount_amount",
    "total_amount",
    "amount_paid",
    "balance_due",
    "payment_status",
]

PAYMENT_COLUMNS = [
    "payment_id",
    "cafe_id",
    "bill_id",
    "payment_date",
    "amount",
    "payment_method",
    "reference",
    "notes",
]

ALLOWED_PAYMENT_METHODS = ["Cash", "UPI", "Card", "Other"]


def _ensure_data_dir():
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def _read_bills_df():
    _ensure_data_dir()
    if not BILLS_PATH.exists():
        pd.DataFrame(columns=BILL_COLUMNS).to_csv(BILLS_PATH, index=False)
        return pd.DataFrame(columns=BILL_COLUMNS)
    try:
        df = pd.read_csv(BILLS_PATH)
    except Exception:
        return pd.DataFrame(columns=BILL_COLUMNS)

    for column in BILL_COLUMNS:
        if column not in df.columns:
            df[column] = ""
    df = df.reindex(columns=BILL_COLUMNS)
    df.to_csv(BILLS_PATH, index=False)
    return df


def _read_payments_df():
    _ensure_data_dir()
    if not PAYMENTS_PATH.exists():
        pd.DataFrame(columns=PAYMENT_COLUMNS).to_csv(PAYMENTS_PATH, index=False)
        return pd.DataFrame(columns=PAYMENT_COLUMNS)
    try:
        df = pd.read_csv(PAYMENTS_PATH)
    except Exception:
        return pd.DataFrame(columns=PAYMENT_COLUMNS)

    for column in PAYMENT_COLUMNS:
        if column not in df.columns:
            df[column] = ""
    df = df.reindex(columns=PAYMENT_COLUMNS)
    df.to_csv(PAYMENTS_PATH, index=False)
    return df


def _decimal(value):
    try:
        return Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError("Invalid numeric value.")


def _currency(value):
    return float(Decimal(str(value)).quantize(Decimal("0.01")))


def _generate_bill_id():
    bills_df = _read_bills_df()
    if bills_df.empty:
        return "BIL001"
    values = []
    for value in bills_df["bill_id"].fillna("").astype(str):
        if value.startswith("BIL") and value[3:].isdigit():
            values.append(int(value[3:]))
    next_num = max(values, default=0) + 1
    return f"BIL{next_num:03d}"


def _generate_payment_id():
    payments_df = _read_payments_df()
    if payments_df.empty:
        return "PAY001"
    values = []
    for value in payments_df["payment_id"].fillna("").astype(str):
        if value.startswith("PAY") and value[3:].isdigit():
            values.append(int(value[3:]))
    next_num = max(values, default=0) + 1
    return f"PAY{next_num:03d}"


def _normalize_payment_status(amount_paid, total_amount):
    amount_paid = float(amount_paid)
    total_amount = float(total_amount)
    if total_amount <= 0:
        return "Pending"
    diff = total_amount - amount_paid
    if diff <= 0.01:
        return "Paid"
    if amount_paid > 0:
        return "Partially Paid"
    return "Pending"


def _build_bill_dict(row):
    try:
        subtotal = float(row.get("subtotal", 0) or 0)
        tax_amount = float(row.get("tax_amount", 0) or 0)
        discount_amount = float(row.get("discount_amount", 0) or 0)
        total_amount = float(row.get("total_amount", 0) or 0)
        amount_paid = float(row.get("amount_paid", 0) or 0)
        balance_due = float(row.get("balance_due", 0) or 0)
    except ValueError:
        subtotal = 0.0
        tax_amount = 0.0
        discount_amount = 0.0
        total_amount = 0.0
        amount_paid = 0.0
        balance_due = 0.0

    payment_status = str(row.get("payment_status") or _normalize_payment_status(amount_paid, total_amount)).strip()
    if not payment_status:
        payment_status = _normalize_payment_status(amount_paid, total_amount)

    return {
        "bill_id": str(row.get("bill_id") or "").strip(),
        "cafe_id": str(row.get("cafe_id") or "").strip(),
        "order_id": str(row.get("order_id") or "").strip(),
        "issued_at": str(row.get("issued_at") or "").strip(),
        "subtotal": subtotal,
        "tax_amount": tax_amount,
        "discount_amount": discount_amount,
        "total_amount": total_amount,
        "amount_paid": amount_paid,
        "balance_due": balance_due,
        "payment_status": payment_status,
    }


def _build_payment_dict(row):
    return {
        "payment_id": str(row.get("payment_id") or "").strip(),
        "cafe_id": str(row.get("cafe_id") or "").strip(),
        "bill_id": str(row.get("bill_id") or "").strip(),
        "payment_date": str(row.get("payment_date") or "").strip(),
        "amount": float(row.get("amount", 0) or 0),
        "payment_method": str(row.get("payment_method") or "").strip(),
        "reference": str(row.get("reference") or "").strip(),
        "notes": str(row.get("notes") or "").strip(),
    }


def _refresh_bill_totals(cafe_id, bill_id):
    bills_df = _read_bills_df()
    bill_mask = (bills_df["cafe_id"].astype(str) == str(cafe_id)) & (bills_df["bill_id"].astype(str) == str(bill_id))
    if not bill_mask.any():
        return None

    bill_rows = bills_df.loc[bill_mask].copy()
    total_amount = float(bill_rows["total_amount"].iloc[0] or 0)
    payments_df = _read_payments_df()
    bill_payments = payments_df[(payments_df["cafe_id"].astype(str) == str(cafe_id)) & (payments_df["bill_id"].astype(str) == str(bill_id))].copy()
    amount_paid = float(bill_payments["amount"].fillna(0).astype(float).sum()) if not bill_payments.empty else 0.0
    balance_due = max(total_amount - amount_paid, 0.0)
    payment_status = _normalize_payment_status(amount_paid, total_amount)

    bills_df.loc[bill_mask, "amount_paid"] = _currency(amount_paid)
    bills_df.loc[bill_mask, "balance_due"] = _currency(balance_due)
    bills_df.loc[bill_mask, "payment_status"] = payment_status
    bills_df.to_csv(BILLS_PATH, index=False)

    refreshed = bills_df.loc[bill_mask].iloc[0].to_dict()
    return _build_bill_dict(refreshed)


def get_bill_summary(cafe_id):
    cafe_id = str(cafe_id or "").strip()
    bills = list_bills(cafe_id)
    total_bills = len(bills)
    now = datetime.now().strftime("%Y-%m-%d")
    today_billed_sales = sum(float(row["total_amount"]) for row in bills if str(row["issued_at"]).startswith(now))
    payments_df = _read_payments_df()
    today_payments = payments_df[(payments_df["cafe_id"].astype(str) == cafe_id) & (payments_df["payment_date"].astype(str).str.startswith(now))]
    payments_received_today = float(today_payments["amount"].fillna(0).astype(float).sum()) if not today_payments.empty else 0.0
    outstanding_balance = sum(float(row["balance_due"]) for row in bills)
    return {
        "total_bills": total_bills,
        "today_billed_sales": _currency(today_billed_sales),
        "payments_received_today": _currency(payments_received_today),
        "outstanding_balance": _currency(outstanding_balance),
    }


def list_payments(cafe_id, bill_id=None):
    cafe_id = str(cafe_id or "").strip()
    payments_df = _read_payments_df()
    if payments_df.empty:
        return []
    filtered = payments_df[payments_df["cafe_id"].astype(str) == cafe_id].copy()
    if bill_id:
        filtered = filtered[filtered["bill_id"].astype(str) == str(bill_id)]
    if filtered.empty:
        return []
    filtered = filtered.sort_values(by=["payment_date"], ascending=False).reset_index(drop=True)
    return [_build_payment_dict(row.to_dict()) for _, row in filtered.iterrows()]


def list_bills(cafe_id, search="", payment_status="All", date_filter="All", payment_method="All"):
    cafe_id = str(cafe_id or "").strip()
    bills_df = _read_bills_df()
    if bills_df.empty:
        return []

    filtered = bills_df[bills_df["cafe_id"].astype(str) == cafe_id].copy()
    if filtered.empty:
        return []

    if search:
        term = str(search).strip().lower()
        filtered = filtered[
            filtered["bill_id"].fillna("").astype(str).str.lower().str.contains(term, na=False)
            | filtered["order_id"].fillna("").astype(str).str.lower().str.contains(term, na=False)
        ]

    if payment_status != "All":
        filtered = filtered[filtered["payment_status"].fillna("").astype(str).str.lower() == str(payment_status).strip().lower()]

    if date_filter == "Today":
        today = datetime.now().strftime("%Y-%m-%d")
        filtered = filtered[filtered["issued_at"].astype(str).str.startswith(today)]
    elif date_filter == "7 Days":
        filtered = filtered[filtered["issued_at"].astype(str).str.len() > 0]

    if payment_method != "All":
        payments_df = _read_payments_df()
        related = payments_df[(payments_df["cafe_id"].astype(str) == cafe_id) & (payments_df["payment_method"].astype(str).str.lower() == str(payment_method).strip().lower())]
        bill_ids = set(related["bill_id"].astype(str))
        filtered = filtered[filtered["bill_id"].astype(str).isin(bill_ids)]

    filtered = filtered.sort_values(by=["issued_at"], ascending=False).reset_index(drop=True)
    return [_build_bill_dict(row.to_dict()) for _, row in filtered.iterrows()]


def get_bill_detail(cafe_id, bill_id):
    cafe_id = str(cafe_id or "").strip()
    bill_id = str(bill_id or "").strip()
    bills_df = _read_bills_df()
    bill_row = bills_df[(bills_df["cafe_id"].astype(str) == cafe_id) & (bills_df["bill_id"].astype(str) == bill_id)]
    if bill_row.empty:
        return {"success": False, "message": "Bill not found."}

    bill = _build_bill_dict(bill_row.iloc[0].to_dict())
    payments = list_payments(cafe_id, bill_id)
    return {"success": True, "bill": bill, "payments": payments}


def list_eligible_orders(cafe_id):
    cafe_id = str(cafe_id or "").strip()
    from modules.orders import list_orders

    orders = list_orders(cafe_id)
    bills_df = _read_bills_df()
    billed_order_ids = set()
    if not bills_df.empty:
        billed_order_ids = set(str(value) for value in bills_df[(bills_df["cafe_id"].astype(str) == cafe_id)]["order_id"].fillna("").astype(str))

    eligible = []
    for order in orders:
        if str(order.get("order_status", "")).strip() == "Cancelled":
            continue
        if str(order.get("order_id", "")).strip() in billed_order_ids:
            continue
        eligible.append(order)
    return eligible


def create_bill_from_order(cafe_id, order_id):
    cafe_id = str(cafe_id or "").strip()
    order_id = str(order_id or "").strip()
    if not cafe_id:
        return {"success": False, "message": "No active café is selected."}

    detail = get_order_detail(cafe_id, order_id)
    if not detail["success"]:
        return {"success": False, "message": "Order not found for this café."}

    order = detail["order"]
    if str(order.get("order_status", "")).strip() == "Cancelled":
        return {"success": False, "message": "Cancelled orders cannot be billed."}

    existing_bills = _read_bills_df()
    if not existing_bills.empty:
        matches = existing_bills[(existing_bills["cafe_id"].astype(str) == cafe_id) & (existing_bills["order_id"].astype(str) == order_id)]
        if not matches.empty:
            bill = _build_bill_dict(matches.iloc[0].to_dict())
            return {"success": False, "message": "A bill already exists for this order.", "bill": bill}

    order_total = float(order.get("total_amount", 0) or 0)
    subtotal = float(order.get("subtotal", 0) or 0)
    tax_amount = float(order.get("tax_amount", 0) or 0)
    discount_amount = float(order.get("discount_amount", 0) or 0)
    recalculated_total = subtotal + tax_amount - discount_amount
    if abs(recalculated_total - order_total) > 0.01:
        return {"success": False, "message": "The persisted order total does not match the billable total and cannot be billed safely."}

    bill_id = _generate_bill_id()
    issued_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    bill_row = {
        "bill_id": bill_id,
        "cafe_id": cafe_id,
        "order_id": order_id,
        "issued_at": issued_at,
        "subtotal": _currency(subtotal),
        "tax_amount": _currency(tax_amount),
        "discount_amount": _currency(discount_amount),
        "total_amount": _currency(order_total),
        "amount_paid": 0.0,
        "balance_due": _currency(order_total),
        "payment_status": "Pending",
    }

    bills_df = _read_bills_df()
    bills_df = pd.concat([bills_df.reindex(columns=BILL_COLUMNS), pd.DataFrame([bill_row], columns=BILL_COLUMNS)], ignore_index=True, sort=False)
    bills_df.to_csv(BILLS_PATH, index=False)
    return {"success": True, "message": "Bill generated successfully.", "bill": _build_bill_dict(bill_row)}


def record_payment(cafe_id, bill_id, amount, payment_method, reference="", notes=""):
    cafe_id = str(cafe_id or "").strip()
    bill_id = str(bill_id or "").strip()
    if not cafe_id:
        return {"success": False, "message": "No active café is selected."}

    try:
        payment_amount = float(amount)
    except (TypeError, ValueError):
        return {"success": False, "message": "Payment amount must be a valid number."}

    if payment_amount <= 0:
        return {"success": False, "message": "Payment amount must be greater than zero."}

    payment_method = str(payment_method or "").strip()
    if payment_method not in ALLOWED_PAYMENT_METHODS:
        return {"success": False, "message": "Unsupported payment method."}

    bills_df = _read_bills_df()
    bill_mask = (bills_df["cafe_id"].astype(str) == cafe_id) & (bills_df["bill_id"].astype(str) == bill_id)
    if not bill_mask.any():
        return {"success": False, "message": "Bill not found."}

    bill_row = bills_df.loc[bill_mask].iloc[0].to_dict()
    bill = _build_bill_dict(bill_row)
    current_amount_paid = float(bill["amount_paid"])
    total_amount = float(bill["total_amount"])
    outstanding = max(total_amount - current_amount_paid, 0.0)
    if payment_amount > outstanding + 0.01:
        return {"success": False, "message": "Payment exceeds the remaining balance for this bill."}

    payment_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    payment_id = _generate_payment_id()
    payment_row = {
        "payment_id": payment_id,
        "cafe_id": cafe_id,
        "bill_id": bill_id,
        "payment_date": payment_date,
        "amount": _currency(payment_amount),
        "payment_method": payment_method,
        "reference": str(reference or "").strip(),
        "notes": str(notes or "").strip(),
    }

    payments_df = _read_payments_df()
    payments_df = pd.concat([payments_df.reindex(columns=PAYMENT_COLUMNS), pd.DataFrame([payment_row], columns=PAYMENT_COLUMNS)], ignore_index=True, sort=False)
    payments_df.to_csv(PAYMENTS_PATH, index=False)

    refreshed = _refresh_bill_totals(cafe_id, bill_id)
    if refreshed is None:
        return {"success": False, "message": "Payment saved but the bill totals could not be refreshed."}

    bill_detail = get_bill_detail(cafe_id, bill_id)
    payment = _build_payment_dict(payment_row)
    return {"success": True, "message": "Payment recorded successfully.", "payment": payment, "bill": bill_detail["bill"]}


def export_receipt_pdf(cafe_id, bill_id, output_path=None):
    cafe_id = str(cafe_id or "").strip()
    bill_id = str(bill_id or "").strip()
    detail = get_bill_detail(cafe_id, bill_id)
    if not detail["success"]:
        return {"success": False, "message": detail["message"]}

    bill = detail["bill"]
    order_detail = get_order_detail(cafe_id, bill["order_id"])
    if not order_detail["success"]:
        return {"success": False, "message": "The original order could not be loaded for this receipt."}

    if output_path is None:
        base_dir = DATA_DIR / "receipts"
        base_dir.mkdir(parents=True, exist_ok=True)
        output_path = base_dir / f"{bill_id}.pdf"
    else:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

    cafe_name = "CaféSync Café"
    cafe_address = "Address unavailable"
    cafe_phone = "Phone unavailable"
    try:
        from modules.cafe_manager import get_cafes_for_owner
        from modules.session import session

        cafes = get_cafes_for_owner(session.current_user_id) if session.current_user_id else None
        if cafes is not None and not cafes.empty:
            cafe_row = cafes[cafes["cafe_id"].astype(str) == cafe_id]
            if not cafe_row.empty:
                cafe_name = str(cafe_row.iloc[0].get("cafe_name") or cafe_name)
                cafe_address = str(cafe_row.iloc[0].get("location") or cafe_address)
                cafe_phone = str(cafe_row.iloc[0].get("phone") or cafe_phone)
    except Exception:
        pass

    payment_lines = []
    for payment in detail["payments"]:
        payment_lines.append(f"- {payment['payment_date']} | {payment['payment_method']} | ₹ {payment['amount']:.2f} | {payment['reference'] or 'No reference'}")

    lines = [
        "CaféSync Receipt",
        f"Café: {cafe_name}",
        f"Address: {cafe_address}",
        f"Phone: {cafe_phone}",
        f"Bill ID: {bill['bill_id']}",
        f"Order ID: {bill['order_id']}",
        f"Issued: {bill['issued_at']}",
        "",
        "Items:",
    ]

    for item in order_detail["line_items"]:
        lines.append(f"- {item['item_name_snapshot']} x{item['quantity']} @ ₹ {item['unit_price_snapshot']:.2f} = ₹ {item['line_total']:.2f}")

    lines.extend([
        "",
        f"Subtotal: ₹ {bill['subtotal']:.2f}",
        f"Tax: ₹ {bill['tax_amount']:.2f}",
        f"Discount: ₹ {bill['discount_amount']:.2f}",
        f"Grand Total: ₹ {bill['total_amount']:.2f}",
        f"Amount Paid: ₹ {bill['amount_paid']:.2f}",
        f"Balance Due: ₹ {bill['balance_due']:.2f}",
        f"Payment Status: {bill['payment_status']}",
        "",
        "Payments:",
    ])
    if not payment_lines:
        lines.append("- No payments recorded yet.")
    else:
        lines.extend(payment_lines)

    _write_simple_pdf(output_path, lines)
    return {"success": True, "message": "Receipt exported successfully.", "path": str(output_path)}


def _escape_pdf_text(value):
    text = str(value or "")
    return text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def _write_simple_pdf(path, lines):
    page_width = 595
    page_height = 842
    content_lines = []
    y_position = 790
    for line in lines:
        content_lines.append(f"BT /F1 11 Tf 72 {y_position} Td ({_escape_pdf_text(line)}) Tj ET")
        y_position -= 18

    content = "\n".join(content_lines).encode("latin-1", errors="replace")
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {page_width} {page_height}] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>".encode("latin-1"),
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        f"<< /Length {len(content)} >>\nstream\n".encode("latin-1") + content + b"\nendstream",
    ]

    pdf = b"%PDF-1.4\n"
    offsets = [0]
    for index, obj in enumerate(objects, start=1):
        offsets.append(len(pdf))
        pdf += f"{index} 0 obj\n".encode("latin-1") + obj + b"\nendobj\n"

    xref_start = len(pdf)
    pdf += f"xref\n0 {len(objects) + 1}\n".encode("latin-1")
    pdf += b"0000000000 65535 f \n"
    for offset in offsets[1:]:
        pdf += f"{offset:010d} 00000 n \n".encode("latin-1")
    pdf += f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\nstartxref\n{xref_start}\n%%EOF\n".encode("latin-1")
    path.write_bytes(pdf)


__all__ = [
    "ALLOWED_PAYMENT_METHODS",
    "create_bill_from_order",
    "export_receipt_pdf",
    "get_bill_detail",
    "get_bill_summary",
    "list_bills",
    "list_eligible_orders",
    "list_payments",
    "record_payment",
]
