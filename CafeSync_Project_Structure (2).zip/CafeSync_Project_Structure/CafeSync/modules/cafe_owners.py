"""Platform-level owner management for CaféSync.

This module keeps ownership, status, and café relationship logic separate from
view code and uses the existing CSV data model instead of creating duplicate data.
"""

from __future__ import annotations

import re
from pathlib import Path

import pandas as pd

from modules.platform_activity import record_platform_activity

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
USER_FILE = DATA_DIR / "users.csv"
CAFE_FILE = DATA_DIR / "cafes.csv"


def _read_users():
    if not USER_FILE.exists():
        return pd.DataFrame(columns=[
            "user_id",
            "name",
            "email",
            "phone",
            "password",
            "role",
            "status",
            "created_at",
        ])
    try:
        return pd.read_csv(USER_FILE)
    except Exception:
        return pd.DataFrame(columns=[
            "user_id",
            "name",
            "email",
            "phone",
            "password",
            "role",
            "status",
            "created_at",
        ])


def _read_cafes():
    if not CAFE_FILE.exists():
        return pd.DataFrame(columns=[
            "cafe_id",
            "owner_id",
            "cafe_name",
            "location",
            "phone",
            "status",
            "created_at",
            "cafe_type",
            "opening_date",
            "opening_time",
            "closing_time",
            "setup_completed",
            "setup_progress",
        ])
    try:
        return pd.read_csv(CAFE_FILE)
    except Exception:
        return pd.DataFrame(columns=[
            "cafe_id",
            "owner_id",
            "cafe_name",
            "location",
            "phone",
            "status",
            "created_at",
            "cafe_type",
            "opening_date",
            "opening_time",
            "closing_time",
            "setup_completed",
            "setup_progress",
        ])


def _normalize_status(value):
    status = str(value or "Inactive").strip()
    return "Active" if status.lower() == "active" else "Inactive"


def _parse_date(value):
    if pd.isna(value) or value == "":
        return ""
    text = str(value).strip()
    try:
        return pd.to_datetime(text, errors="raise").strftime("%d %b %Y")
    except Exception:
        return text


def _owner_to_row(user_row, cafes):
    owner_id = str(user_row.get("user_id", "")).strip()
    cafe_rows = cafes[cafes["owner_id"].astype(str) == owner_id]
    cafe = cafe_rows.iloc[0].to_dict() if not cafe_rows.empty else {}
    cafe_id = str(cafe.get("cafe_id", "")).strip() if cafe else ""
    cafe_name = str(cafe.get("cafe_name", "")).strip() if cafe else "No café assigned"
    cafe_status = _normalize_status(cafe.get("status", "Inactive")) if cafe else "Inactive"
    setup_progress = 0
    if cafe and "setup_progress" in cafe:
        try:
            setup_progress = int(float(str(cafe.get("setup_progress", "0") or "0")))
        except Exception:
            setup_progress = 0
    return {
        "user_id": owner_id,
        "name": str(user_row.get("name", "")).strip() or "Unknown Owner",
        "email": str(user_row.get("email", "")).strip(),
        "phone": str(user_row.get("phone", "")).strip(),
        "role": str(user_row.get("role", "cafe_owner")).strip() or "cafe_owner",
        "status": _normalize_status(user_row.get("status", "Inactive")),
        "created_at": _parse_date(user_row.get("created_at", "")),
        "cafe_id": cafe_id,
        "cafe_name": cafe_name,
        "cafe_status": cafe_status,
        "setup_progress": setup_progress,
        "has_active_cafe": cafe_status == "Active",
    }


def get_owner_summary():
    users = _read_users()
    cafes = _read_cafes()
    owner_rows = [
        _owner_to_row(row, cafes)
        for _, row in users[users["role"].astype(str).str.lower() == "cafe_owner"].iterrows()
    ]
    total = len(owner_rows)
    active = sum(1 for row in owner_rows if row["status"] == "Active")
    inactive = total - active
    active_cafes = sum(1 for row in owner_rows if row["has_active_cafe"])
    return {
        "total_owners": total,
        "active_owners": active,
        "inactive_owners": inactive,
        "owners_with_active_cafe": active_cafes,
    }


def list_owner_accounts(search="", owner_status="All", cafe_status="All"):
    users = _read_users()
    if users.empty:
        return []

    cafes = _read_cafes()
    rows = [
        _owner_to_row(row, cafes)
        for _, row in users[users["role"].astype(str).str.lower() == "cafe_owner"].iterrows()
    ]

    if search:
        query = search.lower()
        rows = [
            row for row in rows
            if query in row["name"].lower()
            or query in row["email"].lower()
            or query in row["phone"].lower()
            or query in row["user_id"].lower()
            or query in row["cafe_name"].lower()
            or query in row["cafe_id"].lower()
        ]

    if owner_status != "All":
        rows = [row for row in rows if row["status"] == owner_status]

    if cafe_status != "All":
        if cafe_status == "Active Café":
            rows = [row for row in rows if row["cafe_status"] == "Active"]
        else:
            rows = [row for row in rows if row["cafe_status"] == "Inactive"]

    rows.sort(key=lambda row: row["name"].lower())
    return rows


def get_owner_detail(user_id):
    users = _read_users()
    if users.empty:
        return None
    match = users[users["user_id"].astype(str) == str(user_id)]
    if match.empty:
        return None

    cafes = _read_cafes()
    row = _owner_to_row(match.iloc[0].to_dict(), cafes)
    cafe = cafes[cafes["owner_id"].astype(str) == str(user_id)]
    linked_cafe = cafe.iloc[0].to_dict() if not cafe.empty else {}
    setup_progress = int(float(str(linked_cafe.get("setup_progress", "0") or "0"))) if linked_cafe else 0
    return {
        "user_id": row["user_id"],
        "name": row["name"],
        "email": row["email"],
        "phone": row["phone"],
        "role": row["role"],
        "status": row["status"],
        "created_at": row["created_at"],
        "cafe_id": row["cafe_id"],
        "cafe_name": row["cafe_name"],
        "cafe_status": row["cafe_status"],
        "setup_progress": setup_progress,
        "owner_access_status": "Active" if row["status"] == "Active" else "Inactive",
        "location": str(linked_cafe.get("location", "")).strip() if linked_cafe else "",
        "password_hidden": True,
    }


def get_owner_account_snapshot(user_id, cafe_id=None):
    """Return the authenticated owner and their linked café in a safe UI-ready shape."""
    users = _read_users()
    if users.empty:
        return None

    match = users[users["user_id"].astype(str) == str(user_id)]
    if match.empty:
        return None

    user_row = match.iloc[0].to_dict()
    cafes = _read_cafes()
    cafe_match = cafes[cafes["owner_id"].astype(str) == str(user_id)].copy()
    if cafe_id is not None:
        cafe_match = cafe_match[cafe_match["cafe_id"].astype(str) == str(cafe_id)]
    linked_cafe = cafe_match.iloc[0].to_dict() if not cafe_match.empty else {}

    if cafe_id is not None and not linked_cafe:
        return None

    return {
        "user_id": str(user_row.get("user_id", "")).strip(),
        "owner_name": str(user_row.get("name", "")).strip(),
        "email": str(user_row.get("email", "")).strip(),
        "phone": str(user_row.get("phone", "")).strip(),
        "role": str(user_row.get("role", "cafe_owner")).strip() or "cafe_owner",
        "status": _normalize_status(user_row.get("status", "Inactive")),
        "created_at": str(user_row.get("created_at", "")).strip(),
        "cafe_id": str(linked_cafe.get("cafe_id", "")).strip(),
        "cafe_name": str(linked_cafe.get("cafe_name", "")).strip(),
        "location": str(linked_cafe.get("location", "")).strip(),
        "cafe_phone": str(linked_cafe.get("phone", "")).strip(),
        "cafe_status": _normalize_status(linked_cafe.get("status", "Inactive")),
        "setup_completed": bool(str(linked_cafe.get("setup_completed", "False")).strip().lower() in {"true", "1", "yes"}),
        "setup_progress": int(float(str(linked_cafe.get("setup_progress", "0") or "0"))) if str(linked_cafe.get("setup_progress", "0") or "0").strip() else 0,
        "owner_status": _normalize_status(user_row.get("status", "Inactive")),
    }


def update_owner_profile(user_id, full_name=None, email=None, phone=None, password=None, current_password=None, role=None):
    """Persist safe owner profile updates without allowing role or ownership changes."""
    if user_id is None or str(user_id).strip() == "":
        return {"success": False, "message": "Owner account is missing."}

    users = _read_users()
    if users.empty:
        return {"success": False, "message": "Owner account was not found."}

    mask = users["user_id"].astype(str) == str(user_id)
    if not mask.any():
        return {"success": False, "message": "Owner account was not found."}

    user_row = users.loc[mask].iloc[0].to_dict()
    new_name = str(full_name if full_name is not None else user_row.get("name", "")).strip()
    new_email = str(email if email is not None else user_row.get("email", "")).strip()
    new_phone = str(phone if phone is not None else user_row.get("phone", "")).strip()

    if not new_name:
        return {"success": False, "message": "Full name is required."}
    if not new_email:
        return {"success": False, "message": "Login email is required."}
    if not new_phone:
        return {"success": False, "message": "Phone number is required."}

    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", new_email):
        return {"success": False, "message": "Please enter a valid email address."}

    digits = re.sub(r"\D", "", new_phone)
    if len(digits) < 10:
        return {"success": False, "message": "Please enter a valid phone number."}

    duplicate = users[(users["email"].astype(str).str.lower() == new_email.lower()) & (users["user_id"].astype(str) != str(user_id))]
    if not duplicate.empty:
        return {"success": False, "message": "This login email is already in use by another account."}

    if role is not None and str(role).strip() and str(role).strip().lower() != "cafe_owner":
        return {"success": False, "message": "Role changes are not allowed from this profile page."}

    if password is not None:
        password_text = str(password).strip()
        if not password_text:
            return {"success": False, "message": "Password cannot be blank."}
        if len(password_text) < 8:
            return {"success": False, "message": "New password must be at least 8 characters long."}
        current_value = str(current_password if current_password is not None else "").strip()
        if str(user_row.get("password", "")) != current_value:
            return {"success": False, "message": "Current password is incorrect."}
        users.loc[mask, "password"] = password_text

    users.loc[mask, "name"] = new_name
    users.loc[mask, "email"] = new_email
    users.loc[mask, "phone"] = new_phone
    users.to_csv(USER_FILE, index=False)
    return {"success": True, "message": "Profile updated successfully."}


def update_cafe_profile(user_id, cafe_id, cafe_name=None, location=None, phone=None):
    """Update only the authenticated owner's linked café and leave all other café records untouched."""
    if user_id is None or str(user_id).strip() == "":
        return {"success": False, "message": "Owner account is missing."}
    if cafe_id is None or str(cafe_id).strip() == "":
        return {"success": False, "message": "No café is selected."}

    cafes = _read_cafes()
    if cafes.empty:
        return {"success": False, "message": "Café record could not be found."}

    mask = (cafes["cafe_id"].astype(str) == str(cafe_id)) & (cafes["owner_id"].astype(str) == str(user_id))
    if not mask.any():
        return {"success": False, "message": "You can only edit your own café details."}

    new_name = str(cafe_name if cafe_name is not None else cafes.loc[mask, "cafe_name"].iloc[0]).strip()
    new_location = str(location if location is not None else cafes.loc[mask, "location"].iloc[0]).strip()
    new_phone = str(phone if phone is not None else cafes.loc[mask, "phone"].iloc[0]).strip()

    if not new_name:
        return {"success": False, "message": "Café name is required."}
    if not new_location:
        return {"success": False, "message": "Location is required."}
    if not new_phone:
        return {"success": False, "message": "Café phone is required."}

    digits = re.sub(r"\D", "", new_phone)
    if len(digits) < 10:
        return {"success": False, "message": "Please enter a valid café phone number."}

    cafes.loc[mask, "cafe_name"] = new_name
    cafes.loc[mask, "location"] = new_location
    cafes.loc[mask, "phone"] = new_phone
    cafes.to_csv(CAFE_FILE, index=False)
    return {"success": True, "message": "Café details updated successfully."}


def update_owner_status(user_id, status):
    users = _read_users()
    if users.empty:
        return False
    mask = users["user_id"].astype(str) == str(user_id)
    if not mask.any():
        return False
    users.loc[mask, "status"] = "Active" if str(status).strip().lower() == "active" else "Inactive"
    users.to_csv(USER_FILE, index=False)
    return True


def deactivate_owner_account(user_id, actor_id=None, actor_name="Platform Admin", actor_role="platform_admin"):
    if not update_owner_status(user_id, "Inactive"):
        return {"success": False, "message": "Unable to deactivate this owner account."}

    detail = get_owner_detail(user_id)
    target_name = detail["name"] if detail else "Unknown Owner"
    record_platform_activity(
        actor_id=actor_id,
        actor_name=actor_name,
        actor_role=actor_role,
        action="DEACTIVATE_OWNER",
        target_type="OWNER",
        target_id=str(user_id),
        target_name=target_name,
        status="SUCCESS",
        details="Owner account deactivated by Platform Admin.",
    )
    return {"success": True, "message": "Owner account deactivated successfully."}


def reactivate_owner_account(user_id, actor_id=None, actor_name="Platform Admin", actor_role="platform_admin"):
    if not update_owner_status(user_id, "Active"):
        return {"success": False, "message": "Unable to reactivate this owner account."}

    detail = get_owner_detail(user_id)
    target_name = detail["name"] if detail else "Unknown Owner"
    record_platform_activity(
        actor_id=actor_id,
        actor_name=actor_name,
        actor_role=actor_role,
        action="REACTIVATE_OWNER",
        target_type="OWNER",
        target_id=str(user_id),
        target_name=target_name,
        status="SUCCESS",
        details="Owner account reactivated by Platform Admin.",
    )
    return {"success": True, "message": "Owner account reactivated successfully."}


def can_access_cafe_owners(role):
    return str(role or "").strip().lower() == "platform_admin"
