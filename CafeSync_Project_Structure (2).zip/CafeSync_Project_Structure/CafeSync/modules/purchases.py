"""Purchases and goods-receipt management for CaféSync."""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path

import pandas as pd

from modules.inventory import get_ingredient_by_id, list_ingredients, record_stock_movement
from modules.suppliers import get_supplier_by_id

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
PURCHASES_PATH = DATA_DIR / "purchases.csv"
PURCHASE_ITEMS_PATH = DATA_DIR / "purchase_items.csv"

PURCHASE_COLUMNS = [
    "purchase_id",
    "cafe_id",
    "supplier_id",
    "created_at",
    "expected_date",
    "status",
    "subtotal",
    "notes",
    "created_by",
    "updated_at",
]

PURCHASE_ITEM_COLUMNS = [
    "purchase_item_id",
    "cafe_id",
    "purchase_id",
    "ingredient_id",
    "ingredient_name",
    "ordered_quantity",
    "received_quantity",
    "unit",
    "unit_cost",
    "line_total",
    "created_at",
    "updated_at",
]

VALID_STATUSES = ["Draft", "Ordered", "Partially Received", "Received", "Cancelled"]


def _ensure_data_dir():
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def _atomic_write(frame, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temp_path, index=False)
    temp_path.replace(path)


def _decimal(value):
    if value is None or value == "":
        raise ValueError("Value missing")
    try:
        return Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError("Invalid decimal")


def _canonical_unit(value):
    unit = str(value or "").strip().lower()
    aliases = {
        "g": "g",
        "kg": "kg",
        "gram": "g",
        "grams": "g",
        "kilogram": "kg",
        "kilograms": "kg",
        "ml": "ml",
        "millilitre": "ml",
        "milliliter": "ml",
        "litre": "litre",
        "liter": "litre",
        "litres": "litre",
        "liters": "litre",
        "pcs": "pcs",
        "piece": "pcs",
        "pieces": "pcs",
        "pc": "pcs",
    }
    canonical = aliases.get(unit)
    if canonical is None:
        raise ValueError(f"Unsupported unit '{value}'.")
    return canonical


def _convert_quantity(quantity, from_unit, to_unit):
    from_unit = _canonical_unit(from_unit)
    to_unit = _canonical_unit(to_unit)
    if from_unit == to_unit:
        return Decimal(str(quantity))
    mapping = {
        ("kg", "g"): Decimal("1000"),
        ("g", "kg"): Decimal("0.001"),
        ("litre", "ml"): Decimal("1000"),
        ("ml", "litre"): Decimal("0.001"),
    }
    factor = mapping.get((from_unit, to_unit))
    if factor is None:
        raise ValueError(f"Incompatible units: {from_unit} and {to_unit}.")
    return Decimal(str(quantity)) * factor


def _read_purchases_df():
    _ensure_data_dir()
    if not PURCHASES_PATH.exists():
        empty = pd.DataFrame(columns=PURCHASE_COLUMNS)
        _atomic_write(empty, PURCHASES_PATH)
        return empty
    try:
        df = pd.read_csv(PURCHASES_PATH)
    except Exception:
        return pd.DataFrame(columns=PURCHASE_COLUMNS)
    for column in PURCHASE_COLUMNS:
        if column not in df.columns:
            df[column] = ""
    df = df.reindex(columns=PURCHASE_COLUMNS)
    _atomic_write(df, PURCHASES_PATH)
    return df


def _read_purchase_items_df():
    _ensure_data_dir()
    if not PURCHASE_ITEMS_PATH.exists():
        empty = pd.DataFrame(columns=PURCHASE_ITEM_COLUMNS)
        _atomic_write(empty, PURCHASE_ITEMS_PATH)
        return empty
    try:
        df = pd.read_csv(PURCHASE_ITEMS_PATH)
    except Exception:
        return pd.DataFrame(columns=PURCHASE_ITEM_COLUMNS)
    for column in PURCHASE_ITEM_COLUMNS:
        if column not in df.columns:
            df[column] = ""
    df = df.reindex(columns=PURCHASE_ITEM_COLUMNS)
    _atomic_write(df, PURCHASE_ITEMS_PATH)
    return df


def _generate_purchase_id():
    df = _read_purchases_df()
    if df.empty:
        return "PO001"
    values = []
    for value in df["purchase_id"].fillna("").astype(str):
        if value.startswith("PO") and value[2:].isdigit():
            values.append(int(value[2:]))
    return f"PO{max(values, default=0)+1:03d}"


def _generate_purchase_item_id():
    df = _read_purchase_items_df()
    if df.empty:
        return "PI001"
    values = []
    for value in df["purchase_item_id"].fillna("").astype(str):
        if value.startswith("PI") and value[2:].isdigit():
            values.append(int(value[2:]))
    return f"PI{max(values, default=0)+1:03d}"


def _normalize_purchase_row(row):
    return {
        "purchase_id": str(row.get("purchase_id") or "").strip(),
        "cafe_id": str(row.get("cafe_id") or "").strip(),
        "supplier_id": str(row.get("supplier_id") or "").strip(),
        "created_at": str(row.get("created_at") or "").strip(),
        "expected_date": str(row.get("expected_date") or "").strip(),
        "status": str(row.get("status") or "Draft").strip(),
        "subtotal": float(row.get("subtotal") or 0),
        "notes": str(row.get("notes") or "").strip(),
        "created_by": str(row.get("created_by") or "system").strip(),
        "updated_at": str(row.get("updated_at") or "").strip(),
    }


def _normalize_purchase_item_row(row):
    return {
        "purchase_item_id": str(row.get("purchase_item_id") or "").strip(),
        "cafe_id": str(row.get("cafe_id") or "").strip(),
        "purchase_id": str(row.get("purchase_id") or "").strip(),
        "ingredient_id": str(row.get("ingredient_id") or "").strip(),
        "ingredient_name": str(row.get("ingredient_name") or "").strip(),
        "ordered_quantity": float(row.get("ordered_quantity") or 0),
        "received_quantity": float(row.get("received_quantity") or 0),
        "unit": str(row.get("unit") or "").strip(),
        "unit_cost": float(row.get("unit_cost") or 0),
        "line_total": float(row.get("line_total") or 0),
        "created_at": str(row.get("created_at") or "").strip(),
        "updated_at": str(row.get("updated_at") or "").strip(),
    }


def _status_transition_allowed(current_status, next_status):
    current_status = str(current_status or "Draft").strip()
    next_status = str(next_status or "Draft").strip()
    if current_status == next_status:
        return True
    allowed = {
        "Draft": {"Ordered", "Cancelled"},
        "Ordered": {"Partially Received", "Received", "Cancelled"},
        "Partially Received": {"Received"},
        "Received": set(),
        "Cancelled": set(),
    }
    return next_status in allowed.get(current_status, set())


def _get_purchase_items(cafe_id, purchase_id):
    df = _read_purchase_items_df()
    if df.empty:
        return []
    filtered = df[(df["cafe_id"].astype(str) == str(cafe_id)) & (df["purchase_id"].astype(str) == str(purchase_id))].copy()
    return [_normalize_purchase_item_row(row.to_dict()) for _, row in filtered.sort_values(by=["ingredient_name", "purchase_item_id"], kind="mergesort").iterrows()]


def list_purchases(cafe_id, search="", status="All"):
    cafe_id = str(cafe_id or "").strip()
    df = _read_purchases_df()
    if df.empty:
        return []
    filtered = df[df["cafe_id"].astype(str) == cafe_id].copy()
    if filtered.empty:
        return []
    if search:
        term = str(search).strip().lower()
        filtered = filtered[
            filtered["purchase_id"].fillna("").astype(str).str.lower().str.contains(term, na=False)
            | filtered["notes"].fillna("").astype(str).str.lower().str.contains(term, na=False)
        ]
    if status != "All":
        filtered = filtered[filtered["status"].astype(str).str.lower() == str(status).lower()]
    results = []
    for _, row in filtered.sort_values(by=["created_at", "purchase_id"], ascending=[False, False], kind="mergesort").iterrows():
        purchase = _normalize_purchase_row(row.to_dict())
        purchase["items"] = _get_purchase_items(cafe_id, purchase["purchase_id"])
        results.append(purchase)
    return results


def get_purchase_by_id(cafe_id, purchase_id):
    cafe_id = str(cafe_id or "").strip()
    purchase_id = str(purchase_id or "").strip()
    df = _read_purchases_df()
    if df.empty:
        return None
    match = df[(df["cafe_id"].astype(str) == cafe_id) & (df["purchase_id"].astype(str) == purchase_id)]
    if match.empty:
        return None
    purchase = _normalize_purchase_row(match.iloc[0].to_dict())
    purchase["items"] = _get_purchase_items(cafe_id, purchase_id)
    return purchase


def create_purchase(cafe_id, supplier_id, expected_date="", items=None, notes="", created_by="system", status="Draft"):
    cafe_id = str(cafe_id or "").strip()
    supplier_id = str(supplier_id or "").strip()
    if not cafe_id:
        return {"success": False, "message": "No active café is selected."}
    if not supplier_id:
        return {"success": False, "message": "Supplier is required."}
    supplier = get_supplier_by_id(cafe_id, supplier_id)
    if supplier is None or not supplier.get("is_active"):
        return {"success": False, "message": "Supplier not found or inactive for this café."}
    status = str(status or "Draft").strip()
    if status not in VALID_STATUSES:
        status = "Draft"

    items = items or []
    if not items:
        return {"success": False, "message": "At least one purchase line is required."}

    purchase_id = _generate_purchase_id()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    purchase_df = _read_purchases_df()
    subtotal = Decimal("0")
    purchase_items_df = _read_purchase_items_df()

    line_rows = []
    for entry in items:
        if not isinstance(entry, dict):
            return {"success": False, "message": "Invalid purchase line item."}
        ingredient_name = str(entry.get("ingredient_name") or entry.get("name") or "").strip()
        ingredient_id = str(entry.get("ingredient_id") or "").strip()
        ingredient = None
        if ingredient_id:
            for candidate in list_ingredients(cafe_id):
                if candidate["ingredient_id"] == ingredient_id:
                    ingredient = candidate
                    break
        else:
            for candidate in list_ingredients(cafe_id):
                if candidate["name"].lower() == ingredient_name.lower():
                    ingredient = candidate
                    break
        if ingredient is None:
            return {"success": False, "message": f"Ingredient '{ingredient_name or ingredient_id}' not found for this café."}
        ordered_quantity = entry.get("ordered_quantity")
        try:
            ordered = _decimal(ordered_quantity)
        except ValueError:
            return {"success": False, "message": f"Ordered quantity for {ingredient['name']} must be a positive decimal."}
        if ordered <= 0:
            return {"success": False, "message": f"Ordered quantity for {ingredient['name']} must be greater than zero."}
        unit = str(entry.get("unit") or ingredient["unit"]).strip() or ingredient["unit"]
        try:
            unit_value = _canonical_unit(unit)
            _convert_quantity(ordered, unit_value, ingredient["unit"])
        except ValueError:
            return {"success": False, "message": f"Unit '{unit}' is incompatible with ingredient '{ingredient['name']}' ({ingredient['unit']})."}
        raw_cost = entry.get("unit_cost")
        try:
            unit_cost = _decimal(raw_cost)
        except ValueError:
            return {"success": False, "message": f"Unit cost for {ingredient['name']} must be a valid non-negative number."}
        if unit_cost < 0:
            return {"success": False, "message": f"Unit cost for {ingredient['name']} cannot be negative."}
        line_total = ordered * unit_cost
        subtotal += line_total
        line_rows.append({
            "purchase_item_id": _generate_purchase_item_id(),
            "cafe_id": cafe_id,
            "purchase_id": purchase_id,
            "ingredient_id": ingredient["ingredient_id"],
            "ingredient_name": ingredient["name"],
            "ordered_quantity": float(ordered),
            "received_quantity": 0.0,
            "unit": unit_value,
            "unit_cost": float(unit_cost),
            "line_total": float(line_total),
            "created_at": now,
            "updated_at": now,
        })

    purchase_row = {
        "purchase_id": purchase_id,
        "cafe_id": cafe_id,
        "supplier_id": supplier_id,
        "created_at": now,
        "expected_date": str(expected_date or "").strip(),
        "status": status if status in VALID_STATUSES else "Draft",
        "subtotal": float(subtotal),
        "notes": str(notes or "").strip(),
        "created_by": str(created_by or "system").strip() or "system",
        "updated_at": now,
    }

    purchase_df = pd.concat([purchase_df.reindex(columns=PURCHASE_COLUMNS), pd.DataFrame([purchase_row], columns=PURCHASE_COLUMNS)], ignore_index=True, sort=False)
    _atomic_write(purchase_df, PURCHASES_PATH)

    for row in line_rows:
        purchase_items_df = pd.concat([purchase_items_df.reindex(columns=PURCHASE_ITEM_COLUMNS), pd.DataFrame([row], columns=PURCHASE_ITEM_COLUMNS)], ignore_index=True, sort=False)
    _atomic_write(purchase_items_df, PURCHASE_ITEMS_PATH)
    return {"success": True, "message": "Purchase created successfully.", "purchase": get_purchase_by_id(cafe_id, purchase_id)}


def update_purchase_status(cafe_id, purchase_id, status):
    cafe_id = str(cafe_id or "").strip()
    purchase_id = str(purchase_id or "").strip()
    status = str(status or "Draft").strip()
    if status not in VALID_STATUSES:
        return {"success": False, "message": "Unsupported purchase status."}
    purchase = get_purchase_by_id(cafe_id, purchase_id)
    if purchase is None:
        return {"success": False, "message": "Purchase not found for this café."}

    current_status = str(purchase.get("status") or "Draft").strip()
    if not _status_transition_allowed(current_status, status):
        return {"success": False, "message": f"Invalid status transition from {current_status} to {status}."}
    if status == "Cancelled":
        total_received = Decimal("0")
        for item in purchase.get("items", []):
            total_received += Decimal(str(item.get("received_quantity") or 0))
        if total_received > 0:
            return {"success": False, "message": "A purchase with goods already received cannot be cancelled."}

    purchase_df = _read_purchases_df()
    mask = (purchase_df["cafe_id"].astype(str) == cafe_id) & (purchase_df["purchase_id"].astype(str) == purchase_id)
    purchase_df.loc[mask, "status"] = status
    purchase_df.loc[mask, "updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    _atomic_write(purchase_df, PURCHASES_PATH)
    return {"success": True, "message": "Purchase status updated.", "purchase": get_purchase_by_id(cafe_id, purchase_id)}


def _purchase_total_received(purchase_items):
    total = Decimal("0")
    for item in purchase_items:
        total += Decimal(str(item.get("received_quantity") or 0))
    return total


def record_receipt(cafe_id, purchase_id, received_items, actor_id="system"):
    cafe_id = str(cafe_id or "").strip()
    purchase_id = str(purchase_id or "").strip()
    if not cafe_id or not purchase_id:
        return {"success": False, "message": "Purchase information is missing."}

    purchase = get_purchase_by_id(cafe_id, purchase_id)
    if purchase is None:
        return {"success": False, "message": "Purchase not found for this café."}
    if purchase["status"] == "Cancelled":
        return {"success": False, "message": "Cancelled purchases cannot receive stock."}
    if purchase["status"] == "Received":
        return {"success": False, "message": "This purchase has already been fully received."}
    if purchase["status"] not in {"Ordered", "Partially Received"}:
        return {"success": False, "message": "Only ordered purchases can receive stock."}

    if not isinstance(received_items, list) or not received_items:
        return {"success": False, "message": "Received items are required."}

    items_df = _read_purchase_items_df()
    purchase_items = _get_purchase_items(cafe_id, purchase_id)
    if not purchase_items:
        return {"success": False, "message": "No purchase lines were found."}
    applied = []
    for entry in received_items:
        ingredient_name = str(entry.get("ingredient_name") or entry.get("name") or "").strip()
        ingredient_id = str(entry.get("ingredient_id") or "").strip()
        ingredient = None
        matched_item = None
        for item in purchase_items:
            if ingredient_id and item["ingredient_id"] == ingredient_id:
                matched_item = item
                ingredient = get_ingredient_by_id(cafe_id, ingredient_id)
                break
            if ingredient_name and item["ingredient_name"].lower() == ingredient_name.lower():
                matched_item = item
                ingredient = get_ingredient_by_id(cafe_id, item["ingredient_id"])
                break
        if ingredient is None or matched_item is None:
            return {"success": False, "message": f"Ingredient '{ingredient_name or ingredient_id}' is not part of this purchase."}
        new_received = entry.get("quantity_received")
        try:
            quantity_received = _decimal(new_received)
        except ValueError:
            return {"success": False, "message": f"Received quantity for {ingredient['name']} must be a positive number."}
        if quantity_received <= 0:
            return {"success": False, "message": f"Received quantity for {ingredient['name']} must be greater than zero."}
        ordered_quantity = Decimal(str(matched_item["ordered_quantity"]))
        already_received = Decimal(str(matched_item["received_quantity"]))
        remaining = ordered_quantity - already_received
        if quantity_received > remaining:
            return {"success": False, "message": f"Received quantity for {ingredient['name']} exceeds the remaining ordered quantity."}
        existing_received_value = Decimal(str(matched_item.get("received_quantity") or 0))
        if abs(quantity_received - existing_received_value) <= Decimal("0.0001"):
            return {"success": False, "message": f"Receipt for {ingredient['name']} has already been processed."}
        unit = str(entry.get("unit") or matched_item["unit"]).strip() or matched_item["unit"]
        try:
            unit_value = _canonical_unit(unit)
            _convert_quantity(quantity_received, unit_value, ingredient["unit"])
        except ValueError:
            return {"success": False, "message": f"Unit '{unit}' is incompatible with ingredient '{ingredient['name']}' ({ingredient['unit']})."}
        if quantity_received > remaining:
            return {"success": False, "message": f"Received quantity for {ingredient['name']} exceeds remaining order quantity."}
        applied.append({
            "purchase_item_id": matched_item["purchase_item_id"],
            "ingredient_id": ingredient["ingredient_id"],
            "quantity_received": quantity_received,
            "unit": unit_value,
            "ingredient_name": ingredient["name"],
            "reference_suffix": datetime.now().strftime("%Y%m%d%H%M%S%f"),
        })

    for item in applied:
        matching = items_df[(items_df["cafe_id"].astype(str) == cafe_id) & (items_df["purchase_id"].astype(str) == purchase_id) & (items_df["purchase_item_id"].astype(str) == item["purchase_item_id"])]
        if matching.empty:
            return {"success": False, "message": "Purchase item could not be matched while updating receipt."}
        current_received = Decimal(str(matching.iloc[0].get("received_quantity") or 0))
        new_total = current_received + item["quantity_received"]
        items_df.loc[matching.index, "received_quantity"] = float(new_total)
        items_df.loc[matching.index, "updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        movement_result = record_stock_movement(
            cafe_id=cafe_id,
            ingredient_id=item["ingredient_id"],
            movement_type="purchase_receipt",
            quantity=item["quantity_received"],
            unit=item["unit"],
            reference=f"PO:{purchase_id}:{item['purchase_item_id']}:{item['reference_suffix']}",
            reason="Goods received against purchase",
            actor_id=actor_id,
        )
        if not movement_result["success"]:
            return {"success": False, "message": movement_result["message"]}
    _atomic_write(items_df, PURCHASE_ITEMS_PATH)

    updated_purchase = get_purchase_by_id(cafe_id, purchase_id)
    remaining_all = True
    for item in updated_purchase["items"]:
        if Decimal(str(item.get("received_quantity") or 0)) < Decimal(str(item.get("ordered_quantity") or 0)):
            remaining_all = False
            break
    if remaining_all:
        new_status = "Received"
    else:
        new_status = "Partially Received"
    update_purchase_status(cafe_id, purchase_id, new_status)
    purchase = get_purchase_by_id(cafe_id, purchase_id)
    return {"success": True, "message": "Goods receipt recorded successfully.", "purchase": purchase}


def get_purchase_summary(cafe_id):
    purchases = list_purchases(cafe_id)
    statuses = {status: 0 for status in VALID_STATUSES}
    total_spend = Decimal("0")
    for purchase in purchases:
        statuses[purchase["status"]] = statuses.get(purchase["status"], 0) + 1
        total_spend += Decimal(str(purchase.get("subtotal") or 0))
    awaiting_delivery = statuses.get("Ordered", 0) + statuses.get("Partially Received", 0)
    return {
        "total_purchases": len(purchases),
        "draft_purchases": statuses.get("Draft", 0),
        "ordered_purchases": statuses.get("Ordered", 0),
        "awaiting_delivery_purchases": awaiting_delivery,
        "partially_received_purchases": statuses.get("Partially Received", 0),
        "received_purchases": statuses.get("Received", 0),
        "total_purchase_spend": float(total_spend),
    }


def list_supplier_purchases(cafe_id, supplier_id):
    supplier_id = str(supplier_id or "").strip()
    return [purchase for purchase in list_purchases(cafe_id) if purchase["supplier_id"] == supplier_id]


def cancel_purchase(cafe_id, purchase_id):
    return update_purchase_status(cafe_id, purchase_id, "Cancelled")


def get_low_stock_purchase_suggestions(cafe_id):
    suggestions = []
    inventory_rows = list_ingredients(cafe_id)
    for ingredient in inventory_rows:
        low = float(ingredient["minimum_stock"])
        current = float(ingredient["current_stock"])
        outstanding = Decimal("0")
        for purchase in list_purchases(cafe_id):
            for item in purchase["items"]:
                if item["ingredient_id"] == ingredient["ingredient_id"]:
                    ordered = Decimal(str(item["ordered_quantity"]))
                    received = Decimal(str(item["received_quantity"]))
                    outstanding += ordered - received
        if current <= low or outstanding > 0:
            suggestions.append({
                "ingredient_id": ingredient["ingredient_id"],
                "ingredient_name": ingredient["name"],
                "current_stock": ingredient["current_stock"],
                "minimum_stock": ingredient["minimum_stock"],
                "outstanding_ordered_quantity": float(outstanding),
                "suggested_review_quantity": max(0.0, float(low - current + outstanding)),
            })
    return suggestions


__all__ = [
    "VALID_STATUSES",
    "cancel_purchase",
    "create_purchase",
    "get_low_stock_purchase_suggestions",
    "get_purchase_by_id",
    "get_purchase_summary",
    "list_purchases",
    "list_supplier_purchases",
    "record_receipt",
    "update_purchase_status",
]
