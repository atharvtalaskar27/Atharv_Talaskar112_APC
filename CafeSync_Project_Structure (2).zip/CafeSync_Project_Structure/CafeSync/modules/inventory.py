"""Inventory and stock movement management for CaféSync.

The app remains CSV-based and multi-tenant aware. Inventory records and stock
movements are scoped to the authenticated café and stored in separate CSV files
for safer auditing and simpler debugging.
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path

import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
INVENTORY_PATH = DATA_DIR / "inventory.csv"
MOVEMENTS_PATH = DATA_DIR / "inventory_movements.csv"

INVENTORY_COLUMNS = [
    "ingredient_id",
    "cafe_id",
    "name",
    "unit",
    "current_stock",
    "minimum_stock",
    "unit_cost",
    "created_at",
    "updated_at",
]

MOVEMENT_COLUMNS = [
    "movement_id",
    "cafe_id",
    "ingredient_id",
    "movement_type",
    "quantity",
    "unit",
    "reference",
    "reason",
    "created_at",
    "actor_id",
]

ALLOWED_UNITS = ["g", "kg", "ml", "litre", "pcs"]
UNIT_ALIASES = {
    "g": "g",
    "gram": "g",
    "grams": "g",
    "kg": "kg",
    "kilogram": "kg",
    "kilograms": "kg",
    "ml": "ml",
    "millilitre": "ml",
    "milliliter": "ml",
    "millilitres": "ml",
    "milliliters": "ml",
    "l": "litre",
    "liter": "litre",
    "litre": "litre",
    "litres": "litre",
    "liters": "litre",
    "piece": "pcs",
    "pieces": "pcs",
    "pcs": "pcs",
    "pc": "pcs",
}

MOVEMENT_TYPES = {
    "opening_stock",
    "purchase_receipt",
    "manual_stock_increase",
    "manual_stock_decrease",
    "waste_adjustment",
}


def _ensure_data_dir():
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def _decimal(value, allow_zero=True, allow_negative=False):
    if value is None or (isinstance(value, float) and pd.isna(value)):
        raise ValueError("Value is missing.")
    try:
        dec = Decimal(str(value).strip())
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError("Value must be numeric.")
    if not allow_zero and dec == 0:
        raise ValueError("Value must be non-zero.")
    if not allow_negative and dec < 0:
        raise ValueError("Value cannot be negative.")
    return dec


def _canonical_unit(value):
    raw = str(value or "").strip().lower()
    if not raw:
        raise ValueError("Unit is required.")
    canonical = UNIT_ALIASES.get(raw)
    if not canonical:
        raise ValueError(f"Unsupported unit '{value}'. Supported units: {', '.join(ALLOWED_UNITS)}")
    return canonical


def _convert_quantity(value, from_unit, to_unit):
    from_unit = _canonical_unit(from_unit)
    to_unit = _canonical_unit(to_unit)

    if from_unit == to_unit:
        return Decimal(str(value))

    mapping = {
        ("kg", "g"): Decimal("1000"),
        ("g", "kg"): Decimal("0.001"),
        ("litre", "ml"): Decimal("1000"),
        ("ml", "litre"): Decimal("0.001"),
    }

    scale = mapping.get((from_unit, to_unit))
    if scale is None:
        raise ValueError(f"Incompatible units: {from_unit} and {to_unit}.")
    return Decimal(str(value)) * scale


def _read_inventory_df():
    _ensure_data_dir()
    if not INVENTORY_PATH.exists():
        empty = pd.DataFrame(columns=INVENTORY_COLUMNS)
        empty.to_csv(INVENTORY_PATH, index=False)
        return empty

    try:
        df = pd.read_csv(INVENTORY_PATH)
    except Exception:
        return pd.DataFrame(columns=INVENTORY_COLUMNS)

    for column in INVENTORY_COLUMNS:
        if column not in df.columns:
            df[column] = ""

    if "ingredient_name" in df.columns and "name" not in df.columns:
        df["name"] = df["ingredient_name"]
    if "quantity" in df.columns and "current_stock" not in df.columns:
        df["current_stock"] = df["quantity"]
    if "min_stock" in df.columns and "minimum_stock" not in df.columns:
        df["minimum_stock"] = df["min_stock"]

    df = df.reindex(columns=INVENTORY_COLUMNS)
    df.to_csv(INVENTORY_PATH, index=False)
    return df


def _read_movements_df():
    _ensure_data_dir()
    if not MOVEMENTS_PATH.exists():
        empty = pd.DataFrame(columns=MOVEMENT_COLUMNS)
        empty.to_csv(MOVEMENTS_PATH, index=False)
        return empty

    try:
        df = pd.read_csv(MOVEMENTS_PATH)
    except Exception:
        return pd.DataFrame(columns=MOVEMENT_COLUMNS)

    for column in MOVEMENT_COLUMNS:
        if column not in df.columns:
            df[column] = ""
    df = df.reindex(columns=MOVEMENT_COLUMNS)
    df.to_csv(MOVEMENTS_PATH, index=False)
    return df


def _write_inventory_df(df):
    df = df.copy().reindex(columns=INVENTORY_COLUMNS)
    df.to_csv(INVENTORY_PATH, index=False)


def _write_movements_df(df):
    df = df.copy().reindex(columns=MOVEMENT_COLUMNS)
    df.to_csv(MOVEMENTS_PATH, index=False)


def _generate_ingredient_id():
    df = _read_inventory_df()
    if df.empty:
        return "I001"

    values = []
    for value in df["ingredient_id"].fillna("").astype(str):
        if value.startswith("I") and value[1:].isdigit():
            values.append(int(value[1:]))
    next_number = max(values, default=0) + 1
    return f"I{next_number:03d}"


def _generate_movement_id():
    df = _read_movements_df()
    if df.empty:
        return "SM001"

    values = []
    for value in df["movement_id"].fillna("").astype(str):
        if value.startswith("SM") and value[2:].isdigit():
            values.append(int(value[2:]))
    next_number = max(values, default=0) + 1
    return f"SM{next_number:03d}"


def _normalize_ingredient_row(row):
    unit = _canonical_unit(row.get("unit") or "")
    try:
        current_stock = Decimal(str(row.get("current_stock") or 0))
    except InvalidOperation:
        current_stock = Decimal("0")
    try:
        minimum_stock = Decimal(str(row.get("minimum_stock") or 0))
    except InvalidOperation:
        minimum_stock = Decimal("0")

    unit_cost_value = row.get("unit_cost")
    unit_cost = None
    if unit_cost_value is not None and not (isinstance(unit_cost_value, str) and unit_cost_value.strip() == ""):
        try:
            if pd.isna(unit_cost_value):
                unit_cost = None
            else:
                unit_cost = float(Decimal(str(unit_cost_value)))
        except (InvalidOperation, TypeError, ValueError):
            unit_cost = None

    return {
        "ingredient_id": str(row.get("ingredient_id") or "").strip(),
        "cafe_id": str(row.get("cafe_id") or "").strip(),
        "name": str(row.get("name") or row.get("ingredient_name") or "").strip(),
        "unit": unit,
        "current_stock": float(current_stock),
        "minimum_stock": float(minimum_stock),
        "unit_cost": unit_cost,
        "created_at": str(row.get("created_at") or "").strip(),
        "updated_at": str(row.get("updated_at") or "").strip(),
        "stock_status": get_stock_status(current_stock, minimum_stock),
    }


def _ingredient_matches_name(df, cafe_id, name, exclude_id=None):
    name_value = str(name or "").strip().lower()
    if not name_value:
        return pd.Series(False, index=df.index)
    mask = (df["cafe_id"].astype(str) == str(cafe_id)) & (df["name"].fillna("").astype(str).str.lower() == name_value)
    if exclude_id is not None:
        mask &= (df["ingredient_id"].astype(str) != str(exclude_id))
    return mask


def get_stock_status(current_stock, minimum_stock):
    try:
        current = Decimal(str(current_stock))
        minimum = Decimal(str(minimum_stock))
    except (InvalidOperation, TypeError, ValueError):
        return "Out of stock"

    if current <= 0:
        return "Out of stock"
    if current <= minimum:
        return "Low stock"
    return "In stock"


def _calculate_inventory_value(ingredients):
    total = Decimal("0")
    for ingredient in ingredients:
        if ingredient.get("unit_cost") is None:
            return None
        try:
            cost = Decimal(str(ingredient["unit_cost"]))
        except (InvalidOperation, TypeError, ValueError):
            return None
        if cost < 0:
            return None
        stock = Decimal(str(ingredient.get("current_stock", 0)))
        total += stock * cost
    return float(total)


def get_inventory_dashboard(cafe_id):
    ingredients = list_ingredients(str(cafe_id))
    total = len(ingredients)
    low = sum(1 for item in ingredients if item["stock_status"] == "Low stock")
    out = sum(1 for item in ingredients if item["stock_status"] == "Out of stock")
    value = _calculate_inventory_value(ingredients)
    return {
        "total_ingredients": total,
        "low_stock_ingredients": low,
        "out_of_stock_ingredients": out,
        "inventory_value": value,
        "inventory_value_label": "Not available" if value is None else f"₹ {value:,.2f}",
    }


def list_ingredients(cafe_id, search="", status="All"):
    cafe_id = str(cafe_id or "").strip()
    df = _read_inventory_df()
    if df.empty:
        return []

    filtered = df[df["cafe_id"].astype(str) == cafe_id].copy()
    if filtered.empty:
        return []

    if search:
        term = str(search).strip().lower()
        filtered = filtered[
            filtered["name"].fillna("").astype(str).str.lower().str.contains(term, na=False)
            | filtered["unit"].fillna("").astype(str).str.lower().str.contains(term, na=False)
        ]

    rows = []
    for _, row in filtered.iterrows():
        ingredient = _normalize_ingredient_row(row.to_dict())
        if status != "All" and ingredient["stock_status"] != status:
            continue
        rows.append(ingredient)

    rows.sort(key=lambda record: (record["name"].lower(), record["ingredient_id"]))
    return rows


def get_ingredient_by_id(cafe_id, ingredient_id):
    cafe_id = str(cafe_id or "").strip()
    ingredient_id = str(ingredient_id or "").strip()
    df = _read_inventory_df()
    if df.empty:
        return None

    match = df[(df["cafe_id"].astype(str) == cafe_id) & (df["ingredient_id"].astype(str) == ingredient_id)]
    if match.empty:
        return None
    return _normalize_ingredient_row(match.iloc[0].to_dict())


def add_ingredient(cafe_id, name, unit, minimum_stock, unit_cost="", opening_stock=0):
    cafe_id = str(cafe_id or "").strip()
    name = str(name or "").strip()
    if not cafe_id:
        return {"success": False, "message": "No active café is selected."}
    if not name:
        return {"success": False, "message": "Ingredient name is required."}

    try:
        canonical_unit = _canonical_unit(unit)
    except ValueError as exc:
        return {"success": False, "message": str(exc)}

    try:
        minimum = _decimal(minimum_stock, allow_zero=True, allow_negative=False)
    except ValueError:
        return {"success": False, "message": "Minimum stock must be a valid number."}

    try:
        opening = _decimal(opening_stock, allow_zero=True, allow_negative=False)
    except ValueError:
        return {"success": False, "message": "Opening stock must be a valid number greater than or equal to zero."}

    unit_cost_decimal = None
    if unit_cost not in (None, "", " "):
        try:
            unit_cost_decimal = _decimal(unit_cost, allow_zero=True, allow_negative=False)
        except ValueError:
            return {"success": False, "message": "Unit cost must be a valid number greater than or equal to zero."}

    df = _read_inventory_df()
    duplicate = _ingredient_matches_name(df, cafe_id, name)
    if duplicate.any():
        return {"success": False, "message": "This ingredient already exists for this café."}

    ingredient_id = _generate_ingredient_id()
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    record = {
        "ingredient_id": ingredient_id,
        "cafe_id": cafe_id,
        "name": name,
        "unit": canonical_unit,
        "current_stock": 0.0,
        "minimum_stock": float(minimum),
        "unit_cost": float(unit_cost_decimal) if unit_cost_decimal is not None else "",
        "created_at": timestamp,
        "updated_at": timestamp,
    }
    df = pd.concat([df.reindex(columns=INVENTORY_COLUMNS), pd.DataFrame([record], columns=INVENTORY_COLUMNS)], ignore_index=True, sort=False)
    _write_inventory_df(df)

    # Opening stock has one authoritative path: the stock-movement service.
    # This prevents a second, competing balance update and creates an audit row.
    if opening > 0:
        movement = record_stock_movement(
            cafe_id=cafe_id,
            ingredient_id=ingredient_id,
            movement_type="opening_stock",
            quantity=opening,
            unit=canonical_unit,
            reference=f"OPEN-{ingredient_id}",
            reason="Opening stock at ingredient creation",
        )
        if not movement["success"]:
            # Best-effort rollback of this newly-created record. No existing
            # ingredient or movement is touched if creation cannot complete.
            current = _read_inventory_df()
            created_mask = (current["cafe_id"].astype(str) == cafe_id) & (current["ingredient_id"].astype(str) == ingredient_id)
            _write_inventory_df(current.loc[~created_mask].copy())
            return {"success": False, "message": f"Ingredient was not created because opening stock could not be recorded: {movement['message']}"}
        return {"success": True, "message": "Ingredient added with opening stock recorded.", "ingredient": movement["ingredient"]}

    return {"success": True, "message": "Ingredient added successfully.", "ingredient": _normalize_ingredient_row(record)}


def update_ingredient(cafe_id, ingredient_id, name=None, unit=None, minimum_stock=None, unit_cost=None):
    cafe_id = str(cafe_id or "").strip()
    ingredient_id = str(ingredient_id or "").strip()
    if not cafe_id or not ingredient_id:
        return {"success": False, "message": "Missing café or ingredient information."}

    df = _read_inventory_df()
    match = df[(df["cafe_id"].astype(str) == cafe_id) & (df["ingredient_id"].astype(str) == ingredient_id)]
    if match.empty:
        return {"success": False, "message": "Ingredient not found for this café."}

    existing = match.iloc[0].to_dict()
    current_name = str(name or existing.get("name") or existing.get("ingredient_name") or "").strip()
    if not current_name:
        return {"success": False, "message": "Ingredient name is required."}

    new_unit = _canonical_unit(unit or existing.get("unit") or "g")

    try:
        minimum = _decimal(minimum_stock if minimum_stock is not None else existing.get("minimum_stock", 0), allow_zero=True, allow_negative=False)
    except ValueError:
        return {"success": False, "message": "Minimum stock must be a valid number."}

    if unit_cost is not None and str(unit_cost).strip() not in ("", " "):
        try:
            parsed_cost = _decimal(unit_cost, allow_zero=True, allow_negative=False)
        except ValueError:
            return {"success": False, "message": "Unit cost must be a valid number greater than or equal to zero."}
        cost_value = float(parsed_cost)
    else:
        raw_cost = existing.get("unit_cost")
        if raw_cost is None or (isinstance(raw_cost, float) and pd.isna(raw_cost)) or str(raw_cost).strip() in ("", "nan"):
            cost_value = ""
        else:
            try:
                cost_value = float(_decimal(raw_cost, allow_zero=True, allow_negative=False))
            except ValueError:
                return {"success": False, "message": "Existing unit cost is invalid; correct it before saving."}

    if _ingredient_matches_name(df, cafe_id, current_name, ingredient_id).any():
        return {"success": False, "message": "Another ingredient with this name already exists for this café."}

    current_stock = Decimal(str(existing.get("current_stock") or 0))
    old_unit = _canonical_unit(existing.get("unit") or "g")
    if old_unit != new_unit:
        history = _read_movements_df()
        if not history[
            (history["cafe_id"].astype(str) == cafe_id)
            & (history["ingredient_id"].astype(str) == ingredient_id)
        ].empty:
            return {"success": False, "message": "Unit cannot be changed after stock history exists; record stock using the existing unit."}
        try:
            current_stock = _convert_quantity(current_stock, old_unit, new_unit)
        except ValueError as exc:
            return {"success": False, "message": f"Unit conversion failed: {exc}"}

    updated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    df.loc[match.index, "name"] = current_name
    df.loc[match.index, "unit"] = new_unit
    df.loc[match.index, "current_stock"] = float(current_stock)
    df.loc[match.index, "minimum_stock"] = float(minimum)
    df.loc[match.index, "unit_cost"] = cost_value if cost_value != "" else ""
    df.loc[match.index, "updated_at"] = updated_at
    try:
        _write_inventory_df(df)
    except Exception:
        return {"success": False, "message": "Ingredient could not be saved. Your existing record was not changed."}

    updated = get_ingredient_by_id(cafe_id, ingredient_id)
    return {"success": True, "message": "Ingredient updated successfully.", "ingredient": updated}


def record_stock_movement(cafe_id, ingredient_id, movement_type, quantity, unit, reference="", reason="", actor_id="system"):
    cafe_id = str(cafe_id or "").strip()
    ingredient_id = str(ingredient_id or "").strip()
    if not cafe_id:
        return {"success": False, "message": "No active café is selected."}
    if movement_type not in MOVEMENT_TYPES:
        return {"success": False, "message": "Unsupported stock movement type."}

    ingredient = get_ingredient_by_id(cafe_id, ingredient_id)
    if ingredient is None:
        return {"success": False, "message": "Ingredient not found for this café."}

    try:
        quantity_dec = _decimal(quantity, allow_zero=False, allow_negative=False)
    except ValueError:
        return {"success": False, "message": "Quantity must be a positive number."}

    try:
        movement_unit = _canonical_unit(unit)
    except ValueError as exc:
        return {"success": False, "message": str(exc)}

    try:
        converted = _convert_quantity(quantity_dec, movement_unit, ingredient["unit"])
    except ValueError:
        return {"success": False, "message": f"Unit mismatch: movement unit {movement_unit} is not compatible with ingredient unit {ingredient['unit']}."}

    if movement_type in {"manual_stock_increase", "manual_stock_decrease", "waste_adjustment"} and not str(reason or "").strip():
        return {"success": False, "message": "A reason is required for manual stock adjustments."}

    if movement_type in {"opening_stock", "purchase_receipt", "manual_stock_increase"}:
        delta = converted
    elif movement_type in {"manual_stock_decrease", "waste_adjustment"}:
        delta = -converted
    else:
        delta = Decimal("0")

    current_stock = Decimal(str(ingredient["current_stock"]))
    candidate = current_stock + delta
    if candidate < 0:
        return {"success": False, "message": "Stock cannot fall below zero for this movement."}

    reference_text = str(reference or "").strip()
    if reference_text:
        movements = _read_movements_df()
        duplicate = movements[
            (movements["cafe_id"].astype(str) == cafe_id)
            & (movements["ingredient_id"].astype(str) == ingredient_id)
            & (movements["movement_type"].astype(str).str.lower() == movement_type.lower())
            & (movements["reference"].fillna("").astype(str).str.lower() == reference_text.lower())
        ]
        if not duplicate.empty:
            return {"success": False, "message": "This stock movement has already been recorded."}

    movement_id = _generate_movement_id()
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    movement_row = {
        "movement_id": movement_id,
        "cafe_id": cafe_id,
        "ingredient_id": ingredient_id,
        "movement_type": movement_type,
        "quantity": float(quantity_dec),
        "unit": movement_unit,
        "reference": reference_text,
        "reason": str(reason or "").strip(),
        "created_at": timestamp,
        "actor_id": str(actor_id or "system").strip() or "system",
    }

    movements_df = _read_movements_df()
    movements_df = pd.concat([
        movements_df.reindex(columns=MOVEMENT_COLUMNS),
        pd.DataFrame([movement_row], columns=MOVEMENT_COLUMNS),
    ], ignore_index=True, sort=False)
    try:
        _write_movements_df(movements_df)
    except Exception:
        return {"success": False, "message": "Movement history could not be saved. Stock was not updated."}

    inventory_df = _read_inventory_df()
    mask = (inventory_df["cafe_id"].astype(str) == cafe_id) & (inventory_df["ingredient_id"].astype(str) == ingredient_id)
    if not mask.any():
        return {"success": False, "message": "Inventory record could not be located after movement save."}

    inventory_df.loc[mask, "current_stock"] = float(candidate)
    inventory_df.loc[mask, "updated_at"] = timestamp
    try:
        _write_inventory_df(inventory_df)
    except Exception:
        try:
            saved_movements = _read_movements_df()
            saved_movements = saved_movements[saved_movements["movement_id"].astype(str) != movement_id]
            _write_movements_df(saved_movements)
        except Exception:
            return {"success": False, "message": "Stock could not be saved consistently. Contact an administrator before retrying.", "movement": movement_row}
        return {"success": False, "message": "Stock movement could not be saved. Your stock balance was not changed."}

    updated = get_ingredient_by_id(cafe_id, ingredient_id)
    return {"success": True, "message": "Stock movement recorded successfully.", "movement": movement_row, "ingredient": updated}


def list_stock_movements(cafe_id, ingredient_id=None, movement_type="All"):
    cafe_id = str(cafe_id or "").strip()
    df = _read_movements_df()
    if df.empty:
        return []

    filtered = df[df["cafe_id"].astype(str) == cafe_id].copy()
    if ingredient_id:
        filtered = filtered[filtered["ingredient_id"].astype(str) == str(ingredient_id)]
    if movement_type != "All":
        filtered = filtered[filtered["movement_type"].astype(str).str.lower() == str(movement_type).lower()]

    rows = filtered.sort_values(by=["created_at", "movement_id"], ascending=[False, False], kind="mergesort", na_position="last").to_dict("records")
    return rows


__all__ = [
    "ALLOWED_UNITS",
    "MOVEMENT_TYPES",
    "add_ingredient",
    "get_ingredient_by_id",
    "get_inventory_dashboard",
    "get_stock_status",
    "list_ingredients",
    "list_stock_movements",
    "record_stock_movement",
    "update_ingredient",
]
