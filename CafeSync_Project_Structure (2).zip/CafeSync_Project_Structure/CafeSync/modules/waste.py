"""Waste management for CaféSync.

The waste workflow keeps the inventory stock adjustment in the existing
stock movement service and stores a separate waste audit log for the café.
"""

from __future__ import annotations

from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation
from pathlib import Path

import pandas as pd

from modules import inventory

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
WASTE_PATH = DATA_DIR / "waste.csv"

WASTE_COLUMNS = [
    "waste_id",
    "cafe_id",
    "ingredient_id",
    "quantity",
    "unit",
    "reason",
    "estimated_unit_cost",
    "estimated_total_cost",
    "occurred_at",
    "recorded_by",
    "notes",
    "stock_movement_id",
    "created_at",
    "operation_id",
]

WASTE_REASONS = [
    "Expired / Spoiled",
    "Over-prepared",
    "Preparation Error",
    "Damaged / Spilled",
    "Quality Issue",
    "Other",
]

ALLOWED_UNITS = ["g", "kg", "ml", "litre", "pcs"]
UNIT_ALIASES = {
    "g": "g",
    "gram": "g",
    "grams": "g",
    "kg": "kg",
    "kilogram": "kg",
    "kilograms": "kg",
    "ml": "ml",
    "millilitre": "ml",
    "milliliter": "ml",
    "millilitres": "ml",
    "milliliters": "ml",
    "l": "litre",
    "liter": "litre",
    "litre": "litre",
    "litres": "litre",
    "liters": "litre",
    "pcs": "pcs",
    "piece": "pcs",
    "pieces": "pcs",
    "pc": "pcs",
}


def _ensure_data_dir():
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def _atomic_write(frame, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temp_path, index=False)
    temp_path.replace(path)


def _decimal(value, allow_zero=False, allow_negative=False):
    if value is None or (isinstance(value, float) and pd.isna(value)):
        raise ValueError("Value is missing.")
    try:
        dec = Decimal(str(value).strip())
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError("Value must be numeric.")
    if not allow_zero and dec == 0:
        raise ValueError("Value must be non-zero.")
    if not allow_negative and dec < 0:
        raise ValueError("Value cannot be negative.")
    return dec


def _canonical_unit(value):
    raw = str(value or "").strip().lower()
    if not raw:
        raise ValueError("Unit is required.")
    canonical = UNIT_ALIASES.get(raw)
    if not canonical:
        raise ValueError(f"Unsupported unit '{value}'. Supported units: {', '.join(ALLOWED_UNITS)}")
    return canonical


def _convert_quantity(value, from_unit, to_unit):
    from_unit = _canonical_unit(from_unit)
    to_unit = _canonical_unit(to_unit)
    if from_unit == to_unit:
        return Decimal(str(value))
    mapping = {
        ("kg", "g"): Decimal("1000"),
        ("g", "kg"): Decimal("0.001"),
        ("litre", "ml"): Decimal("1000"),
        ("ml", "litre"): Decimal("0.001"),
    }
    scale = mapping.get((from_unit, to_unit))
    if scale is None:
        raise ValueError(f"Incompatible units: {from_unit} and {to_unit}.")
    return Decimal(str(value)) * scale


def _read_waste_df():
    _ensure_data_dir()
    if not WASTE_PATH.exists():
        empty = pd.DataFrame(columns=WASTE_COLUMNS)
        _atomic_write(empty, WASTE_PATH)
        return empty
    try:
        df = pd.read_csv(WASTE_PATH)
    except Exception:
        return pd.DataFrame(columns=WASTE_COLUMNS)

    for column in WASTE_COLUMNS:
        if column not in df.columns:
            df[column] = ""
    df = df.reindex(columns=WASTE_COLUMNS)
    try:
        _atomic_write(df, WASTE_PATH)
    except Exception:
        pass
    return df


def _generate_waste_id():
    df = _read_waste_df()
    if df.empty:
        return "W001"
    values = []
    for value in df["waste_id"].fillna("").astype(str):
        if value.startswith("W") and value[1:].isdigit():
            values.append(int(value[1:]))
    next_number = max(values, default=0) + 1
    return f"W{next_number:03d}"


def _normalize_waste_row(row):
    raw_quantity = row.get("quantity", 0)
    try:
        quantity = float(Decimal(str(raw_quantity or 0)))
    except (InvalidOperation, TypeError, ValueError):
        quantity = 0.0

    def _cost_value(raw):
        if raw is None or (isinstance(raw, str) and raw.strip() == ""):
            return None
        try:
            value = Decimal(str(raw))
            return float(value)
        except (InvalidOperation, TypeError, ValueError):
            return None

    return {
        "waste_id": str(row.get("waste_id") or "").strip(),
        "cafe_id": str(row.get("cafe_id") or "").strip(),
        "ingredient_id": str(row.get("ingredient_id") or "").strip(),
        "quantity": quantity,
        "unit": str(row.get("unit") or "").strip(),
        "reason": str(row.get("reason") or "").strip(),
        "estimated_unit_cost": _cost_value(row.get("estimated_unit_cost")),
        "estimated_total_cost": _cost_value(row.get("estimated_total_cost")),
        "occurred_at": str(row.get("occurred_at") or "").strip(),
        "recorded_by": str(row.get("recorded_by") or "").strip(),
        "notes": str(row.get("notes") or "").strip(),
        "stock_movement_id": str(row.get("stock_movement_id") or "").strip(),
        "created_at": str(row.get("created_at") or "").strip(),
        "operation_id": str(row.get("operation_id") or "").strip(),
    }


def _serialize_cost(value):
    if value is None:
        return ""
    try:
        return float(Decimal(str(value)))
    except (InvalidOperation, TypeError, ValueError):
        return ""


def _build_qty_label(rows):
    if not rows:
        return "0"
    by_unit = {}
    for row in rows:
        unit = str(row.get("unit") or "").strip() or "pcs"
        quantity = Decimal(str(row.get("quantity") or 0))
        by_unit[unit] = by_unit.get(unit, Decimal("0")) + quantity
    parts = []
    for unit, amount in sorted(by_unit.items()):
        parts.append(f"{float(amount):,.2f} {unit}")
    return ", ".join(parts) if parts else "0"


def _format_currency(value):
    if value is None:
        return "Cost unavailable"
    try:
        amount = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        return "Cost unavailable"
    return f"₹{float(amount):,.2f}"


def list_waste_entries(cafe_id, search="", reason="All", start_date=None, end_date=None):
    cafe_id = str(cafe_id or "").strip()
    if not cafe_id:
        return []

    df = _read_waste_df()
    if df.empty:
        return []
    filtered = df[df["cafe_id"].astype(str) == cafe_id].copy()
    if filtered.empty:
        return []

    if search:
        term = str(search).strip().lower()
        filtered = filtered[
            filtered["waste_id"].fillna("").astype(str).str.lower().str.contains(term, na=False)
            | filtered["ingredient_id"].fillna("").astype(str).str.lower().str.contains(term, na=False)
        ]

    if reason != "All":
        filtered = filtered[filtered["reason"].fillna("").astype(str).str.lower() == str(reason).lower()]

    if start_date:
        filtered = filtered[filtered["occurred_at"].fillna("").astype(str).str >= str(start_date)]
    if end_date:
        filtered = filtered[filtered["occurred_at"].fillna("").astype(str).str <= str(end_date)]

    filtered = filtered.sort_values(by=["occurred_at", "created_at", "waste_id"], ascending=[False, False, False], kind="mergesort")
    rows = []
    for _, row in filtered.iterrows():
        waste = _normalize_waste_row(row.to_dict())
        ingredient = inventory.get_ingredient_by_id(cafe_id, waste["ingredient_id"])
        if ingredient:
            waste["ingredient_name"] = ingredient.get("name")
            waste["ingredient_unit"] = ingredient.get("unit")
        rows.append(waste)
    return rows


def get_waste_by_id(cafe_id, waste_id):
    cafe_id = str(cafe_id or "").strip()
    waste_id = str(waste_id or "").strip()
    if not cafe_id or not waste_id:
        return None
    df = _read_waste_df()
    match = df[(df["cafe_id"].astype(str) == cafe_id) & (df["waste_id"].astype(str) == waste_id)]
    if match.empty:
        return None
    waste = _normalize_waste_row(match.iloc[0].to_dict())
    ingredient = inventory.get_ingredient_by_id(cafe_id, waste["ingredient_id"])
    if ingredient:
        waste["ingredient_name"] = ingredient.get("name")
        waste["ingredient_unit"] = ingredient.get("unit")
    return waste


def get_waste_dashboard(cafe_id, start_date=None, end_date=None, reason=None):
    cafe_id = str(cafe_id or "").strip()
    entries = list_waste_entries(cafe_id, start_date=start_date, end_date=end_date, reason=reason or "All")
    if not entries:
        return {
            "total_entries": 0,
            "total_quantity_by_unit": {},
            "total_quantity_label": "0",
            "estimated_waste_cost": None,
            "estimated_waste_cost_label": "Cost unavailable",
            "most_common_reason": "No data",
            "most_wasted_ingredient": "No data",
            "waste_cost_by_reason": {},
            "trend": [],
            "repeated_incidents": [],
        }

    total_cost = Decimal("0")
    cost_available = 0
    total_by_unit = {}
    reasons = {}
    ingredients = {}
    for entry in entries:
        qty = Decimal(str(entry.get("quantity") or 0))
        unit = str(entry.get("unit") or "pcs").strip() or "pcs"
        total_by_unit[unit] = total_by_unit.get(unit, Decimal("0")) + qty

        reason_text = str(entry.get("reason") or "Other").strip() or "Other"
        reasons[reason_text] = reasons.get(reason_text, 0) + 1

        ingredient_name = str(entry.get("ingredient_name") or entry.get("ingredient_id") or "Unknown").strip() or "Unknown"
        ingredients[ingredient_name] = ingredients.get(ingredient_name, 0) + 1

        est_total = entry.get("estimated_total_cost")
        if est_total is not None:
            try:
                total_cost += Decimal(str(est_total))
                cost_available += 1
            except (InvalidOperation, TypeError, ValueError):
                pass

    if reasons:
        most_common_reason = max(reasons.items(), key=lambda item: item[1])[0]
    else:
        most_common_reason = "No data"

    ingredient_counts = sorted(ingredients.items(), key=lambda item: (-item[1], item[0]))
    top_ingredient = ingredient_counts[0][0] if ingredient_counts else "No data"

    reason_costs = {}
    for entry in entries:
        reason_text = str(entry.get("reason") or "Other").strip() or "Other"
        total = entry.get("estimated_total_cost")
        if total is None:
            continue
        try:
            reason_costs[reason_text] = reason_costs.get(reason_text, Decimal("0")) + Decimal(str(total))
        except (InvalidOperation, TypeError, ValueError):
            continue

    trend = []
    for day in range(7):
        date = (datetime.now() - timedelta(days=6 - day)).strftime("%Y-%m-%d")
        count = sum(1 for entry in entries if str(entry.get("occurred_at", "")).startswith(date))
        trend.append({"date": date, "count": count})

    repeated_incidents = []
    by_ingredient = {}
    for entry in entries:
        ingredient_name = str(entry.get("ingredient_name") or entry.get("ingredient_id") or "Unknown").strip() or "Unknown"
        by_ingredient.setdefault(ingredient_name, []).append(entry)
    for ingredient_name, rows in by_ingredient.items():
        if len(rows) >= 2:
            repeated_incidents.append({
                "ingredient": ingredient_name,
                "count": len(rows),
                "last_seen": max((item.get("occurred_at") or "") for item in rows),
            })
    repeated_incidents = sorted(repeated_incidents, key=lambda item: (-item["count"], item["ingredient"]))[:5]

    total_cost_value = float(total_cost) if cost_available else None
    if cost_available == 0:
        total_cost_label = "Cost unavailable"
    else:
        total_cost_label = f"₹{total_cost_value:,.2f}"

    return {
        "total_entries": len(entries),
        "total_quantity_by_unit": {unit: float(amount) for unit, amount in total_by_unit.items()},
        "total_quantity_label": _build_qty_label(entries),
        "estimated_waste_cost": total_cost_value,
        "estimated_waste_cost_label": total_cost_label,
        "most_common_reason": most_common_reason,
        "most_wasted_ingredient": top_ingredient,
        "waste_cost_by_reason": {k: float(v) for k, v in reason_costs.items()},
        "trend": trend,
        "repeated_incidents": repeated_incidents,
    }


def _validate_and_prepare_waste(cafe_id, ingredient_id, quantity, unit, reason, occurred_at=None, recorded_by=None, notes="", other_reason="", operation_id=None):
    cafe_id = str(cafe_id or "").strip()
    if not cafe_id:
        return {"success": False, "message": "No active café is selected."}

    ingredient = inventory.get_ingredient_by_id(cafe_id, ingredient_id)
    if ingredient is None:
        return {"success": False, "message": "Ingredient not found for this café."}

    try:
        qty = _decimal(quantity, allow_zero=False, allow_negative=False)
    except ValueError:
        return {"success": False, "message": "Waste quantity must be a positive number."}

    try:
        canonical_unit = _canonical_unit(unit)
    except ValueError as exc:
        return {"success": False, "message": str(exc)}

    if reason == "Other":
        if not str(other_reason or "").strip():
            return {"success": False, "message": "Please provide a short explanation for the 'Other' waste reason."}
        detail = str(other_reason or "").strip()
        note_value = str(notes or "").strip()
        notes_text = f"{note_value} | Other reason: {detail}" if note_value else f"Other reason: {detail}"
    else:
        notes_text = str(notes or "").strip()

    try:
        converted = _convert_quantity(qty, canonical_unit, ingredient["unit"])
    except ValueError:
        return {"success": False, "message": f"Unit mismatch: waste unit {canonical_unit} is not compatible with ingredient unit {ingredient['unit']}."}

    current_stock = Decimal(str(ingredient.get("current_stock") or 0))
    if converted > current_stock:
        return {"success": False, "message": "Waste quantity exceeds the available stock for this ingredient."}

    occurred_value = str(occurred_at or datetime.now().strftime("%Y-%m-%d %H:%M:%S")).strip() or datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    unit_cost = ingredient.get("unit_cost")
    if unit_cost is None or (isinstance(unit_cost, str) and str(unit_cost).strip() == ""):
        estimated_unit_cost = None
        estimated_total_cost = None
    else:
        try:
            estimated_unit_cost = float(Decimal(str(unit_cost)))
            estimated_total_cost = float(converted * Decimal(str(unit_cost)))
        except (InvalidOperation, TypeError, ValueError):
            estimated_unit_cost = None
            estimated_total_cost = None

    if operation_id:
        waste_df = _read_waste_df()
        duplicate = waste_df[(waste_df["cafe_id"].astype(str) == cafe_id) & (waste_df["operation_id"].fillna("").astype(str).str.lower() == str(operation_id).lower())]
        if not duplicate.empty:
            return {"success": False, "message": "This waste operation has already been processed."}

    return {
        "success": True,
        "ingredient": ingredient,
        "quantity": qty,
        "unit": canonical_unit,
        "converted_quantity": converted,
        "estimated_unit_cost": estimated_unit_cost,
        "estimated_total_cost": estimated_total_cost,
        "occurred_at": occurred_value,
        "recorded_by": str(recorded_by or "system").strip() or "system",
        "notes": notes_text,
    }


def record_waste(cafe_id, ingredient_id, quantity, unit, reason, occurred_at=None, recorded_by=None, notes="", other_reason="", operation_id=None):
    prepared = _validate_and_prepare_waste(
        cafe_id=cafe_id,
        ingredient_id=ingredient_id,
        quantity=quantity,
        unit=unit,
        reason=reason,
        occurred_at=occurred_at,
        recorded_by=recorded_by,
        notes=notes,
        other_reason=other_reason,
        operation_id=operation_id,
    )
    if not prepared["success"]:
        return prepared

    waste_id = _generate_waste_id()
    movement_reference = f"WASTE:{waste_id}"
    movement = inventory.record_stock_movement(
        cafe_id=cafe_id,
        ingredient_id=ingredient_id,
        movement_type="waste_adjustment",
        quantity=prepared["quantity"],
        unit=prepared["unit"],
        reference=movement_reference,
        reason=str(reason or "Waste disposal").strip() or "Waste disposal",
        actor_id=str(recorded_by or "system").strip() or "system",
    )
    if not movement["success"]:
        return {"success": False, "message": movement["message"]}

    waste_row = {
        "waste_id": waste_id,
        "cafe_id": str(cafe_id or "").strip(),
        "ingredient_id": str(ingredient_id or "").strip(),
        "quantity": float(prepared["quantity"]),
        "unit": prepared["unit"],
        "reason": str(reason or "").strip() or "Other",
        "estimated_unit_cost": _serialize_cost(prepared["estimated_unit_cost"]),
        "estimated_total_cost": _serialize_cost(prepared["estimated_total_cost"]),
        "occurred_at": prepared["occurred_at"],
        "recorded_by": prepared["recorded_by"],
        "notes": prepared["notes"],
        "stock_movement_id": movement["movement"]["movement_id"],
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "operation_id": str(operation_id or "").strip(),
    }

    waste_df = _read_waste_df()
    waste_df = pd.concat([
        waste_df.reindex(columns=WASTE_COLUMNS),
        pd.DataFrame([waste_row], columns=WASTE_COLUMNS),
    ], ignore_index=True, sort=False)
    try:
        _atomic_write(waste_df, WASTE_PATH)
    except Exception:
        return {"success": False, "message": "Waste record could not be saved after stock was adjusted. Review the movement log and reconcile manually."}

    saved = get_waste_by_id(cafe_id, waste_id)
    return {"success": True, "message": "Waste recorded successfully.", "waste": saved, "movement": movement["movement"], "ingredient": prepared["ingredient"]}


def get_waste_summary(cafe_id, search="", reason="All", start_date=None, end_date=None):
    dashboard = get_waste_dashboard(cafe_id, start_date=start_date, end_date=end_date, reason=reason)
    entries = list_waste_entries(cafe_id, search=search, reason=reason, start_date=start_date, end_date=end_date)
    return {
        "total_entries": dashboard["total_entries"],
        "total_quantity_label": dashboard["total_quantity_label"],
        "estimated_waste_cost_label": dashboard["estimated_waste_cost_label"],
        "most_common_reason": dashboard["most_common_reason"],
        "entries": entries,
    }


__all__ = [
    "WASTE_REASONS",
    "get_waste_by_id",
    "get_waste_dashboard",
    "get_waste_summary",
    "list_waste_entries",
    "record_waste",
]
