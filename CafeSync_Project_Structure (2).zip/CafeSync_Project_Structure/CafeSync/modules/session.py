"""Session state for platform-level and café-level access control.

This module keeps the active user and current café in one place so the rest of
application code does not scatter session variables across the project.
"""

from __future__ import annotations


class Session:
    """Stores the currently authenticated user and café context."""

    def __init__(self):
        self.clear()

    def clear(self):
        self.current_user_id = None
        self.current_user_name = None
        self.current_user_role = None
        self.current_cafe_id = None
        self.current_cafe_name = None

    def login_session(
        self,
        current_user_id,
        current_user_name,
        current_user_role,
        current_cafe_id=None,
        current_cafe_name=None,
    ):
        self.current_user_id = current_user_id
        self.current_user_name = current_user_name
        self.current_user_role = current_user_role
        self.current_cafe_id = current_cafe_id
        self.current_cafe_name = current_cafe_name

    def logout(self):
        self.clear()

    def is_logged_in(self):
        return bool(self.current_user_id)

    def is_platform_admin(self):
        return self.current_user_role == "platform_admin"

    def is_cafe_owner(self):
        return self.current_user_role == "cafe_owner"

    def get_current_cafe(self):
        if not self.current_cafe_id:
            return None
        return {
            "cafe_id": self.current_cafe_id,
            "cafe_name": self.current_cafe_name,
        }


session = Session()
