"""Helpers for the CaféSync onboarding wizard and café setup state.

This module keeps the setup journey simple and file-based while preserving the
platform admin and café owner data separation rules introduced in Phase 2.
"""

from __future__ import annotations

import logging
import re
import shutil
from pathlib import Path

import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"

EMAIL_RE = re.compile(r"[^@\s]+@[^@\s]+\.[^@\s]+")

CSV_FILES = {
    "menu": [
        "item_id",
        "cafe_id",
        "item_name",
        "category",
        "price",
    ],
    "inventory": [
        "ingredient_id",
        "cafe_id",
        "ingredient_name",
        "quantity",
        "unit",
        "min_stock",
    ],
    "recipes": [
        "recipe_id",
        "cafe_id",
        "item_id",
        "ingredient",
        "quantity",
        "unit",
    ],
    "suppliers": [
        "supplier_id",
        "cafe_id",
        "supplier_name",
        "phone",
        "email",
        "category",
    ],
    "orders": [
        "order_id",
        "cafe_id",
        "date",
        "time",
        "item_id",
        "quantity",
        "total",
    ],
    "purchases": [
        "purchase_id",
        "cafe_id",
        "date",
        "supplier_id",
        "ingredient",
        "quantity",
        "unit",
        "cost",
    ],
    "waste": [
        "waste_id",
        "cafe_id",
        "date",
        "ingredient",
        "quantity",
        "unit",
        "reason",
    ],
}


def _resolve_data_path(file_name: str):
    """Return the actual CSV path for a logical table name, even if a directory exists."""
    if file_name.lower().endswith(".csv"):
        return DATA_DIR / file_name
    return DATA_DIR / f"{file_name}.csv"


def _backup_malformed_csv(path: Path):
    """Preserve malformed CSV data before repairing the file schema."""
    if not path.exists():
        return None
    backup_path = path.with_name(f"{path.name}.bak")
    timestamp = 1
    while backup_path.exists():
        backup_path = path.with_name(f"{path.name}.{timestamp}.bak")
        timestamp += 1
    shutil.copy2(path, backup_path)
    return backup_path


def ensure_file_columns(file_name: str, columns):
    """Create a CSV if needed and add any missing required columns safely."""
    path = _resolve_data_path(file_name)
    path.parent.mkdir(parents=True, exist_ok=True)

    if path.exists() and path.is_dir():
        raise ValueError(f"Expected a CSV file at {path}, but found a directory instead.")

    if not path.exists():
        empty = pd.DataFrame(columns=columns)
        empty.to_csv(path, index=False)
        return empty

    try:
        df = pd.read_csv(path)
    except Exception as exc:
        backup_path = _backup_malformed_csv(path)
        logging.warning("Malformed CSV %s was backed up to %s before schema repair: %s", path, backup_path, exc)
        df = pd.DataFrame(columns=columns)
    else:
        if not set(columns).intersection(df.columns):
            backup_path = _backup_malformed_csv(path)
            logging.warning("CSV %s did not contain any expected columns; backed up to %s and reset to the required schema.", path, backup_path)
            df = pd.DataFrame(columns=columns)

    for column in columns:
        if column not in df.columns:
            df[column] = ""

    ordered_columns = list(columns)
    for column in df.columns:
        if column not in ordered_columns:
            ordered_columns.append(column)

    df = df.reindex(columns=ordered_columns)
    df.to_csv(path, index=False)
    return df


def ensure_setup_files():
    """Ensure all onboarding-capable CSV files have safe schema definitions."""
    for file_name, columns in CSV_FILES.items():
        ensure_file_columns(f"{file_name}.csv", columns)

    # Ensure cafés include onboarding metadata needed by the setup wizard.
    cafe_path = DATA_DIR / "cafes.csv"
    if cafe_path.exists():
        cafes = pd.read_csv(cafe_path)
        for column in [
            "cafe_type",
            "opening_date",
            "opening_time",
            "closing_time",
            "setup_completed",
            "setup_progress",
            "quick_start_completed",
            "quick_start_progress",
            "optional_setup_progress",
            "onboarding_dismissed",
            "feature_readiness",
        ]:
            if column not in cafes.columns:
                cafes[column] = ""
        cafes.to_csv(cafe_path, index=False)


ensure_setup_files()


def get_file_df(file_name: str):
    key = file_name if file_name.endswith(".csv") else file_name
    if key.endswith(".csv"):
        base_name = key[:-4]
    else:
        base_name = key
    return ensure_file_columns(f"{base_name}.csv", CSV_FILES[base_name])


def generate_id(prefix: str, file_name: str, id_column: str):
    """Generate IDs in a predictable pattern like MI001, I001, R001."""
    df = get_file_df(file_name)
    if df.empty:
        return f"{prefix}001"

    values = []
    for value in df[id_column].astype(str):
        if value.startswith(prefix) and value[len(prefix):].isdigit():
            values.append(int(value[len(prefix):]))

    next_number = max(values, default=0) + 1
    return f"{prefix}{next_number:03d}"


def get_menu_for_cafe(cafe_id):
    df = get_file_df("menu")
    if df.empty:
        return df
    return df[df["cafe_id"].astype(str) == str(cafe_id)].reset_index(drop=True)


def _is_valid_positive_number(value):
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return False
    return parsed >= 0


def save_menu_item(cafe_id, item_name, category, price):
    """Add a menu item to the current café's menu."""
    item_name = str(item_name).strip()
    category = str(category).strip()
    if not item_name or not category:
        return {"success": False, "message": "Item name and category are required."}

    try:
        price_value = float(price)
    except (TypeError, ValueError):
        return {"success": False, "message": "Please enter a valid price."}

    if price_value <= 0:
        return {"success": False, "message": "Price must be greater than zero."}

    df = get_file_df("menu")
    duplicate = df[
        (df["cafe_id"].astype(str) == str(cafe_id))
        & (df["item_name"].astype(str).str.lower() == item_name.lower())
    ]
    if not duplicate.empty:
        return {"success": False, "message": "This menu item already exists for this café."}

    new_row = {
        "item_id": generate_id("MI", "menu", "item_id"),
        "cafe_id": cafe_id,
        "item_name": item_name,
        "category": category,
        "price": float(price_value),
    }
    df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
    df.to_csv(DATA_DIR / "menu.csv", index=False)
    return {"success": True, "message": "Menu item added successfully.", "item_id": new_row["item_id"]}


def get_inventory_for_cafe(cafe_id):
    df = get_file_df("inventory")
    if df.empty:
        return df
    return df[df["cafe_id"].astype(str) == str(cafe_id)].reset_index(drop=True)


def save_ingredient(cafe_id, ingredient_name, unit, min_stock):
    """Add or update an ingredient entry for the current café."""
    ingredient_name = str(ingredient_name).strip()
    unit = str(unit).strip()
    if not ingredient_name or not unit:
        return {"success": False, "message": "Ingredient name and unit are required."}

    try:
        min_value = float(min_stock)
    except (TypeError, ValueError):
        return {"success": False, "message": "Please enter a valid minimum stock level."}

    if min_value < 0:
        return {"success": False, "message": "Minimum stock cannot be negative."}

    df = get_file_df("inventory")
    existing = df[(df["cafe_id"].astype(str) == str(cafe_id)) & (df["ingredient_name"].astype(str).str.lower() == ingredient_name.lower())]
    if not existing.empty:
        df.loc[existing.index, "unit"] = unit
        df.loc[existing.index, "min_stock"] = min_value
        df.to_csv(DATA_DIR / "inventory.csv", index=False)
        return {"success": True, "message": "Ingredient updated successfully."}

    new_row = {
        "ingredient_id": generate_id("I", "inventory", "ingredient_id"),
        "cafe_id": cafe_id,
        "ingredient_name": ingredient_name,
        "quantity": 0,
        "unit": unit,
        "min_stock": min_value,
    }
    df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
    df.to_csv(DATA_DIR / "inventory.csv", index=False)
    return {"success": True, "message": "Ingredient added successfully.", "ingredient_id": new_row["ingredient_id"]}


def update_opening_stock(cafe_id, ingredient_name, quantity, unit="kg"):
    """Set the opening stock quantity for a specific ingredient."""
    ingredient_name = str(ingredient_name).strip()
    if not ingredient_name:
        return {"success": False, "message": "Ingredient name is required."}

    try:
        quantity_value = float(quantity)
    except (TypeError, ValueError):
        return {"success": False, "message": "Please enter a valid quantity."}

    if quantity_value < 0:
        return {"success": False, "message": "Quantity cannot be negative."}

    df = get_file_df("inventory")
    matching = df[(df["cafe_id"].astype(str) == str(cafe_id)) & (df["ingredient_name"].astype(str).str.lower() == ingredient_name.lower())]
    if matching.empty:
        return {"success": False, "message": "Ingredient must be added before setting opening stock."}

    df.loc[matching.index, "quantity"] = quantity_value
    df.loc[matching.index, "unit"] = str(unit).strip() or matching.iloc[0].get("unit", "kg")
    df.to_csv(DATA_DIR / "inventory.csv", index=False)
    return {"success": True, "message": "Opening stock saved successfully."}


def get_recipes_for_cafe(cafe_id):
    df = get_file_df("recipes")
    if df.empty:
        return df
    return df[df["cafe_id"].astype(str) == str(cafe_id)].reset_index(drop=True)


def save_recipe(cafe_id, item_id, ingredient, quantity, unit):
    """Save a recipe ingredient mapping for a café and menu item."""
    if not item_id or not ingredient or not quantity or not unit:
        return {"success": False, "message": "Please complete all recipe fields."}

    try:
        quantity_value = float(quantity)
    except (TypeError, ValueError):
        return {"success": False, "message": "Please enter a valid quantity."}

    if quantity_value <= 0:
        return {"success": False, "message": "Recipe quantity must be greater than zero."}

    df = get_file_df("recipes")
    new_row = {
        "recipe_id": generate_id("R", "recipes", "recipe_id"),
        "cafe_id": cafe_id,
        "item_id": item_id,
        "ingredient": ingredient,
        "quantity": float(quantity_value),
        "unit": unit,
    }
    df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
    df.to_csv(DATA_DIR / "recipes.csv", index=False)
    return {"success": True, "message": "Recipe ingredient added successfully."}


def get_suppliers_for_cafe(cafe_id):
    df = get_file_df("suppliers")
    if df.empty:
        return df
    return df[df["cafe_id"].astype(str) == str(cafe_id)].reset_index(drop=True)


def save_supplier(cafe_id, supplier_name, phone, email, category):
    """Add a supplier record for the current café."""
    supplier_name = str(supplier_name).strip()
    category = str(category).strip()
    if not supplier_name or not phone or not category:
        return {"success": False, "message": "Supplier name, phone, and category are required."}

    digits = re.sub(r"\D", "", str(phone).strip())
    if len(digits) < 10:
        return {"success": False, "message": "Please enter a valid phone number."}

    email_value = str(email or "").strip()
    if email_value and not EMAIL_RE.fullmatch(email_value):
        return {"success": False, "message": "Please enter a valid supplier email."}

    df = get_file_df("suppliers")
    duplicate = df[(df["cafe_id"].astype(str) == str(cafe_id)) & (df["supplier_name"].astype(str).str.lower() == supplier_name.lower())]
    if not duplicate.empty:
        return {"success": False, "message": "This supplier already exists for this café."}

    new_row = {
        "supplier_id": generate_id("S", "suppliers", "supplier_id"),
        "cafe_id": cafe_id,
        "supplier_name": supplier_name,
        "phone": phone,
        "email": email_value,
        "category": category,
    }
    df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
    df.to_csv(DATA_DIR / "suppliers.csv", index=False)
    return {"success": True, "message": "Supplier added successfully."}


def get_demo_menu_items():
    """Return the starter menu catalog used in the quick-start flow."""
    return [
        ("Signature Latte", "Coffee", 180),
        ("Cappuccino", "Coffee", 200),
        ("Veg Sandwich", "Breakfast", 220),
        ("Brownie", "Dessert", 140),
    ]


def seed_demo_menu_items(cafe_id):
    """Populate a demo starter menu for a café if no menu items exist yet."""
    cafe_id = str(cafe_id)
    df = get_file_df("menu")
    if not df.empty:
        existing = df[df["cafe_id"].astype(str) == cafe_id]
        if not existing.empty:
            return {"success": True, "message": "Demo menu items are already available for this café.", "added": 0}

    added = 0
    for item_name, category, price in get_demo_menu_items():
        result = save_menu_item(cafe_id, item_name, category, price)
        if result.get("success"):
            added += 1

    return {"success": True, "message": f"Added {added} demo menu items for this café.", "added": added}


def get_optional_setup_status(cafe_id):
    """Return optional setup completion data based on persisted records."""
    menu = get_menu_for_cafe(cafe_id)
    ingredients = get_inventory_for_cafe(cafe_id)
    recipes = get_recipes_for_cafe(cafe_id)
    suppliers = get_suppliers_for_cafe(cafe_id)
    opening_stock_complete = not ingredients.empty and bool((pd.to_numeric(ingredients["quantity"], errors="coerce").fillna(0) > 0).any())

    checklist = {
        "menu_items": not menu.empty,
        "ingredients": not ingredients.empty,
        "recipes": not recipes.empty,
        "opening_stock": opening_stock_complete,
        "suppliers": not suppliers.empty,
    }
    complete_count = sum(1 for value in checklist.values() if value)
    progress = int(round((complete_count / len(checklist)) * 100)) if checklist else 0
    return checklist, progress


def normalize_csv_value(value):
    """Convert pandas/CSV missing values into a clean empty string."""
    if value is None or pd.isna(value):
        return ""
    return str(value).strip()


def get_setup_status(cafe_id):
    """Return quick-start completion, optional setup progress, and feature readiness for a café."""
    cafe_path = DATA_DIR / "cafes.csv"
    default = {
        "setup_completed": False,
        "setup_progress": 0,
        "quick_start_completed": False,
        "quick_start_progress": 0,
        "optional_setup_progress": 0,
        "optional_tasks_completed": 0,
        "optional_tasks_total": 5,
        "profile_complete": False,
        "menu_complete": False,
        "ingredients_complete": False,
        "recipes_complete": False,
        "opening_stock_complete": False,
        "suppliers_complete": False,
        "feature_readiness": {
            "stock_deductions_ready": False,
            "inventory_reports_ready": False,
            "supplier_purchases_ready": False,
        },
    }
    if not cafe_path.exists():
        return default

    cafes = pd.read_csv(cafe_path)
    if "cafe_id" not in cafes.columns:
        return default

    if "quick_start_completed" not in cafes.columns:
        cafes["quick_start_completed"] = ""
    if "quick_start_progress" not in cafes.columns:
        cafes["quick_start_progress"] = ""
    if "optional_setup_progress" not in cafes.columns:
        cafes["optional_setup_progress"] = ""
    if "onboarding_dismissed" not in cafes.columns:
        cafes["onboarding_dismissed"] = False
    if "feature_readiness" not in cafes.columns:
        cafes["feature_readiness"] = ""

    row = cafes[cafes["cafe_id"].astype(str) == str(cafe_id)]
    if row.empty:
        return default

    record = row.iloc[0]
    cafe_name = normalize_csv_value(record.get("cafe_name", ""))
    location = normalize_csv_value(record.get("location", ""))
    profile_complete = bool(cafe_name and location)

    menu = get_menu_for_cafe(cafe_id)
    ingredients = get_inventory_for_cafe(cafe_id)
    recipes = get_recipes_for_cafe(cafe_id)
    suppliers = get_suppliers_for_cafe(cafe_id)
    opening_stock_complete = not ingredients.empty and bool((pd.to_numeric(ingredients["quantity"], errors="coerce").fillna(0) > 0).any())

    optional_status, optional_progress = get_optional_setup_status(cafe_id)
    quick_start_complete = profile_complete
    quick_start_progress = 100 if quick_start_complete else 0

    feature_readiness = {
        "stock_deductions_ready": bool(not menu.empty and not recipes.empty and not ingredients.empty),
        "inventory_reports_ready": bool(not ingredients.empty),
        "supplier_purchases_ready": bool(not suppliers.empty),
    }

    cafes["quick_start_completed"] = cafes["quick_start_completed"].astype(object)
    cafes["onboarding_dismissed"] = cafes["onboarding_dismissed"].astype(object)
    cafes["feature_readiness"] = cafes["feature_readiness"].astype(object)

    cafes.loc[row.index, "setup_completed"] = bool(quick_start_complete)
    cafes.loc[row.index, "setup_progress"] = quick_start_progress
    cafes.loc[row.index, "quick_start_completed"] = bool(quick_start_complete)
    cafes.loc[row.index, "quick_start_progress"] = quick_start_progress
    cafes.loc[row.index, "optional_setup_progress"] = int(optional_progress)
    onboarding_dismissed = normalize_csv_value(record.get("onboarding_dismissed", "False")).lower() in {"true", "1", "yes"}
    cafes.loc[row.index, "onboarding_dismissed"] = bool(onboarding_dismissed)
    cafes.loc[row.index, "feature_readiness"] = str(feature_readiness)
    cafes.to_csv(cafe_path, index=False)

    result = {
        "setup_completed": quick_start_complete,
        "setup_progress": quick_start_progress,
        "quick_start_completed": quick_start_complete,
        "quick_start_progress": quick_start_progress,
        "optional_setup_progress": int(optional_progress),
        "optional_tasks_completed": sum(1 for value in optional_status.values() if value),
        "optional_tasks_total": len(optional_status),
        "feature_readiness": feature_readiness,
        "profile_complete": profile_complete,
        "menu_complete": not menu.empty,
        "ingredients_complete": not ingredients.empty,
        "recipes_complete": not recipes.empty,
        "opening_stock_complete": opening_stock_complete,
        "suppliers_complete": not suppliers.empty,
    }
    return result


def update_cafe_profile(cafe_id, cafe_name, location, phone, cafe_type, opening_date, opening_time, closing_time):
    """Update the café profile in cafes.csv."""
    cafe_path = DATA_DIR / "cafes.csv"
    if not cafe_path.exists():
        return {"success": False, "message": "Café profile file is missing."}

    cafes = pd.read_csv(cafe_path)
    mask = cafes["cafe_id"].astype(str) == str(cafe_id)
    if not mask.any():
        return {"success": False, "message": "Café record not found."}

    cafes.loc[mask, "cafe_name"] = cafe_name
    cafes.loc[mask, "location"] = location
    cafes.loc[mask, "phone"] = phone
    cafes.loc[mask, "cafe_type"] = cafe_type
    cafes.loc[mask, "opening_date"] = opening_date
    cafes.loc[mask, "opening_time"] = opening_time
    cafes.loc[mask, "closing_time"] = closing_time
    cafes.to_csv(cafe_path, index=False)

    status = get_setup_status(cafe_id)
    return {"success": True, "message": "Café profile updated successfully.", "status": status}


def mark_setup_complete(cafe_id, completed=True):
    """Mark setup status for the current café."""
    cafe_path = DATA_DIR / "cafes.csv"
    if not cafe_path.exists():
        return False

    cafes = pd.read_csv(cafe_path)
    if "cafe_id" not in cafes.columns:
        return False

    mask = cafes["cafe_id"].astype(str) == str(cafe_id)
    if not mask.any():
        return False

    cafes.loc[mask, "setup_completed"] = bool(completed)
    cafes.loc[mask, "setup_progress"] = 100 if completed else get_setup_status(cafe_id)["setup_progress"]
    cafes.loc[mask, "quick_start_completed"] = bool(completed)
    cafes.loc[mask, "quick_start_progress"] = 100 if completed else get_setup_status(cafe_id)["quick_start_progress"]
    cafes.loc[mask, "optional_setup_progress"] = int(get_setup_status(cafe_id).get("optional_setup_progress", 0))
    cafes.to_csv(cafe_path, index=False)
    return True


def set_onboarding_dismissed(cafe_id, dismissed=True):
    """Persist the dashboard onboarding checklist dismissal state for this café."""
    cafe_path = DATA_DIR / "cafes.csv"
    if not cafe_path.exists():
        return False

    cafes = pd.read_csv(cafe_path)
    if "cafe_id" not in cafes.columns:
        return False

    mask = cafes["cafe_id"].astype(str) == str(cafe_id)
    if not mask.any():
        return False

    cafes.loc[mask, "onboarding_dismissed"] = bool(dismissed)
    cafes.to_csv(cafe_path, index=False)
    return True
