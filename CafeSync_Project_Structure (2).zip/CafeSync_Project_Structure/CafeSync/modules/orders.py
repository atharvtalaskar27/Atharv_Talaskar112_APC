"""Orders and order-line persistence for CaféSync.

This module keeps the current CSV-first architecture and adds a safe, tenant-aware
order workflow that records historical snapshots of menu item names and prices.
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path

import pandas as pd

from modules.menu import list_menu_items

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
ORDERS_PATH = DATA_DIR / "orders.csv"
ORDER_ITEMS_PATH = DATA_DIR / "order_items.csv"

ORDER_COLUMNS = [
    "order_id",
    "cafe_id",
    "created_at",
    "order_status",
    "subtotal",
    "tax_amount",
    "discount_amount",
    "total_amount",
    "item_count",
    "cancelled_at",
    "notes",
]

ORDER_ITEM_COLUMNS = [
    "line_id",
    "order_id",
    "cafe_id",
    "menu_item_id",
    "item_name_snapshot",
    "unit_price_snapshot",
    "quantity",
    "line_total",
    "created_at",
]


def _ensure_data_dir():
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def _read_orders_df():
    _ensure_data_dir()
    if not ORDERS_PATH.exists():
        pd.DataFrame(columns=ORDER_COLUMNS).to_csv(ORDERS_PATH, index=False)
        return pd.DataFrame(columns=ORDER_COLUMNS)
    try:
        df = pd.read_csv(ORDERS_PATH)
    except Exception:
        return pd.DataFrame(columns=ORDER_COLUMNS)

    for column in ORDER_COLUMNS:
        if column not in df.columns:
            df[column] = ""
    df = df.reindex(columns=ORDER_COLUMNS)
    df.to_csv(ORDERS_PATH, index=False)
    return df


def _read_order_items_df():
    _ensure_data_dir()
    if not ORDER_ITEMS_PATH.exists():
        pd.DataFrame(columns=ORDER_ITEM_COLUMNS).to_csv(ORDER_ITEMS_PATH, index=False)
        return pd.DataFrame(columns=ORDER_ITEM_COLUMNS)
    try:
        df = pd.read_csv(ORDER_ITEMS_PATH)
    except Exception:
        return pd.DataFrame(columns=ORDER_ITEM_COLUMNS)

    for column in ORDER_ITEM_COLUMNS:
        if column not in df.columns:
            df[column] = ""
    df = df.reindex(columns=ORDER_ITEM_COLUMNS)
    df.to_csv(ORDER_ITEMS_PATH, index=False)
    return df


def _decimal(value):
    try:
        return Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError("Invalid numeric value.")


def _currency(value):
    return float(Decimal(str(value)).quantize(Decimal("0.01")))


def _generate_order_id():
    orders = _read_orders_df()
    if orders.empty:
        return "ORD001"

    values = []
    for value in orders["order_id"].fillna("").astype(str):
        if value.startswith("ORD") and value[3:].isdigit():
            values.append(int(value[3:]))
    next_num = max(values, default=0) + 1
    return f"ORD{next_num:03d}"


def _generate_line_id():
    items = _read_order_items_df()
    if items.empty:
        return "LI001"

    values = []
    for value in items["line_id"].fillna("").astype(str):
        if value.startswith("LI") and value[2:].isdigit():
            values.append(int(value[2:]))
    next_num = max(values, default=0) + 1
    return f"LI{next_num:03d}"


def _normalize_status(value):
    status = str(value or "Completed").strip()
    if status.lower() in {"completed", "complete", "paid"}:
        return "Completed"
    if status.lower() in {"cancelled", "canceled", "cancel"}:
        return "Cancelled"
    return "Completed"


def _menu_for_cafe(cafe_id):
    return list_menu_items(str(cafe_id), availability="Available")


def _build_order_dict(row):
    try:
        subtotal = float(row.get("subtotal", 0) or 0)
        tax_amount = float(row.get("tax_amount", 0) or 0)
        discount_amount = float(row.get("discount_amount", 0) or 0)
        total_amount = float(row.get("total_amount", 0) or 0)
        item_count = int(row.get("item_count", 0) or 0)
    except ValueError:
        subtotal = 0.0
        tax_amount = 0.0
        discount_amount = 0.0
        total_amount = 0.0
        item_count = 0

    return {
        "order_id": str(row.get("order_id") or "").strip(),
        "cafe_id": str(row.get("cafe_id") or "").strip(),
        "created_at": str(row.get("created_at") or "").strip(),
        "order_status": _normalize_status(row.get("order_status")),
        "subtotal": subtotal,
        "tax_amount": tax_amount,
        "discount_amount": discount_amount,
        "total_amount": total_amount,
        "item_count": item_count,
        "cancelled_at": str(row.get("cancelled_at") or "").strip(),
        "notes": str(row.get("notes") or "").strip(),
    }


def create_order(cafe_id, items):
    """Create a completed order from valid, available menu items for the authenticated café."""
    cafe_id = str(cafe_id or "").strip()
    if not cafe_id:
        return {"success": False, "message": "No active café is selected."}

    if not items:
        return {"success": False, "message": "Empty orders are not allowed."}

    menu_rows = list_menu_items(cafe_id)
    menu_map = {str(row["item_id"]): row for row in menu_rows if row.get("is_available")}
    if not menu_map:
        return {"success": False, "message": "No available menu items are configured for this café. Open Menu Management to add products first."}

    valid_lines = []
    subtotal = Decimal("0")
    for entry in items:
        if not isinstance(entry, dict):
            return {"success": False, "message": "Invalid order item format."}
        menu_item_id = str(entry.get("menu_item_id") or "").strip()
        quantity = int(entry.get("quantity") or 0)
        if not menu_item_id:
            return {"success": False, "message": "Each order line must reference a menu item."}
        if quantity <= 0:
            return {"success": False, "message": "Quantity must be a positive integer."}
        if menu_item_id not in menu_map:
            return {"success": False, "message": f"Menu item {menu_item_id} is unavailable or belongs to another café."}

        item = menu_map[menu_item_id]
        unit_price = Decimal(str(item.get("selling_price", 0) or 0))
        line_total = unit_price * Decimal(quantity)
        subtotal += line_total
        valid_lines.append({
            "menu_item_id": menu_item_id,
            "item_name_snapshot": item.get("item_name", ""),
            "unit_price_snapshot": float(unit_price),
            "quantity": quantity,
            "line_total": float(line_total),
        })

    if not valid_lines:
        return {"success": False, "message": "Order items are required before saving."}

    tax_amount = Decimal("0.00")
    discount_amount = Decimal("0.00")
    total_amount = subtotal + tax_amount - discount_amount
    created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    order_id = _generate_order_id()
    item_count = sum(line["quantity"] for line in valid_lines)

    orders_df = _read_orders_df()
    orders_df = pd.concat(
        [orders_df.reindex(columns=ORDER_COLUMNS), pd.DataFrame([{
            "order_id": order_id,
            "cafe_id": cafe_id,
            "created_at": created_at,
            "order_status": "Completed",
            "subtotal": _currency(subtotal),
            "tax_amount": _currency(tax_amount),
            "discount_amount": _currency(discount_amount),
            "total_amount": _currency(total_amount),
            "item_count": item_count,
            "cancelled_at": "",
            "notes": "",
        }], columns=ORDER_COLUMNS)], ignore_index=True, sort=False)
    orders_df.to_csv(ORDERS_PATH, index=False)

    line_rows = []
    for line in valid_lines:
        line_rows.append({
            "line_id": _generate_line_id(),
            "order_id": order_id,
            "cafe_id": cafe_id,
            "menu_item_id": line["menu_item_id"],
            "item_name_snapshot": line["item_name_snapshot"],
            "unit_price_snapshot": line["unit_price_snapshot"],
            "quantity": line["quantity"],
            "line_total": line["line_total"],
            "created_at": created_at,
        })

    items_df = _read_order_items_df()
    items_df = pd.concat(
        [items_df.reindex(columns=ORDER_ITEM_COLUMNS), pd.DataFrame(line_rows, columns=ORDER_ITEM_COLUMNS)],
        ignore_index=True,
        sort=False,
    )
    items_df.to_csv(ORDER_ITEMS_PATH, index=False)

    order = _build_order_dict({
        "order_id": order_id,
        "cafe_id": cafe_id,
        "created_at": created_at,
        "order_status": "Completed",
        "subtotal": _currency(subtotal),
        "tax_amount": _currency(tax_amount),
        "discount_amount": _currency(discount_amount),
        "total_amount": _currency(total_amount),
        "item_count": item_count,
        "cancelled_at": "",
        "notes": "",
    })
    return {"success": True, "message": "Order saved successfully.", "order": order, "line_items": line_rows}


def list_orders(cafe_id, search="", status="All", date_filter="All"):
    cafe_id = str(cafe_id or "").strip()
    orders_df = _read_orders_df()
    if orders_df.empty:
        return []

    filtered = orders_df[orders_df["cafe_id"].astype(str) == cafe_id].copy()
    if filtered.empty:
        return []

    if search:
        term = str(search).strip().lower()
        filtered = filtered[
            filtered["order_id"].fillna("").astype(str).str.lower().str.contains(term, na=False)
            | filtered["notes"].fillna("").astype(str).str.lower().str.contains(term, na=False)
        ]

    if status != "All":
        filtered = filtered[filtered["order_status"].fillna("").astype(str).str.lower() == str(status).strip().lower()]

    if date_filter == "Today":
        today = datetime.now().strftime("%Y-%m-%d")
        filtered = filtered[filtered["created_at"].astype(str).str.startswith(today)]
    elif date_filter == "7 Days":
        filtered = filtered[filtered["created_at"].astype(str).str.len() > 0]

    filtered = filtered.sort_values(by=["created_at"], ascending=False).reset_index(drop=True)
    return [_build_order_dict(row.to_dict()) for _, row in filtered.iterrows()]


def get_order_detail(cafe_id, order_id):
    cafe_id = str(cafe_id or "").strip()
    order_id = str(order_id or "").strip()
    orders_df = _read_orders_df()
    order_row = orders_df[(orders_df["cafe_id"].astype(str) == cafe_id) & (orders_df["order_id"].astype(str) == order_id)]
    if order_row.empty:
        return {"success": False, "message": "Order not found."}

    line_items_df = _read_order_items_df()
    lines = line_items_df[(line_items_df["cafe_id"].astype(str) == cafe_id) & (line_items_df["order_id"].astype(str) == order_id)]
    order = _build_order_dict(order_row.iloc[0].to_dict())
    order_lines = []
    for _, row in lines.iterrows():
        order_lines.append({
            "line_id": str(row.get("line_id") or "").strip(),
            "menu_item_id": str(row.get("menu_item_id") or "").strip(),
            "item_name_snapshot": str(row.get("item_name_snapshot") or "").strip(),
            "unit_price_snapshot": float(row.get("unit_price_snapshot") or 0),
            "quantity": int(row.get("quantity") or 0),
            "line_total": float(row.get("line_total") or 0),
        })
    return {"success": True, "order": order, "line_items": order_lines}


def cancel_order(cafe_id, order_id):
    cafe_id = str(cafe_id or "").strip()
    order_id = str(order_id or "").strip()
    orders_df = _read_orders_df()
    mask = (orders_df["cafe_id"].astype(str) == cafe_id) & (orders_df["order_id"].astype(str) == order_id)
    if not mask.any():
        return {"success": False, "message": "Order not found."}

    current_status = str(orders_df.loc[mask, "order_status"].iloc[0] or "").strip()
    if str(current_status).lower() == "cancelled":
        return {"success": False, "message": "This order is already cancelled."}

    orders_df.loc[mask, "order_status"] = "Cancelled"
    orders_df.loc[mask, "cancelled_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    orders_df.to_csv(ORDERS_PATH, index=False)
    detail = get_order_detail(cafe_id, order_id)
    return {"success": True, "message": "Order cancelled successfully.", "order": detail["order"]}


def get_order_summary(cafe_id):
    cafe_id = str(cafe_id or "").strip()
    rows = list_orders(cafe_id)
    total_orders = len(rows)
    today = datetime.now().strftime("%Y-%m-%d")
    today_orders = sum(1 for row in rows if str(row["created_at"]).startswith(today))
    completed = [row for row in rows if row["order_status"] == "Completed"]
    today_sales = sum(float(row["total_amount"]) for row in completed if str(row["created_at"]).startswith(today))
    average_order_value = (sum(float(row["total_amount"]) for row in completed) / len(completed)) if completed else 0.0
    return {
        "total_orders": total_orders,
        "today_orders": today_orders,
        "today_sales": float(today_sales),
        "average_order_value": float(average_order_value),
    }


__all__ = [
    "cancel_order",
    "create_order",
    "get_order_detail",
    "get_order_summary",
    "list_orders",
]
