"""Platform audit trail for CaféSync.

This module keeps the activity log in CSV format with a consistent schema so the
platform admin can inspect who changed what, when, and whether the action
succeeded.
"""

from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
ACTIVITY_FILE = DATA_DIR / "platform_activity.csv"

EXPECTED_COLUMNS = [
    "activity_id",
    "timestamp",
    "actor_id",
    "actor_name",
    "actor_role",
    "action",
    "target_type",
    "target_id",
    "target_name",
    "status",
    "details",
]


def _read_activity_df():
    if not ACTIVITY_FILE.exists():
        return pd.DataFrame(columns=EXPECTED_COLUMNS)
    try:
        return pd.read_csv(ACTIVITY_FILE)
    except Exception:
        return pd.DataFrame(columns=EXPECTED_COLUMNS)


def _parse_activity_timestamp(value):
    text = str(value or "").strip()
    if not text:
        return ""
    try:
        return pd.to_datetime(text, errors="raise").strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        try:
            parsed = datetime.strptime(text, "%d %b %Y %H:%M")
            return parsed.strftime("%Y-%m-%d %H:%M:%S")
        except Exception:
            return text


def _extract_target_from_message(message):
    text = str(message or "")
    match = re.search(r"([A-Z]+-\d+|C\d{3})", text)
    cafe_id = match.group(1) if match else ""
    name_match = re.search(r"\(([^)]+)\)", text)
    cafe_name = name_match.group(1) if name_match else ""
    return cafe_id, cafe_name


def _migrate_legacy_activity_file():
    if not ACTIVITY_FILE.exists():
        pd.DataFrame(columns=EXPECTED_COLUMNS).to_csv(ACTIVITY_FILE, index=False)
        return

    df = _read_activity_df()
    if df.empty and list(df.columns) == []:
        pd.DataFrame(columns=EXPECTED_COLUMNS).to_csv(ACTIVITY_FILE, index=False)
        return

    if set(EXPECTED_COLUMNS).issubset(df.columns):
        for col in EXPECTED_COLUMNS:
            if col not in df.columns:
                df[col] = ""
        df = df.reindex(columns=EXPECTED_COLUMNS)
        df.to_csv(ACTIVITY_FILE, index=False)
        return

    migrated_rows = []
    for row in df.to_dict("records"):
        legacy_message = str(row.get("message", "")).strip()
        timestamp = _parse_activity_timestamp(row.get("timestamp", ""))
        actor_id = str(row.get("actor_id", "")).strip()
        actor_name = str(row.get("actor_name", "")).strip() or "Platform Admin"
        actor_role = str(row.get("actor_role", "platform_admin")).strip() or "platform_admin"
        action = "UNKNOWN"
        if "deactivated" in legacy_message.lower():
            action = "DEACTIVATE_CAFE"
        elif "reactivated" in legacy_message.lower():
            action = "REACTIVATE_CAFE"
        elif "registered" in legacy_message.lower():
            action = "CAFE_REGISTERED"
        elif "logged in" in legacy_message.lower():
            action = "ADMIN_LOGIN"
        elif "logged out" in legacy_message.lower():
            action = "ADMIN_LOGOUT"
        elif "activated" in legacy_message.lower():
            action = "ACTIVATE_CAFE"
        target_id, target_name = _extract_target_from_message(legacy_message)
        migrated_rows.append({
            "activity_id": f"ACT-{len(migrated_rows) + 1:03d}",
            "timestamp": timestamp or pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S"),
            "actor_id": actor_id,
            "actor_name": actor_name,
            "actor_role": actor_role,
            "action": action,
            "target_type": "CAFE" if target_id or "cafe" in legacy_message.lower() else "SYSTEM",
            "target_id": target_id,
            "target_name": target_name,
            "status": "SUCCESS",
            "details": legacy_message,
        })

    if migrated_rows:
        pd.DataFrame(migrated_rows, columns=EXPECTED_COLUMNS).to_csv(ACTIVITY_FILE, index=False)
    else:
        pd.DataFrame(columns=EXPECTED_COLUMNS).to_csv(ACTIVITY_FILE, index=False)


def ensure_activity_file():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    _migrate_legacy_activity_file()
    df = _read_activity_df()
    if df.empty:
        pd.DataFrame(columns=EXPECTED_COLUMNS).to_csv(ACTIVITY_FILE, index=False)
        return pd.DataFrame(columns=EXPECTED_COLUMNS)
    for col in EXPECTED_COLUMNS:
        if col not in df.columns:
            df[col] = ""
    df = df.reindex(columns=EXPECTED_COLUMNS)
    df.to_csv(ACTIVITY_FILE, index=False)
    return df


ensure_activity_file()


def generate_activity_id():
    df = _read_activity_df()
    if df.empty:
        return "ACT-001"

    ids = []
    for value in df["activity_id"].astype(str):
        if value.startswith("ACT-") and value[4:].isdigit():
            ids.append(int(value[4:]))
    next_id = max(ids, default=0) + 1
    return f"ACT-{next_id:03d}"


def record_platform_activity(
    actor_id,
    actor_name,
    actor_role,
    action,
    target_type,
    target_id,
    target_name,
    status,
    details,
):
    """Append a platform activity record while preserving the audit trail."""
    ensure_activity_file()
    df = _read_activity_df()

    row = {
        "activity_id": generate_activity_id(),
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "actor_id": str(actor_id or "").strip(),
        "actor_name": str(actor_name or "Platform Admin").strip(),
        "actor_role": str(actor_role or "platform_admin").strip(),
        "action": str(action or "UNKNOWN").upper().strip(),
        "target_type": str(target_type or "SYSTEM").upper().strip(),
        "target_id": str(target_id or "").strip(),
        "target_name": str(target_name or "").strip(),
        "status": str(status or "FAILED").upper().strip(),
        "details": str(details or "").strip(),
    }
    df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
    df = df.reindex(columns=EXPECTED_COLUMNS)
    df.to_csv(ACTIVITY_FILE, index=False)
    return row


def list_platform_activity(
    search="",
    action_filter="All",
    status_filter="All",
    actor_filter="All",
    date_filter="All",
):
    """Return filtered activity rows for the admin UI."""
    df = _read_activity_df()
    if df.empty:
        return []

    rows = df.copy()
    rows["timestamp"] = rows["timestamp"].astype(str)
    rows["action"] = rows["action"].astype(str)
    rows["status"] = rows["status"].astype(str)
    rows["actor_name"] = rows["actor_name"].astype(str)
    rows["target_name"] = rows["target_name"].astype(str)
    rows["actor_id"] = rows["actor_id"].astype(str)
    rows["target_id"] = rows["target_id"].astype(str)
    rows["details"] = rows["details"].astype(str)

    if search:
        query = search.lower()
        mask = rows["actor_name"].str.lower().str.contains(query, na=False) | \
               rows["actor_id"].str.lower().str.contains(query, na=False) | \
               rows["action"].str.lower().str.contains(query, na=False) | \
               rows["target_name"].str.lower().str.contains(query, na=False) | \
               rows["target_id"].str.lower().str.contains(query, na=False) | \
               rows["details"].str.lower().str.contains(query, na=False)
        rows = rows[mask].copy()

    if action_filter != "All":
        rows = rows[rows["action"].str.upper() == action_filter.upper()]

    if status_filter != "All":
        rows = rows[rows["status"].str.upper() == status_filter.upper()]

    if actor_filter != "All":
        rows = rows[rows["actor_role"].astype(str).str.lower() == actor_filter.lower()]

    if date_filter != "All":
        today = pd.Timestamp.now().normalize()
        if date_filter == "Today":
            rows = rows[rows["timestamp"].apply(lambda value: _parse_activity_timestamp(value)).str.startswith(today.strftime("%Y-%m-%d"))]
        elif date_filter == "Last 7 Days":
            window = today - pd.Timedelta(days=6)
            parsed = rows["timestamp"].apply(_parse_activity_timestamp)
            rows = rows[pd.to_datetime(parsed, errors="coerce") >= window]
        elif date_filter == "Last 30 Days":
            window = today - pd.Timedelta(days=29)
            parsed = rows["timestamp"].apply(_parse_activity_timestamp)
            rows = rows[pd.to_datetime(parsed, errors="coerce") >= window]

    rows = rows.sort_values(by="timestamp", ascending=False, kind="mergesort")
    return rows.to_dict("records")


def get_platform_activity_summary():
    df = _read_activity_df()
    if df.empty:
        return {"total": 0, "today": 0, "cafe_changes": 0, "admin_actions": 0}

    total = len(df)
    today = 0
    cafe_changes = 0
    admin_actions = 0

    for _, row in df.iterrows():
        timestamp = _parse_activity_timestamp(row.get("timestamp", ""))
        if timestamp.startswith(datetime.now().strftime("%Y-%m-%d")):
            today += 1
        action = str(row.get("action", "")).upper()
        if action in {"CAFE_REGISTERED", "ACTIVATE_CAFE", "DEACTIVATE_CAFE", "REACTIVATE_CAFE"}:
            cafe_changes += 1
        if str(row.get("actor_role", "")).strip().lower() == "platform_admin":
            admin_actions += 1

    return {"total": total, "today": today, "cafe_changes": cafe_changes, "admin_actions": admin_actions}


def get_activity_detail(activity_id):
    df = _read_activity_df()
    if df.empty:
        return None
    match = df[df["activity_id"].astype(str) == str(activity_id)]
    if match.empty:
        return None
    return match.iloc[0].to_dict()


def has_platform_activity_access(role):
    return str(role or "").strip().lower() == "platform_admin"


if __name__ == "__main__":
    ensure_activity_file()
    print("platform_activity_ok")
