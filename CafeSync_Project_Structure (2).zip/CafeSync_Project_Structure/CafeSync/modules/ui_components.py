"""Reusable GUI components for the CaféSync desktop dashboard.

This module preserves the Phase 1 layout while adding the session-based access
flow for platform admin and café owners.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict

import customtkinter as ctk
import pandas as pd

from modules.auth import authenticate_user, register_owner_account
from modules.billing import (
    create_bill_from_order,
    export_receipt_pdf,
    get_bill_detail,
    get_bill_summary,
    list_bills,
    list_eligible_orders,
    list_payments,
    record_payment,
)
from modules.cafe_accounts import (
    can_access_cafe_accounts,
    deactivate_cafe_account,
    get_cafe_account_detail,
    get_cafe_account_summary,
    list_cafe_accounts,
    reactivate_cafe_account,
)
from modules.menu import (
    ALLOWED_CATEGORIES,
    add_menu_item,
    archive_menu_item,
    get_menu_summary,
    list_menu_items,
    toggle_item_availability,
    update_menu_item,
)
from modules.cafe_owners import (
    can_access_cafe_owners,
    deactivate_owner_account,
    get_owner_detail,
    get_owner_summary,
    list_owner_accounts,
    reactivate_owner_account,
)
from modules.cafe_manager import get_all_cafes, get_cafes_for_owner, verify_cafe_access
from modules.inventory import (
    add_ingredient,
    get_inventory_dashboard,
    list_ingredients,
    list_stock_movements,
    record_stock_movement,
    update_ingredient,
)
from modules.waste import (
    WASTE_REASONS,
    get_waste_dashboard,
    list_waste_entries,
    record_waste,
)
from modules.platform_activity import (
    get_activity_detail,
    get_platform_activity_summary,
    has_platform_activity_access,
    list_platform_activity,
    record_platform_activity,
)
from modules.orders import cancel_order, create_order, get_order_detail, get_order_summary, list_orders
from modules.purchases import (
    cancel_purchase,
    create_purchase,
    get_purchase_by_id,
    get_purchase_summary,
    list_purchases,
    record_receipt,
    update_purchase_status,
)
from modules.recipes import add_recipe, get_recipe_by_id, get_recipe_dashboard, list_recipes, update_recipe
from modules.reports import (
    export_report_csv,
    get_inventory_report,
    get_menu_cost_report,
    get_overview_report,
    get_purchases_report,
    get_sales_report,
    get_waste_report,
    _resolve_date_range,
)
from modules.session import session
from modules.suppliers import (
    VALID_CATEGORIES,
    add_supplier,
    deactivate_supplier,
    get_supplier_by_id,
    list_suppliers,
    reactivate_supplier,
    update_supplier,
)
from modules.setup_manager import (
    get_inventory_for_cafe,
    get_menu_for_cafe,
    get_recipes_for_cafe,
    get_setup_status,
    get_suppliers_for_cafe,
    save_ingredient,
    save_menu_item,
    save_recipe,
    save_supplier,
    seed_demo_menu_items,
    set_onboarding_dismissed,
    update_cafe_profile,
    update_opening_stock,
)


class SidebarButton(ctk.CTkButton):
    """Sidebar navigation button with active highlight states."""

    def __init__(self, master, text: str, command=None, **kwargs):
        super().__init__(
            master,
            text=text,
            command=command,
            height=38,
            corner_radius=10,
            fg_color="transparent",
            hover_color="#1d4f91",
            text_color="#e9edf5",
            border_width=0,
            **kwargs,
        )
        self.selected = False
        self.configure(font=("Segoe UI", 13, "normal"))

    def set_selected(self, selected: bool):
        self.selected = selected
        if selected:
            self.configure(
                fg_color="#2d7ef7",
                hover_color="#3d8bfd",
                text_color="white",
                border_width=0,
            )
        else:
            self.configure(
                fg_color="transparent",
                hover_color="#1d4f91",
                text_color="#e9edf5",
                border_width=0,
            )


class StatCard(ctk.CTkFrame):
    """Summary KPI card used on the dashboard."""

    def __init__(self, master, title: str, value: str, subtitle: str):
        super().__init__(
            master,
            corner_radius=16,
            fg_color="#ffffff",
            border_color="#dfeaf8",
            border_width=1,
        )
        self.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            self,
            text=title,
            text_color="#5a6475",
            font=("Segoe UI", 12, "normal"),
            anchor="w",
        ).grid(row=0, column=0, padx=18, pady=(18, 0), sticky="w")

        ctk.CTkLabel(
            self,
            text=value,
            text_color="#0f172a",
            font=("Segoe UI", 26, "bold"),
            anchor="w",
        ).grid(row=1, column=0, padx=18, pady=(10, 0), sticky="w")

        ctk.CTkLabel(
            self,
            text=subtitle,
            text_color="#4a8f4f",
            font=("Segoe UI", 11, "normal"),
            anchor="w",
        ).grid(row=2, column=0, padx=18, pady=(4, 18), sticky="w")


class DashboardFrame(ctk.CTkScrollableFrame):
    """Main dashboard layout with key summary cards and activity panels."""

    def __init__(self, master, app):
        super().__init__(master, corner_radius=0, fg_color="#f4f7fb")
        self.app = app
        self.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            self,
            text="Overview",
            font=("Segoe UI", 24, "bold"),
            text_color="#111827",
            anchor="w",
        ).grid(row=0, column=0, padx=28, pady=(24, 12), sticky="w")

        cards_frame = ctk.CTkFrame(self, corner_radius=18, fg_color="transparent")
        cards_frame.grid(row=1, column=0, padx=28, pady=(0, 20), sticky="ew")
        cards_frame.grid_columnconfigure((0, 1, 2, 3), weight=1)

        summary_cards = [
            ("Today's Sales", "₹ 18,540", "+12.4% vs yesterday"),
            ("Today's Orders", "128", "14 dine-in, 42 take-away"),
            ("Low Stock Items", "07", "3 items critical"),
            ("Waste", "12 kg", "Down 4.1% this week"),
        ]

        for idx, (title, value, subtitle) in enumerate(summary_cards):
            card = StatCard(cards_frame, title, value, subtitle)
            card.grid(row=0, column=idx, padx=10, pady=0, sticky="ew")

        content_row = ctk.CTkFrame(self, corner_radius=18, fg_color="transparent")
        content_row.grid(row=2, column=0, padx=28, pady=(0, 20), sticky="nsew")
        content_row.grid_columnconfigure(0, weight=2)
        content_row.grid_columnconfigure(1, weight=1)

        recent_orders_frame = ctk.CTkFrame(
            content_row,
            corner_radius=16,
            fg_color="#ffffff",
            border_color="#dfeaf8",
            border_width=1,
        )
        recent_orders_frame.grid(row=0, column=0, padx=(0, 10), pady=0, sticky="nsew")

        ctk.CTkLabel(
            recent_orders_frame,
            text="Recent Orders",
            font=("Segoe UI", 18, "bold"),
            text_color="#111827",
            anchor="w",
        ).grid(row=0, column=0, padx=18, pady=(18, 12), sticky="w")

        recent_orders = [
            ("#1024", "Espresso + Croissant", "₹ 420"),
            ("#1025", "Signature Latte", "₹ 360"),
            ("#1026", "Veg Sandwich Combo", "₹ 620"),
            ("#1027", "Cold Brew", "₹ 320"),
        ]

        for row_index, (order_id, item, amount) in enumerate(recent_orders, start=1):
            row = ctk.CTkFrame(recent_orders_frame, fg_color="transparent")
            row.grid(row=row_index, column=0, padx=18, pady=6, sticky="ew")
            row.grid_columnconfigure(0, weight=2)
            row.grid_columnconfigure(1, weight=1)
            row.grid_columnconfigure(2, weight=1)

            ctk.CTkLabel(row, text=order_id, text_color="#475569", anchor="w").grid(
                row=0, column=0, sticky="w"
            )
            ctk.CTkLabel(row, text=item, text_color="#0f172a", anchor="w").grid(
                row=0, column=1, sticky="w"
            )
            ctk.CTkLabel(row, text=amount, text_color="#0f172a", anchor="e").grid(
                row=0, column=2, sticky="e"
            )

        low_stock_frame = ctk.CTkFrame(
            content_row,
            corner_radius=16,
            fg_color="#ffffff",
            border_color="#dfeaf8",
            border_width=1,
        )
        low_stock_frame.grid(row=0, column=1, padx=(10, 0), pady=0, sticky="nsew")

        ctk.CTkLabel(
            low_stock_frame,
            text="Low Stock Alerts",
            font=("Segoe UI", 18, "bold"),
            text_color="#111827",
            anchor="w",
        ).grid(row=0, column=0, padx=18, pady=(18, 12), sticky="w")

        low_stock_items = [
            ("Milk", "3 cartons left"),
            ("Tomato Sauce", "1 bottle left"),
            ("Coffee Beans", "5 kg left"),
            ("Fresh Lemon", "2 kg left"),
        ]

        for row_index, (item, qty) in enumerate(low_stock_items, start=1):
            alert_row = ctk.CTkFrame(low_stock_frame, fg_color="#fff5f5")
            alert_row.grid(row=row_index, column=0, padx=18, pady=6, sticky="ew")
            alert_row.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(
                alert_row,
                text=f"• {item}",
                text_color="#b42318",
                anchor="w",
                font=("Segoe UI", 12, "bold"),
            ).grid(row=0, column=0, padx=12, pady=8, sticky="w")
            ctk.CTkLabel(
                alert_row,
                text=qty,
                text_color="#7a2e0e",
                anchor="e",
            ).grid(row=0, column=1, padx=12, pady=8, sticky="e")

        actions_frame = ctk.CTkFrame(
            self,
            corner_radius=18,
            fg_color="#ffffff",
            border_color="#dfeaf8",
            border_width=1,
        )
        actions_frame.grid(row=3, column=0, padx=28, pady=(0, 28), sticky="ew")
        actions_frame.grid_columnconfigure((0, 1, 2, 3), weight=1)

        ctk.CTkLabel(
            actions_frame,
            text="Quick Actions",
            font=("Segoe UI", 18, "bold"),
            text_color="#111827",
            anchor="w",
        ).grid(row=0, column=0, padx=18, pady=(18, 12), sticky="w", columnspan=4)

        action_items = [
            ("New Order", "Orders"),
            ("Add Inventory", "Inventory"),
            ("Add Purchase", "Purchases"),
            ("Record Waste", "Waste"),
        ]

        for idx, (label, target) in enumerate(action_items):
            action_button = ctk.CTkButton(
                actions_frame,
                text=label,
                command=lambda page=target: self.app.show_page(page),
                height=42,
                corner_radius=12,
                fg_color="#e0ecff",
                hover_color="#d0e3ff",
                text_color="#0f172a",
            )
            action_button.grid(row=1, column=idx, padx=10, pady=(0, 18), sticky="ew")


class PlaceholderPage(ctk.CTkFrame):
    """Page placeholder shown while a module is still under construction."""

    def __init__(self, master, title: str):
        super().__init__(master, corner_radius=0, fg_color="#f4f7fb")
        self.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            self,
            text=title,
            font=("Segoe UI", 26, "bold"),
            text_color="#111827",
            anchor="w",
        ).grid(row=0, column=0, padx=28, pady=(28, 12), sticky="w")

        ctk.CTkLabel(
            self,
            text=f"{title} Module — Coming Next",
            font=("Segoe UI", 24),
            text_color="#475569",
            justify="center",
        ).grid(row=1, column=0, padx=28, pady=120, sticky="nsew")


class WasteManagementPage(ctk.CTkScrollableFrame):
    """Waste tracking page backed by the existing CSV and stock movement workflow."""

    def __init__(self, master, app):
        super().__init__(master, corner_radius=0, fg_color="#f4f7fb")
        self.app = app
        self.grid_columnconfigure(0, weight=1)

        header = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        header.grid(row=0, column=0, padx=28, pady=(22, 18), sticky="ew")
        header.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(header, text="Waste Management", font=("Segoe UI", 27, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 4), sticky="w")
        ctk.CTkLabel(header, text="Track ingredient waste, understand its cost and reduce avoidable losses.", font=("Segoe UI", 12), text_color="#475569", anchor="w").grid(row=1, column=0, padx=18, pady=(0, 18), sticky="w")

        cards = ctk.CTkFrame(self, corner_radius=18, fg_color="transparent")
        cards.grid(row=1, column=0, padx=28, pady=(0, 12), sticky="ew")
        cards.grid_columnconfigure((0, 1, 2, 3), weight=1)

        self.summary_cards = []
        for idx, (title, key) in enumerate([
            ("Waste Entries", "total_entries"),
            ("Waste Quantity", "total_quantity"),
            ("Estimated Waste Cost", "estimated_cost"),
            ("Most Common Waste Reason", "most_common_reason"),
        ]):
            card = ctk.CTkFrame(cards, corner_radius=16, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
            card.grid(row=0, column=idx, padx=10, sticky="ew")
            card.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(card, text=title, text_color="#5a6475", font=("Segoe UI", 12), anchor="w").grid(row=0, column=0, padx=16, pady=(18, 0), sticky="w")
            value_label = ctk.CTkLabel(card, text="0", text_color="#0f172a", font=("Segoe UI", 20, "bold"), anchor="w")
            value_label.grid(row=1, column=0, padx=16, pady=(10, 18), sticky="w")
            self.summary_cards.append((key, value_label))

        toolbar = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
        toolbar.grid(row=2, column=0, padx=28, pady=(0, 16), sticky="ew")
        toolbar.grid_columnconfigure(0, weight=2)
        toolbar.grid_columnconfigure(1, weight=1)
        toolbar.grid_columnconfigure(2, weight=0)
        toolbar.grid_columnconfigure(3, weight=0)

        self.search_var = ctk.StringVar(value="")
        self.reason_var = ctk.StringVar(value="All")
        self.range_var = ctk.StringVar(value="All")

        search_entry = ctk.CTkEntry(toolbar, textvariable=self.search_var, placeholder_text="Search by waste ID or ingredient", height=38)
        search_entry.grid(row=0, column=0, padx=16, pady=16, sticky="ew")
        search_entry.bind("<KeyRelease>", lambda _event: self.refresh())

        reason_menu = ctk.CTkOptionMenu(toolbar, values=["All", *WASTE_REASONS], variable=self.reason_var, dynamic_resizing=False)
        reason_menu.grid(row=0, column=1, padx=(0, 10), pady=16, sticky="ew")
        reason_menu.configure(command=lambda *_: self.refresh())

        range_menu = ctk.CTkOptionMenu(toolbar, values=["All", "Last 7 days", "Last 30 days", "Last 90 days"], variable=self.range_var, dynamic_resizing=False)
        range_menu.grid(row=0, column=2, padx=(0, 8), pady=16, sticky="ew")
        range_menu.configure(command=lambda *_: self.refresh())

        record_button = ctk.CTkButton(toolbar, text="Record Waste", command=self.show_waste_form, height=38, corner_radius=10, fg_color="#2563eb", hover_color="#1d4f91")
        record_button.grid(row=0, column=3, padx=(0, 16), pady=16, sticky="e")

        self.form_frame = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        self.form_frame.grid(row=3, column=0, padx=28, pady=(0, 16), sticky="ew")
        self.form_frame.grid_columnconfigure(0, weight=1)
        self.form_frame.grid_remove()

        self.form_title = ctk.CTkLabel(self.form_frame, text="Record Waste", font=("Segoe UI", 18, "bold"), text_color="#111827", anchor="w")
        self.form_title.grid(row=0, column=0, padx=18, pady=(18, 8), sticky="w")

        self.waste_fields = {
            "ingredient": ctk.CTkOptionMenu(self.form_frame, values=[], dynamic_resizing=False),
            "quantity": ctk.CTkEntry(self.form_frame, placeholder_text="Quantity wasted", height=38),
            "unit": ctk.CTkOptionMenu(self.form_frame, values=["g", "kg", "ml", "litre", "pcs"], dynamic_resizing=False),
            "reason": ctk.CTkOptionMenu(self.form_frame, values=WASTE_REASONS, dynamic_resizing=False),
            "occurred_at": ctk.CTkEntry(self.form_frame, placeholder_text="Date and time", height=38),
            "notes": ctk.CTkEntry(self.form_frame, placeholder_text="Notes (optional)", height=38),
            "other_reason": ctk.CTkEntry(self.form_frame, placeholder_text="Explain the 'Other' reason", height=38),
        }
        for idx, widget in enumerate(self.waste_fields.values(), start=1):
            widget.grid(row=idx, column=0, padx=18, pady=8, sticky="ew")

        self.waste_fields["reason"].configure(command=lambda *_: self._toggle_other_reason())
        self._toggle_other_reason()

        action_row = ctk.CTkFrame(self.form_frame, fg_color="transparent")
        action_row.grid(row=8, column=0, padx=18, pady=(0, 18), sticky="w")
        ctk.CTkButton(action_row, text="Save", command=self.save_waste, height=38, corner_radius=10, fg_color="#10B981", hover_color="#059669").grid(row=0, column=0, padx=(0, 10), sticky="w")
        ctk.CTkButton(action_row, text="Cancel", command=self.hide_waste_form, height=38, corner_radius=10, fg_color="#f8fafc", hover_color="#eef2ff", text_color="#0f172a", border_width=1, border_color="#dfeaf8").grid(row=0, column=1, sticky="w")

        self.table_frame = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
        self.table_frame.grid(row=4, column=0, padx=28, pady=(0, 28), sticky="nsew")
        self.table_frame.grid_columnconfigure(0, weight=1)

        self.information_frame = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
        self.information_frame.grid(row=5, column=0, padx=28, pady=(0, 28), sticky="ew")
        self.information_frame.grid_columnconfigure((0, 1, 2), weight=1)
        self.information_frame.grid_remove()

        self.refresh()

    def _toggle_other_reason(self):
        is_other = self.waste_fields["reason"].get() == "Other"
        if is_other:
            self.waste_fields["other_reason"].grid()
        else:
            self.waste_fields["other_reason"].grid_remove()

    def show_waste_form(self):
        if session.current_cafe_id is None:
            self._set_notice("No active café is selected.", False)
            return
        ingredients = list_ingredients(session.current_cafe_id) if session.current_cafe_id else []
        if not ingredients:
            self._set_notice("Add at least one inventory ingredient before recording waste.", False)
            return
        values = [item["name"] for item in ingredients]
        self.waste_fields["ingredient"].configure(values=values)
        self.waste_fields["ingredient"].set(values[0])
        selected = next((item for item in ingredients if item["name"] == values[0]), ingredients[0])
        self.waste_fields["unit"].set(selected.get("unit") or "kg")
        self.waste_fields["occurred_at"].delete(0, "end")
        self.waste_fields["occurred_at"].insert(0, __import__("datetime").datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        for field in ["quantity", "notes", "other_reason"]:
            if hasattr(self.waste_fields[field], "delete"):
                self.waste_fields[field].delete(0, "end")
        self.waste_fields["reason"].set("Expired / Spoiled")
        self.form_frame.grid()

    def hide_waste_form(self):
        self.form_frame.grid_remove()

    def _set_notice(self, message, ok=True):
        self.notice_label = ctk.CTkLabel(self, text=message, text_color="#197C3B" if ok else "#b42318", font=("Segoe UI", 12, "bold"), anchor="w")
        self.notice_label.grid(row=0, column=0, padx=28, pady=(0, 8), sticky="w")

    def save_waste(self):
        if session.current_cafe_id is None:
            self._set_notice("No active café is selected.", False)
            return
        ingredient_name = self.waste_fields["ingredient"].get().strip()
        ingredients = list_ingredients(session.current_cafe_id) if session.current_cafe_id else []
        ingredient = next((item for item in ingredients if item["name"] == ingredient_name), None)
        if ingredient is None:
            self._set_notice("Select a valid ingredient.", False)
            return
        quantity = self.waste_fields["quantity"].get().strip()
        if not quantity:
            self._set_notice("Quantity wasted is required.", False)
            return
        reason = self.waste_fields["reason"].get().strip()
        other_reason = self.waste_fields["other_reason"].get().strip()
        occurred_at = self.waste_fields["occurred_at"].get().strip() or __import__("datetime").datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        notes = self.waste_fields["notes"].get().strip()
        result = record_waste(
            cafe_id=session.current_cafe_id,
            ingredient_id=ingredient["ingredient_id"],
            quantity=quantity,
            unit=self.waste_fields["unit"].get(),
            reason=reason,
            occurred_at=occurred_at,
            recorded_by=session.current_user_id or "system",
            notes=notes,
            other_reason=other_reason,
            operation_id=f"{session.current_user_id or 'system'}:{ingredient['ingredient_id']}:{occurred_at}:{quantity}:{reason}",
        )
        if not result["success"]:
            self._set_notice(result["message"], False)
            return
        self._set_notice(result["message"], True)
        self.hide_waste_form()
        self.refresh()

    def _render_table(self, entries):
        for child in self.table_frame.winfo_children():
            child.destroy()
        if not entries:
            ctk.CTkLabel(self.table_frame, text="No waste history recorded yet.", text_color="#475569", font=("Segoe UI", 13), anchor="w").grid(row=0, column=0, padx=18, pady=20, sticky="w")
            return

        header = ctk.CTkFrame(self.table_frame, fg_color="#f8fafc", corner_radius=12, border_color="#dfeaf8", border_width=1)
        header.grid(row=0, column=0, padx=18, pady=(16, 10), sticky="ew")
        header.grid_columnconfigure((0, 1, 2, 3, 4, 5, 6), weight=1)
        labels = ["Waste ID", "Date", "Ingredient", "Qty", "Reason", "Estimated Cost", "Action"]
        for column_index, label in enumerate(labels):
            ctk.CTkLabel(header, text=label, font=("Segoe UI", 11, "bold"), text_color="#111827", anchor="w").grid(row=0, column=column_index, padx=10, pady=10, sticky="ew")

        for idx, entry in enumerate(entries[:25], start=1):
            row = ctk.CTkFrame(self.table_frame, fg_color="#ffffff", border_color="#e2e8f0", border_width=1, corner_radius=10)
            row.grid(row=idx, column=0, padx=18, pady=6, sticky="ew")
            row.grid_columnconfigure((0, 1, 2, 3, 4, 5, 6), weight=1)
            ctk.CTkLabel(row, text=str(entry.get("waste_id") or "-"), text_color="#111827", font=("Segoe UI", 11), anchor="w").grid(row=0, column=0, padx=10, pady=10, sticky="ew")
            ctk.CTkLabel(row, text=str(entry.get("occurred_at") or "-")[:19], text_color="#475569", font=("Segoe UI", 11), anchor="w").grid(row=0, column=1, padx=10, pady=10, sticky="ew")
            ingredient_name = str(entry.get("ingredient_name") or entry.get("ingredient_id") or "-")
            ctk.CTkLabel(row, text=ingredient_name, text_color="#111827", font=("Segoe UI", 11), anchor="w").grid(row=0, column=2, padx=10, pady=10, sticky="ew")
            ctk.CTkLabel(row, text=f"{entry.get('quantity', 0)} {entry.get('unit', '')}", text_color="#111827", font=("Segoe UI", 11), anchor="w").grid(row=0, column=3, padx=10, pady=10, sticky="ew")
            ctk.CTkLabel(row, text=str(entry.get("reason") or "-"), text_color="#475569", font=("Segoe UI", 11), anchor="w").grid(row=0, column=4, padx=10, pady=10, sticky="ew")
            ctk.CTkLabel(row, text="Cost unavailable" if entry.get("estimated_total_cost") is None else f"₹{float(entry['estimated_total_cost']):,.2f}", text_color="#111827", font=("Segoe UI", 11), anchor="w").grid(row=0, column=5, padx=10, pady=10, sticky="ew")
            button = ctk.CTkButton(row, text="View Details", command=lambda item=entry: self.show_detail_dialog(item), height=30, corner_radius=8, fg_color="#e0ecff", hover_color="#d0e3ff", text_color="#0f172a")
            button.grid(row=0, column=6, padx=10, pady=10, sticky="e")

    def show_detail_dialog(self, entry):
        dialog = ctk.CTkToplevel(self)
        dialog.title(f"Waste Details - {entry.get('waste_id', '-')}")
        dialog.geometry("540x420")
        dialog.configure(fg_color="#f8fafc")
        dialog.transient(self.winfo_toplevel())
        dialog.grab_set()

        cost_text = "Cost unavailable" if entry.get("estimated_total_cost") is None else f"₹{float(entry['estimated_total_cost']):,.2f}"
        text = (
            f"Waste ID: {entry.get('waste_id') or '-'}\n"
            f"Ingredient: {entry.get('ingredient_name') or entry.get('ingredient_id') or '-'}\n"
            f"Quantity: {entry.get('quantity') or 0} {entry.get('unit') or '-'}\n"
            f"Reason: {entry.get('reason') or '-'}\n"
            f"Date and Time: {entry.get('occurred_at') or '-'}\n"
            f"Recorded By: {entry.get('recorded_by') or '-'}\n"
            f"Estimated Cost: {cost_text}\n"
            f"Notes: {entry.get('notes') or 'No notes'}\n"
            f"Stock Movement ID: {entry.get('stock_movement_id') or '-'}"
        )
        ctk.CTkLabel(dialog, text=text, justify="left", font=("Segoe UI", 12), text_color="#111827", anchor="nw", wraplength=500).pack(padx=20, pady=20, fill="both", expand=True)

    def refresh(self):
        if session.current_cafe_id is None:
            self._set_notice("Select a café to view waste records.", False)
            return
        start_date, end_date = None, None
        range_label = self.range_var.get()
        if range_label == "Last 7 days":
            end_date = datetime.now().strftime("%Y-%m-%d")
            start_date = (datetime.now() - __import__("datetime").timedelta(days=7)).strftime("%Y-%m-%d")
        elif range_label == "Last 30 days":
            end_date = datetime.now().strftime("%Y-%m-%d")
            start_date = (datetime.now() - __import__("datetime").timedelta(days=30)).strftime("%Y-%m-%d")
        elif range_label == "Last 90 days":
            end_date = datetime.now().strftime("%Y-%m-%d")
            start_date = (datetime.now() - __import__("datetime").timedelta(days=90)).strftime("%Y-%m-%d")

        entries = list_waste_entries(session.current_cafe_id, search=self.search_var.get(), reason=self.reason_var.get(), start_date=start_date, end_date=end_date)
        summary = get_waste_dashboard(session.current_cafe_id, start_date=start_date, end_date=end_date)

        mapping = {
            "total_entries": summary.get("total_entries", 0),
            "total_quantity": summary.get("total_quantity_label", "0"),
            "estimated_cost": summary.get("estimated_waste_cost_label", "Cost unavailable"),
            "most_common_reason": summary.get("most_common_reason", "No data"),
        }
        for key, label in self.summary_cards:
            value = mapping.get(key, "0")
            label.configure(text=str(value))

        self._render_table(entries)


class AccountManagementPage(ctk.CTkScrollableFrame):
    """Owner account management page for the authenticated café owner."""

    def __init__(self, master, app):
        super().__init__(master, corner_radius=0, fg_color="#f4f7fb")
        self.app = app
        self.grid_columnconfigure(0, weight=1)
        self.last_snapshot = None
        self.account_form = {}
        self.cafe_form = {}
        self.security_form = {}
        self.notice_var = ctk.StringVar(value="")
        self.notice_color = "#0f172a"

        self._build_layout()
        self.refresh_profile()

    def _build_layout(self):
        header = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        header.grid(row=0, column=0, padx=28, pady=(22, 18), sticky="ew")
        header.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(header, text="Account Settings", font=("Segoe UI", 27, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 4), sticky="w")
        ctk.CTkLabel(header, text="Manage your owner profile, café details, security and preferences.", font=("Segoe UI", 12), text_color="#475569", anchor="w").grid(row=1, column=0, padx=18, pady=(0, 18), sticky="w")

        self.notice = ctk.CTkLabel(self, textvariable=self.notice_var, text_color="#0f172a", font=("Segoe UI", 12), anchor="w")
        self.notice.grid(row=1, column=0, padx=28, pady=(0, 12), sticky="w")

        main = ctk.CTkFrame(self, corner_radius=18, fg_color="transparent")
        main.grid(row=2, column=0, padx=28, pady=(0, 28), sticky="nsew")
        main.grid_columnconfigure(0, weight=1)
        main.grid_columnconfigure(1, weight=1)

        left = ctk.CTkFrame(main, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        left.grid(row=0, column=0, padx=(0, 10), sticky="nsew")
        left.grid_columnconfigure(0, weight=1)

        right = ctk.CTkFrame(main, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        right.grid(row=0, column=1, padx=(10, 0), sticky="nsew")
        right.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(left, text="Owner Profile", font=("Segoe UI", 18, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 12), sticky="w")
        self.owner_name_var = ctk.StringVar(value="")
        self.email_var = ctk.StringVar(value="")
        self.phone_var = ctk.StringVar(value="")
        self.account_form = {
            "full_name": ctk.CTkEntry(left, textvariable=self.owner_name_var, height=38, placeholder_text="Full name"),
            "email": ctk.CTkEntry(left, textvariable=self.email_var, height=38, placeholder_text="Login email"),
            "phone": ctk.CTkEntry(left, textvariable=self.phone_var, height=38, placeholder_text="Phone number"),
        }
        for idx, (key, widget) in enumerate(self.account_form.items(), start=1):
            widget.grid(row=idx, column=0, padx=18, pady=8, sticky="ew")

        row = ctk.CTkFrame(left, fg_color="transparent")
        row.grid(row=5, column=0, padx=18, pady=(12, 18), sticky="ew")
        row.grid_columnconfigure(0, weight=1)
        row.grid_columnconfigure(1, weight=1)
        ctk.CTkButton(row, text="Save Changes", command=self.save_owner_profile, height=38, corner_radius=10, fg_color="#2563eb", hover_color="#1d4f91").grid(row=0, column=0, padx=(0, 8), sticky="ew")
        ctk.CTkButton(row, text="Reset", command=self.reset_owner_form, height=38, corner_radius=10, fg_color="#f8fafc", hover_color="#eef2ff", text_color="#0f172a", border_width=1, border_color="#dfeaf8").grid(row=0, column=1, padx=(8, 0), sticky="ew")

        ctk.CTkLabel(right, text="Café Information", font=("Segoe UI", 18, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 12), sticky="w")
        self.cafe_name_var = ctk.StringVar(value="")
        self.cafe_location_var = ctk.StringVar(value="")
        self.cafe_phone_var = ctk.StringVar(value="")
        self.cafe_form = {
            "cafe_name": ctk.CTkEntry(right, textvariable=self.cafe_name_var, height=38, placeholder_text="Café name"),
            "location": ctk.CTkEntry(right, textvariable=self.cafe_location_var, height=38, placeholder_text="Location"),
            "phone": ctk.CTkEntry(right, textvariable=self.cafe_phone_var, height=38, placeholder_text="Café contact phone"),
        }
        for idx, widget in enumerate(self.cafe_form.values(), start=1):
            widget.grid(row=idx, column=0, padx=18, pady=8, sticky="ew")

        cafe_row = ctk.CTkFrame(right, fg_color="transparent")
        cafe_row.grid(row=5, column=0, padx=18, pady=(12, 18), sticky="ew")
        cafe_row.grid_columnconfigure(0, weight=1)
        cafe_row.grid_columnconfigure(1, weight=1)
        ctk.CTkButton(cafe_row, text="Save Café", command=self.save_cafe_profile, height=38, corner_radius=10, fg_color="#2563eb", hover_color="#1d4f91").grid(row=0, column=0, padx=(0, 8), sticky="ew")
        ctk.CTkButton(cafe_row, text="Reset", command=self.reset_cafe_form, height=38, corner_radius=10, fg_color="#f8fafc", hover_color="#eef2ff", text_color="#0f172a", border_width=1, border_color="#dfeaf8").grid(row=0, column=1, padx=(8, 0), sticky="ew")

        bottom = ctk.CTkFrame(self, corner_radius=18, fg_color="transparent")
        bottom.grid(row=3, column=0, padx=28, pady=(0, 28), sticky="nsew")
        bottom.grid_columnconfigure(0, weight=1)
        bottom.grid_columnconfigure(1, weight=1)

        security_panel = ctk.CTkFrame(bottom, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        security_panel.grid(row=0, column=0, padx=(0, 10), sticky="nsew")
        security_panel.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(security_panel, text="Security", font=("Segoe UI", 18, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 12), sticky="w")
        self.current_password_var = ctk.StringVar(value="")
        self.new_password_var = ctk.StringVar(value="")
        self.confirm_password_var = ctk.StringVar(value="")
        self.security_form = {
            "current_password": ctk.CTkEntry(security_panel, textvariable=self.current_password_var, show="*", height=38, placeholder_text="Current password"),
            "new_password": ctk.CTkEntry(security_panel, textvariable=self.new_password_var, show="*", height=38, placeholder_text="New password"),
            "confirm_password": ctk.CTkEntry(security_panel, textvariable=self.confirm_password_var, show="*", height=38, placeholder_text="Confirm new password"),
        }
        for idx, widget in enumerate(self.security_form.values(), start=1):
            widget.grid(row=idx, column=0, padx=18, pady=8, sticky="ew")

        security_row = ctk.CTkFrame(security_panel, fg_color="transparent")
        security_row.grid(row=4, column=0, padx=18, pady=(12, 18), sticky="ew")
        security_row.grid_columnconfigure(0, weight=1)
        security_row.grid_columnconfigure(1, weight=1)
        ctk.CTkButton(security_row, text="Change Password", command=self.change_password, height=38, corner_radius=10, fg_color="#10B981", hover_color="#059669").grid(row=0, column=0, padx=(0, 8), sticky="ew")
        ctk.CTkButton(security_row, text="Clear", command=self.clear_security_form, height=38, corner_radius=10, fg_color="#f8fafc", hover_color="#eef2ff", text_color="#0f172a", border_width=1, border_color="#dfeaf8").grid(row=0, column=1, padx=(8, 0), sticky="ew")

        right_panel = ctk.CTkFrame(bottom, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        right_panel.grid(row=0, column=1, padx=(10, 0), sticky="nsew")
        right_panel.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(right_panel, text="Preferences & Status", font=("Segoe UI", 18, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 12), sticky="w")

        pref_box = ctk.CTkFrame(right_panel, fg_color="#f8fafc", border_color="#dfeaf8", border_width=1)
        pref_box.grid(row=1, column=0, padx=18, pady=(0, 12), sticky="ew")
        pref_box.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(pref_box, text="Preferences", font=("Segoe UI", 13, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=16, pady=(16, 8), sticky="w")
        ctk.CTkLabel(pref_box, text="- Currency display: INR\n- Date display: DD/MM/YYYY\n- Time display: 24-hour\n- Notifications: not configured in the existing data model", justify="left", text_color="#475569", anchor="w").grid(row=1, column=0, padx=16, pady=(0, 16), sticky="w")

        status_box = ctk.CTkFrame(right_panel, fg_color="#f8fafc", border_color="#dfeaf8", border_width=1)
        status_box.grid(row=2, column=0, padx=18, pady=(0, 18), sticky="ew")
        status_box.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(status_box, text="Account Status", font=("Segoe UI", 13, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=16, pady=(16, 8), sticky="w")
        self.status_label = ctk.CTkLabel(status_box, text="", justify="left", text_color="#475569", anchor="w")
        self.status_label.grid(row=1, column=0, padx=16, pady=(0, 16), sticky="w")

    def _set_notice(self, message, success=True):
        self.notice_var.set(message)
        self.notice.configure(text_color="#197C3B" if success else "#b42318")

    def _load_snapshot(self):
        from modules.cafe_owners import get_owner_account_snapshot

        if session.current_user_id is None:
            return None
        cafe_id = session.current_cafe_id
        return get_owner_account_snapshot(session.current_user_id, cafe_id)

    def refresh_profile(self):
        snapshot = self._load_snapshot()
        self.last_snapshot = snapshot
        if snapshot is None:
            self._set_notice("No active owner profile is available for this session.", False)
            return

        self.owner_name_var.set(snapshot.get("owner_name") or "")
        self.email_var.set(snapshot.get("email") or "")
        self.phone_var.set(snapshot.get("phone") or "")
        self.cafe_name_var.set(snapshot.get("cafe_name") or "")
        self.cafe_location_var.set(snapshot.get("location") or "")
        self.cafe_phone_var.set(snapshot.get("cafe_phone") or "")

        status_text = (
            f"Status: {snapshot.get('status', 'Unknown')}\n"
            f"Role: {snapshot.get('role', 'Unknown')}\n"
            f"Café ID: {snapshot.get('cafe_id') or 'Not assigned'}\n"
            f"Café: {snapshot.get('cafe_name') or 'Not available'}\n"
            f"Setup: {snapshot.get('setup_progress', 0)}%"
        )
        self.status_label.configure(text=status_text)
        self._set_notice("Profile loaded successfully.", True)

    def reset_owner_form(self):
        snapshot = self.last_snapshot or self._load_snapshot()
        if snapshot is None:
            return
        self.owner_name_var.set(snapshot.get("owner_name") or "")
        self.email_var.set(snapshot.get("email") or "")
        self.phone_var.set(snapshot.get("phone") or "")
        self._set_notice("Owner profile changes were reset.", True)

    def reset_cafe_form(self):
        snapshot = self.last_snapshot or self._load_snapshot()
        if snapshot is None:
            return
        self.cafe_name_var.set(snapshot.get("cafe_name") or "")
        self.cafe_location_var.set(snapshot.get("location") or "")
        self.cafe_phone_var.set(snapshot.get("cafe_phone") or "")
        self._set_notice("Café details were reset.", True)

    def clear_security_form(self):
        self.current_password_var.set("")
        self.new_password_var.set("")
        self.confirm_password_var.set("")

    def save_owner_profile(self):
        if session.current_user_id is None:
            self._set_notice("No active user is available to update the profile.", False)
            return

        from modules.cafe_owners import update_owner_profile
        result = update_owner_profile(
            session.current_user_id,
            full_name=self.owner_name_var.get(),
            email=self.email_var.get(),
            phone=self.phone_var.get(),
        )
        if not result["success"]:
            self._set_notice(result["message"], False)
            return
        self._set_notice(result["message"], True)
        self.refresh_profile()

    def save_cafe_profile(self):
        if session.current_user_id is None or session.current_cafe_id is None:
            self._set_notice("No active café is available to update.", False)
            return

        from modules.cafe_owners import update_cafe_profile
        result = update_cafe_profile(
            session.current_user_id,
            session.current_cafe_id,
            cafe_name=self.cafe_name_var.get(),
            location=self.cafe_location_var.get(),
            phone=self.cafe_phone_var.get(),
        )
        if not result["success"]:
            self._set_notice(result["message"], False)
            return
        self._set_notice(result["message"], True)
        self.refresh_profile()

    def change_password(self):
        if session.current_user_id is None:
            self._set_notice("No active user is available to change the password.", False)
            return

        current_pw = self.current_password_var.get().strip()
        new_pw = self.new_password_var.get().strip()
        confirm_pw = self.confirm_password_var.get().strip()

        if not current_pw or not new_pw or not confirm_pw:
            self._set_notice("Current, new and confirmation passwords are required.", False)
            return
        if new_pw != confirm_pw:
            self._set_notice("The new password and confirmation do not match.", False)
            return
        if len(new_pw) < 8:
            self._set_notice("New password must be at least 8 characters long.", False)
            return

        from modules.cafe_owners import update_owner_profile
        result = update_owner_profile(
            session.current_user_id,
            full_name=self.owner_name_var.get(),
            email=self.email_var.get(),
            phone=self.phone_var.get(),
            password=new_pw,
            current_password=current_pw,
        )
        if not result["success"]:
            self._set_notice(result["message"], False)
            return
        self.clear_security_form()
        self._set_notice("Password updated successfully.", True)
        self.refresh_profile()


class ReportsPage(ctk.CTkScrollableFrame):
    """Business reporting page for the authenticated café."""

    def __init__(self, master, app):
        super().__init__(master, corner_radius=0, fg_color="#f4f7fb")
        self.app = app
        self.grid_columnconfigure(0, weight=1)
        self.section_var = ctk.StringVar(value="Overview")
        self.range_var = ctk.StringVar(value="Last 30 Days")
        self.start_date_var = ctk.StringVar(value="")
        self.end_date_var = ctk.StringVar(value="")

        header = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        header.grid(row=0, column=0, padx=28, pady=(22, 18), sticky="ew")
        header.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(header, text="Reports & Business Insights", font=("Segoe UI", 27, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 4), sticky="w")
        ctk.CTkLabel(header, text="Understand sales, menu performance, stock, purchases and waste.", font=("Segoe UI", 12), text_color="#475569", anchor="w").grid(row=1, column=0, padx=18, pady=(0, 18), sticky="w")

        toolbar = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        toolbar.grid(row=1, column=0, padx=28, pady=(0, 12), sticky="ew")
        toolbar.grid_columnconfigure((0, 1, 2, 3, 4, 5), weight=1)

        self.date_filter_menu = ctk.CTkOptionMenu(toolbar, values=["Today", "Yesterday", "Last 7 Days", "Last 30 Days", "This Month", "Custom Range"], variable=self.range_var, dynamic_resizing=False)
        self.date_filter_menu.grid(row=0, column=0, padx=12, pady=14, sticky="ew")
        self.date_filter_menu.configure(command=lambda *_: self._toggle_custom_dates())

        self.start_date_entry = ctk.CTkEntry(toolbar, placeholder_text="Start date", textvariable=self.start_date_var, height=38)
        self.start_date_entry.grid(row=0, column=1, padx=8, pady=14, sticky="ew")

        self.end_date_entry = ctk.CTkEntry(toolbar, placeholder_text="End date", textvariable=self.end_date_var, height=38)
        self.end_date_entry.grid(row=0, column=2, padx=8, pady=14, sticky="ew")

        ctk.CTkButton(toolbar, text="Apply Filters", command=self.refresh, height=38, corner_radius=10, fg_color="#2563eb", hover_color="#1d4f91").grid(row=0, column=3, padx=8, pady=14, sticky="ew")
        ctk.CTkButton(toolbar, text="Reset Filters", command=self.reset_filters, height=38, corner_radius=10, fg_color="#f8fafc", hover_color="#eef2ff", text_color="#0f172a", border_width=1, border_color="#dfeaf8").grid(row=0, column=4, padx=8, pady=14, sticky="ew")
        ctk.CTkButton(toolbar, text="Export CSV", command=self.export_current_report, height=38, corner_radius=10, fg_color="#10B981", hover_color="#059669").grid(row=0, column=5, padx=(8, 12), pady=14, sticky="ew")

        self._toggle_custom_dates()

        tabs = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        tabs.grid(row=2, column=0, padx=28, pady=(0, 16), sticky="ew")
        tabs.grid_columnconfigure((0, 1, 2, 3, 4, 5), weight=1)
        self.tab_names = ["Overview", "Sales", "Menu & Cost", "Inventory", "Purchases", "Waste"]
        for idx, name in enumerate(self.tab_names):
            btn = ctk.CTkButton(
                tabs,
                text=name,
                command=lambda value=name: self._set_tab(value),
                height=36,
                corner_radius=10,
                fg_color="#e0ecff" if name != "Overview" else "#2563eb",
                hover_color="#d0e3ff",
                text_color="#0f172a" if name != "Overview" else "#ffffff",
            )
            btn.grid(row=0, column=idx, padx=8, pady=12, sticky="ew")
            if name == "Overview":
                self.active_tab_button = btn

        self.content_frame = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        self.content_frame.grid(row=3, column=0, padx=28, pady=(0, 28), sticky="nsew")
        self.content_frame.grid_columnconfigure(0, weight=1)

        self.refresh()

    def _toggle_custom_dates(self):
        show = self.range_var.get() == "Custom Range"
        self.start_date_entry.grid() if show else self.start_date_entry.grid_remove()
        self.end_date_entry.grid() if show else self.end_date_entry.grid_remove()

    def reset_filters(self):
        self.range_var.set("Last 30 Days")
        self.start_date_var.set("")
        self.end_date_var.set("")
        self._toggle_custom_dates()
        self.refresh()

    def _set_tab(self, value):
        self.section_var.set(value)
        self.refresh()

    def _set_placeholder(self, text):
        for child in self.content_frame.winfo_children():
            child.destroy()
        ctk.CTkLabel(self.content_frame, text=text, text_color="#475569", font=("Segoe UI", 13), anchor="w").grid(row=0, column=0, padx=18, pady=24, sticky="w")

    def export_current_report(self):
        if session.current_cafe_id is None:
            self._set_placeholder("Select a café before exporting a report.")
            return
        section = self.section_var.get()
        preset = self.range_var.get()
        start_date = self.start_date_var.get().strip() if self.range_var.get() == "Custom Range" else ""
        end_date = self.end_date_var.get().strip() if self.range_var.get() == "Custom Range" else ""
        start_dt, end_dt = _resolve_date_range(preset=preset, start_date=start_date, end_date=end_date)
        report = self._build_report(section, session.current_cafe_id, start_dt, end_dt)
        rows = report.get("rows") if isinstance(report, dict) else []
        try:
            from tkinter import filedialog
            safe_path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV Files", "*.csv")])
            if not safe_path:
                return
            export_report_csv(section.lower().replace(" & ", "_").replace(" ", "_"), rows, safe_path)
            self._set_placeholder(f"Exported {section} data to {safe_path}.")
        except Exception:
            self._set_placeholder("CSV export could not be created for this report.")

    def _build_report(self, section, cafe_id, start_dt, end_dt):
        if section == "Overview":
            data = get_overview_report(cafe_id, preset="Custom Range", start_date=start_dt.strftime("%Y-%m-%d"), end_date=end_dt.strftime("%Y-%m-%d"))
            cards = [
                ("Completed orders", data.get("metrics", {}).get("completed_order_count", 0)),
                ("Gross sales", "Data unavailable" if data.get("metrics", {}).get("gross_sales") is None else f"₹{data['metrics']['gross_sales']:,.2f}"),
                ("Payments collected", "Data unavailable" if data.get("metrics", {}).get("payments_collected") is None else f"₹{data['metrics']['payments_collected']:,.2f}"),
                ("Low-stock items", data.get("metrics", {}).get("low_stock_ingredient_count", 0)),
            ]
            rows = [{"metric": key, "value": value} for key, value in [
                ("completed_order_count", data.get("metrics", {}).get("completed_order_count", 0)),
                ("gross_sales", data.get("metrics", {}).get("gross_sales")),
                ("discounts", data.get("metrics", {}).get("discounts")),
                ("net_sales", data.get("metrics", {}).get("net_sales")),
                ("payments_collected", data.get("metrics", {}).get("payments_collected")),
                ("outstanding_balance", data.get("metrics", {}).get("outstanding_balance")),
                ("average_order_value", data.get("metrics", {}).get("average_order_value")),
            ]]
            return {"cards": cards, "rows": rows}
        if section == "Sales":
            data = get_sales_report(cafe_id, preset="Custom Range", start_date=start_dt.strftime("%Y-%m-%d"), end_date=end_dt.strftime("%Y-%m-%d"))
            cards = [
                ("Sales trend points", len(data.get("sales_trend", []))),
                ("Average order value", "Data unavailable" if data.get("average_order_value") is None else f"₹{data['average_order_value']:,.2f}"),
                ("Discount total", "Data unavailable" if data.get("discount_total") in (None, 0) else f"₹{data['discount_total']:,.2f}"),
                ("Payment methods", len(data.get("payment_summary", []))),
            ]
            return {"cards": cards, "rows": data.get("menu_item_sales", [])}
        if section == "Menu & Cost":
            data = get_menu_cost_report(cafe_id, preset="Custom Range", start_date=start_dt.strftime("%Y-%m-%d"), end_date=end_dt.strftime("%Y-%m-%d"))
            rows = data.get("sales_by_item", [])
            return {"cards": [("Best sellers", len(data.get("best_sellers", []))), ("Menu items with sales", len(rows)), ("Missing recipes", len(data.get("missing_recipe_items", []))), ("Cost basis", "Recipe cost")], "rows": rows}
        if section == "Inventory":
            data = get_inventory_report(cafe_id, preset="Custom Range", start_date=start_dt.strftime("%Y-%m-%d"), end_date=end_dt.strftime("%Y-%m-%d"))
            return {"cards": [("Current stock items", len(data.get("current_stock", []))), ("Low stock", len(data.get("low_stock", []))), ("Out of stock", len(data.get("out_of_stock", []))), ("Movements", len(data.get("stock_movement_history", [])))], "rows": data.get("current_stock", [])}
        if section == "Purchases":
            data = get_purchases_report(cafe_id, preset="Custom Range", start_date=start_dt.strftime("%Y-%m-%d"), end_date=end_dt.strftime("%Y-%m-%d"))
            return {"cards": [("Purchase orders", len(data.get("purchases", []))), ("Received", len(data.get("received", []))), ("Partially received", len(data.get("partially_received", []))), ("Total value", f"₹{data.get('purchase_total_value', 0):,.2f}")], "rows": data.get("purchases", [])}
        if section == "Waste":
            data = get_waste_report(cafe_id, preset="Custom Range", start_date=start_dt.strftime("%Y-%m-%d"), end_date=end_dt.strftime("%Y-%m-%d"))
            return {"cards": [("Waste entries", len(data.get("entries", []))), ("Ingredients affected", len(data.get("by_ingredient", []))), ("Reasons", len(data.get("by_reason", []))), ("Estimated cost", "Data unavailable" if data.get("estimated_total_cost") is None else f"₹{data['estimated_total_cost']:,.2f}")], "rows": data.get("entries", [])}
        return {"cards": [], "rows": []}

    def refresh(self):
        if session.current_cafe_id is None:
            self._set_placeholder("Select an active café to view reports.")
            return

        section = self.section_var.get()
        preset = self.range_var.get()
        start_date = self.start_date_var.get().strip() if self.range_var.get() == "Custom Range" else ""
        end_date = self.end_date_var.get().strip() if self.range_var.get() == "Custom Range" else ""
        start_dt, end_dt = _resolve_date_range(preset=preset, start_date=start_date, end_date=end_date)
        report = self._build_report(section, session.current_cafe_id, start_dt, end_dt)

        for child in self.content_frame.winfo_children():
            child.destroy()

        card_frame = ctk.CTkFrame(self.content_frame, corner_radius=12, fg_color="#f8fafc", border_color="#dfeaf8", border_width=1)
        card_frame.grid(row=0, column=0, padx=18, pady=18, sticky="ew")
        card_frame.grid_columnconfigure((0, 1, 2, 3), weight=1)
        for idx, (title, value) in enumerate(report.get("cards", [])):
            card = ctk.CTkFrame(card_frame, corner_radius=12, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
            card.grid(row=0, column=idx, padx=8, pady=10, sticky="ew")
            ctk.CTkLabel(card, text=title, text_color="#5a6475", font=("Segoe UI", 12), anchor="w").grid(row=0, column=0, padx=14, pady=(12, 0), sticky="w")
            ctk.CTkLabel(card, text=str(value), text_color="#111827", font=("Segoe UI", 18, "bold"), anchor="w").grid(row=1, column=0, padx=14, pady=(8, 12), sticky="w")

        table = ctk.CTkScrollableFrame(self.content_frame, corner_radius=12, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
        table.grid(row=1, column=0, padx=18, pady=(0, 18), sticky="nsew")
        table.grid_columnconfigure((0, 1, 2, 3), weight=1)

        rows = report.get("rows", [])
        if not rows:
            ctk.CTkLabel(table, text="No data available for the selected period.", text_color="#475569", font=("Segoe UI", 13), anchor="w").grid(row=0, column=0, padx=18, pady=20, sticky="w")
            return

        if section == "Overview":
            metrics = rows
            for idx, row in enumerate(metrics):
                label = ctk.CTkLabel(table, text=str(row["metric"]).replace("_", " ").title(), text_color="#111827", font=("Segoe UI", 12), anchor="w")
                label.grid(row=idx, column=0, padx=18, pady=8, sticky="w")
                val = row["value"]
                if val is None:
                    val = "Data unavailable"
                elif isinstance(val, float):
                    val = f"₹{val:,.2f}"
                ctk.CTkLabel(table, text=str(val), text_color="#475569", font=("Segoe UI", 12), anchor="w").grid(row=idx, column=1, padx=18, pady=8, sticky="e")
        elif section == "Sales":
            for idx, row in enumerate(rows[:10]):
                item_name = row.get("item_name", row.get("menu_item_id", "Item"))
                ctk.CTkLabel(table, text=item_name, text_color="#111827", font=("Segoe UI", 12), anchor="w").grid(row=idx, column=0, padx=18, pady=8, sticky="w")
                ctk.CTkLabel(table, text=f"{row.get('quantity', 0)} sold", text_color="#475569", font=("Segoe UI", 12), anchor="w").grid(row=idx, column=1, padx=18, pady=8, sticky="w")
                ctk.CTkLabel(table, text=f"₹{float(row.get('sales', 0) or 0):,.2f}", text_color="#111827", font=("Segoe UI", 12), anchor="w").grid(row=idx, column=2, padx=18, pady=8, sticky="w")
        else:
            for idx, row in enumerate(rows[:10]):
                if isinstance(row, dict):
                    item_name = row.get("item_name") or row.get("name") or row.get("ingredient") or row.get("purchase_id") or row.get("waste_id") or "Record"
                    d = row.get("sales_value") if "sales_value" in row else row.get("current_stock") if "current_stock" in row else row.get("subtotal") if "subtotal" in row else row.get("quantity") if "quantity" in row else row.get("quantity_sold") or row.get("total")
                    text = f"{item_name}: {d}"
                    ctk.CTkLabel(table, text=text, text_color="#111827", font=("Segoe UI", 12), anchor="w", justify="left", wraplength=700).grid(row=idx, column=0, padx=18, pady=8, sticky="w")

        self.content_frame.grid_rowconfigure(1, weight=1)


class RecipeManagementPage(ctk.CTkScrollableFrame):
    """Recipe management page backed by the CSV workflow."""

    def __init__(self, master, app):
        super().__init__(master, corner_radius=0, fg_color="#f4f7fb")
        self.app = app
        self.grid_columnconfigure(0, weight=1)
        self.refresh()

    def _safe_recipe_cost(self, recipe):
        cost = recipe.get("estimated_ingredient_cost")
        if cost is None:
            return "Cost unavailable"
        return f"₹{float(cost):,.2f}"

    def _menu_options(self):
        options = []
        lookup = {}
        for item in list_menu_items(session.current_cafe_id):
            label = f"{item['item_name']} ({item['item_id']})"
            options.append(label)
            lookup[label] = item["item_id"]
        return options, lookup

    def _ingredient_options(self):
        options = []
        lookup = {}
        for ingredient in list_ingredients(session.current_cafe_id):
            label = f"{ingredient['name']} ({ingredient['ingredient_id']})"
            options.append(label)
            lookup[label] = ingredient
        return options, lookup

    def _compatible_units(self, ingredient_record):
        if not ingredient_record:
            return ["g", "kg", "ml", "litre", "pcs"]
        unit = str(ingredient_record.get("unit") or "g").strip() or "g"
        if unit in {"g", "kg"}:
            return [unit, "g", "kg"]
        if unit in {"ml", "litre"}:
            return [unit, "ml", "litre"]
        return [unit, "pcs"]

    def _show_message(self, message, is_error=False):
        from tkinter import messagebox

        if is_error:
            messagebox.showerror("Recipe Management", message)
        else:
            messagebox.showinfo("Recipe Management", message)

    def _open_recipe_form(self, recipe=None):
        if not session.current_cafe_id:
            self._show_message("No active café is selected.", True)
            return

        menu_options, menu_lookup = self._menu_options()
        if not menu_options:
            self._show_message("Create at least one menu item before creating a recipe.", True)
            return

        ingredient_options, ingredient_lookup = self._ingredient_options()
        if not ingredient_options:
            self._show_message("Add inventory ingredients before creating a recipe.", True)
            return

        dialog = ctk.CTkToplevel(self)
        dialog.title("Edit Recipe" if recipe else "Add Recipe")
        dialog.geometry("760x620")
        dialog.minsize(680, 520)
        dialog.configure(fg_color="#f8fafc")
        dialog.transient(self.winfo_toplevel())
        dialog.grab_set()

        form_frame = ctk.CTkFrame(dialog, fg_color="#ffffff", corner_radius=18, border_color="#dfeaf8", border_width=1)
        form_frame.pack(fill="both", expand=True, padx=18, pady=18)
        form_frame.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(form_frame, text="Recipe Details", font=("Segoe UI", 22, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 10), sticky="w")

        menu_var = ctk.StringVar(value=next((label for label, item_id in menu_lookup.items() if recipe and item_id == recipe["menu_item_id"]), menu_options[0]))
        menu_menu = ctk.CTkOptionMenu(form_frame, values=menu_options, variable=menu_var, width=320, fg_color="#ffffff", button_color="#ffffff", button_hover_color="#e0ecff", text_color="#111827")
        menu_menu.grid(row=1, column=0, padx=18, pady=(0, 12), sticky="ew")

        line_container = ctk.CTkScrollableFrame(form_frame, fg_color="#f8fafc", border_width=1, border_color="#dfeaf8")
        line_container.grid(row=2, column=0, padx=18, pady=(0, 12), sticky="nsew")
        line_container.grid_columnconfigure(0, weight=3)
        line_container.grid_columnconfigure(1, weight=1)
        line_container.grid_columnconfigure(2, weight=1)
        line_container.grid_columnconfigure(3, weight=0)
        line_rows = []

        def add_line(default_data=None):
            row = ctk.CTkFrame(line_container, fg_color="#ffffff", corner_radius=12, border_width=1, border_color="#e2e8f0")
            row.grid_columnconfigure(0, weight=3)
            row.grid_columnconfigure(1, weight=1)
            row.grid_columnconfigure(2, weight=1)
            row.grid_columnconfigure(3, weight=0)
            row.grid_rowconfigure(0, weight=1)

            selected_ingredient_label = default_data["ingredient_label"] if default_data else ingredient_options[0]
            ingredient_var = ctk.StringVar(value=selected_ingredient_label)
            ingredient_menu = ctk.CTkOptionMenu(row, values=ingredient_options, variable=ingredient_var, width=260, fg_color="#ffffff", button_color="#ffffff", button_hover_color="#e0ecff", text_color="#111827")
            ingredient_menu.grid(row=0, column=0, padx=(12, 8), pady=10, sticky="ew")

            quantity_entry = ctk.CTkEntry(row, placeholder_text="Qty", width=100)
            quantity_entry.grid(row=0, column=1, padx=(0, 8), pady=10, sticky="ew")
            if default_data:
                quantity_entry.insert(0, str(default_data["quantity_required"]))

            unit_options = self._compatible_units(ingredient_lookup.get(selected_ingredient_label))
            unit_var = ctk.StringVar(value=default_data["unit"] if default_data else unit_options[0])
            unit_menu = ctk.CTkOptionMenu(row, values=unit_options, variable=unit_var, width=120, fg_color="#ffffff", button_color="#ffffff", button_hover_color="#e0ecff", text_color="#111827")
            unit_menu.grid(row=0, column=2, padx=(0, 8), pady=10, sticky="ew")

            def refresh_units(*_args):
                selected_name = ingredient_var.get()
                selected_ingredient = ingredient_lookup.get(selected_name)
                options = self._compatible_units(selected_ingredient)
                unit_menu.configure(values=options)
                if unit_var.get() not in options:
                    unit_var.set(options[0])

            ingredient_var.trace_add("write", refresh_units)
            remove_button = ctk.CTkButton(row, text="Remove", command=lambda target=row: target.destroy(), fg_color="#fee2e2", hover_color="#fecaca", text_color="#7f1d1d", width=90)
            remove_button.grid(row=0, column=3, padx=(0, 12), pady=10, sticky="e")
            line_rows.append({"row": row, "ingredient_var": ingredient_var, "quantity_entry": quantity_entry, "unit_var": unit_var, "remove_button": remove_button})
            row.grid(sticky="ew", pady=6)

        if recipe:
            for ingredient in recipe["ingredients"]:
                ingredient_label = next((label for label, record in ingredient_lookup.items() if record["ingredient_id"] == ingredient["ingredient_id"]), ingredient_lookup[next(iter(ingredient_lookup))]["ingredient_id"])
                add_line({
                    "ingredient_label": ingredient_label,
                    "quantity_required": ingredient["quantity_required"],
                    "unit": ingredient.get("unit") or ingredient_lookup[next(iter(ingredient_lookup))]["unit"],
                })
        else:
            add_line()

        button_row = ctk.CTkFrame(form_frame, fg_color="transparent")
        button_row.grid(row=3, column=0, padx=18, pady=(0, 18), sticky="ew")
        button_row.grid_columnconfigure((0, 1, 2), weight=1)

        ctk.CTkButton(button_row, text="Add Ingredient Line", command=add_line, fg_color="#dbeafe", hover_color="#bfdbfe", text_color="#0f172a", height=36).grid(row=0, column=0, padx=(0, 8), sticky="w")
        ctk.CTkButton(button_row, text="Save Recipe", command=lambda: self._save_recipe_from_form(dialog, menu_var, menu_lookup, line_rows, recipe), fg_color="#10B981", hover_color="#059669", height=36).grid(row=0, column=1, padx=8, sticky="e")
        ctk.CTkButton(button_row, text="Cancel", command=dialog.destroy, fg_color="#f8fafc", hover_color="#eef2ff", text_color="#0f172a", border_width=1, border_color="#dfeaf8", height=36).grid(row=0, column=2, padx=(8, 0), sticky="e")

        dialog.protocol("WM_DELETE_WINDOW", dialog.destroy)

    def _save_recipe_from_form(self, dialog, menu_var, menu_lookup, line_rows, recipe):
        menu_label = menu_var.get().strip()
        if not menu_label:
            self._show_message("A menu item is required.", True)
            return
        menu_item_id = menu_lookup.get(menu_label)
        if not menu_item_id:
            self._show_message("Select a valid menu item from this café's menu.", True)
            return

        ingredient_lookup = self._ingredient_options()[1]
        ingredient_lines = []
        seen_ingredient_ids = set()
        for row_data in line_rows:
            ingredient_label = row_data["ingredient_var"].get().strip()
            ingredient_record = ingredient_lookup.get(ingredient_label)
            if ingredient_record is None:
                self._show_message("Each ingredient line must reference a valid café inventory item.", True)
                return
            ingredient_id = ingredient_record["ingredient_id"]
            if ingredient_id in seen_ingredient_ids:
                self._show_message("Duplicate ingredient lines are not allowed unless deliberately combined.", True)
                return
            seen_ingredient_ids.add(ingredient_id)

            quantity_text = row_data["quantity_entry"].get().strip()
            try:
                quantity = float(quantity_text)
            except ValueError:
                self._show_message(f"Enter a valid quantity for {ingredient_record['name']}.", True)
                return
            if quantity <= 0:
                self._show_message(f"Quantity for {ingredient_record['name']} must be greater than zero.", True)
                return

            unit = row_data["unit_var"].get().strip()
            ingredient_lines.append({
                "ingredient_id": ingredient_id,
                "ingredient_name": ingredient_record["name"],
                "quantity_required": quantity,
                "unit": unit,
            })

        if not ingredient_lines:
            self._show_message("At least one ingredient line is required.", True)
            return

        if recipe:
            result = update_recipe(session.current_cafe_id, recipe["recipe_id"], ingredient_lines)
        else:
            result = add_recipe(session.current_cafe_id, menu_item_id, ingredient_lines)

        if not result["success"]:
            self._show_message(result["message"], True)
            return

        dialog.destroy()
        self.refresh()
        self._show_message(result["message"])

    def view_recipe(self, recipe):
        recipe_details = get_recipe_by_id(session.current_cafe_id, recipe["recipe_id"])
        if not recipe_details:
            self._show_message("Recipe could not be found.", True)
            return

        popup = ctk.CTkToplevel(self)
        popup.title(f"Recipe: {recipe_details['menu_item_name']}")
        popup.geometry("560x480")
        popup.configure(fg_color="#f8fafc")
        popup.transient(self.winfo_toplevel())
        popup.grab_set()

        ctk.CTkLabel(popup, text=recipe_details["menu_item_name"], font=("Segoe UI", 22, "bold"), text_color="#111827", anchor="w").pack(anchor="w", padx=18, pady=(18, 4))
        ctk.CTkLabel(popup, text=f"Recipe ID: {recipe_details['recipe_id']} • {self._safe_recipe_cost(recipe_details)}", text_color="#475569", font=("Segoe UI", 12), anchor="w").pack(anchor="w", padx=18, pady=(0, 12))

        area = ctk.CTkScrollableFrame(popup, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
        area.pack(fill="both", expand=True, padx=18, pady=(0, 18))
        area.grid_columnconfigure(0, weight=1)

        if not recipe_details.get("ingredients"):
            ctk.CTkLabel(area, text="No ingredient lines saved for this recipe yet.", text_color="#475569", font=("Segoe UI", 12), anchor="w").grid(row=0, column=0, padx=18, pady=18, sticky="w")
            return

        for index, ingredient in enumerate(recipe_details["ingredients"], start=1):
            row = ctk.CTkFrame(area, fg_color="#f8fafc", corner_radius=10, border_width=1, border_color="#e2e8f0")
            row.grid(row=index, column=0, padx=16, pady=8, sticky="ew")
            row.grid_columnconfigure(0, weight=2)
            row.grid_columnconfigure(1, weight=1)
            ctk.CTkLabel(row, text=f"{ingredient['ingredient_name']}", text_color="#111827", font=("Segoe UI", 12, "bold"), anchor="w").grid(row=0, column=0, padx=12, pady=10, sticky="w")
            ctk.CTkLabel(row, text=f"{ingredient['quantity_required']} {ingredient['unit']}", text_color="#475569", font=("Segoe UI", 11), anchor="e").grid(row=0, column=1, padx=12, pady=10, sticky="e")

    def edit_recipe(self, recipe):
        self._open_recipe_form(recipe)

    def refresh(self):
        for widget in self.winfo_children():
            widget.destroy()

        header = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        header.grid(row=0, column=0, padx=28, pady=(22, 18), sticky="ew")
        header.grid_columnconfigure(0, weight=1)
        header.grid_columnconfigure(1, weight=0)

        title = ctk.CTkLabel(header, text="Recipe Management", font=("Segoe UI", 25, "bold"), text_color="#111827", anchor="w")
        title.grid(row=0, column=0, padx=18, pady=(18, 16), sticky="w")

        add_button = ctk.CTkButton(header, text="Add Recipe", command=self._open_recipe_form, fg_color="#2563EB", hover_color="#1d4f91", height=38, corner_radius=10)
        add_button.grid(row=0, column=1, padx=(0, 18), pady=(18, 16), sticky="e")

        subtitle = ctk.CTkLabel(self, text="Menu item recipes, ingredient lines, and estimated ingredient cost.", font=("Segoe UI", 12), text_color="#475569", anchor="w")
        subtitle.grid(row=1, column=0, padx=28, pady=(0, 12), sticky="w")

        stats = get_recipe_dashboard(session.current_cafe_id)
        cards = ctk.CTkFrame(self, fg_color="transparent")
        cards.grid(row=2, column=0, padx=28, pady=(0, 16), sticky="ew")
        cards.grid_columnconfigure((0, 1, 2), weight=1)
        for idx, value in enumerate([("Total Recipes", stats["total_recipes"]), ("Complete", stats["complete_recipes"]), ("Incomplete", stats["incomplete_recipes"]) ]):
            card = ctk.CTkFrame(cards, corner_radius=16, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
            card.grid(row=0, column=idx, padx=8, sticky="ew")
            card.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(card, text=value[0], text_color="#475569", font=("Segoe UI", 12), anchor="w").grid(row=0, column=0, padx=18, pady=(14, 0), sticky="w")
            ctk.CTkLabel(card, text=str(value[1]), text_color="#111827", font=("Segoe UI", 24, "bold"), anchor="w").grid(row=1, column=0, padx=18, pady=(10, 16), sticky="w")

        container = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        container.grid(row=3, column=0, padx=28, pady=(0, 28), sticky="nsew")
        container.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(container, text="Recipes", font=("Segoe UI", 18, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 8), sticky="w")
        rows = list_recipes(session.current_cafe_id)
        if not rows:
            ctk.CTkLabel(container, text="No recipe records yet for this café.", text_color="#475569", font=("Segoe UI", 12), anchor="w").grid(row=1, column=0, padx=18, pady=(0, 18), sticky="w")
            return

        for index, recipe in enumerate(rows, start=1):
            row = ctk.CTkFrame(container, fg_color="#f8fafc")
            row.grid(row=index, column=0, padx=18, pady=8, sticky="ew")
            row.grid_columnconfigure(0, weight=2)
            row.grid_columnconfigure(1, weight=1)
            row.grid_columnconfigure(2, weight=0)
            row.grid_columnconfigure(3, weight=0)

            badge_text = "Complete" if recipe.get("is_complete") else "Incomplete"
            badge_fg = "#dcfce7" if recipe.get("is_complete") else "#fee2e2"
            badge_text_color = "#166534" if recipe.get("is_complete") else "#991b1b"
            badge = ctk.CTkLabel(row, text=badge_text, text_color=badge_text_color, fg_color=badge_fg, corner_radius=8, padx=8, pady=4, font=("Segoe UI", 10, "bold"))
            badge.grid(row=0, column=0, padx=(12, 8), pady=10, sticky="w")

            ctk.CTkLabel(row, text=f"{recipe['menu_item_name']} ({recipe['recipe_id']})", text_color="#111827", font=("Segoe UI", 12, "bold"), anchor="w").grid(row=0, column=1, padx=(0, 8), pady=10, sticky="w")
            ctk.CTkLabel(row, text=f"{recipe['ingredient_count']} ingredients • {self._safe_recipe_cost(recipe)}", text_color="#475569", font=("Segoe UI", 11), anchor="e").grid(row=0, column=2, padx=(0, 8), pady=10, sticky="e")

            actions = ctk.CTkFrame(row, fg_color="transparent")
            actions.grid(row=0, column=3, padx=(0, 12), pady=8, sticky="e")
            ctk.CTkButton(actions, text="View", command=lambda recipe=recipe: self.view_recipe(recipe), height=28, corner_radius=8, fg_color="#e0ecff", hover_color="#d0e3ff", text_color="#0f172a").grid(row=0, column=0, padx=(0, 8), sticky="w")
            ctk.CTkButton(actions, text="Edit", command=lambda recipe=recipe: self.edit_recipe(recipe), height=28, corner_radius=8, fg_color="#dcfce7", hover_color="#bbf7d0", text_color="#14532d").grid(row=0, column=1, sticky="w")


class SupplierDirectoryPage(ctk.CTkScrollableFrame):
    """Supplier directory page for supplier catalog and state management."""

    def __init__(self, master, app):
        super().__init__(master, corner_radius=0, fg_color="#f4f7fb")
        self.app = app
        self.grid_columnconfigure(0, weight=1)
        self.search_var = ctk.StringVar(value="")
        self.category_var = ctk.StringVar(value="All")
        self.status_var = ctk.StringVar(value="All")
        self.refresh()

    def _show_message(self, message, is_error=False):
        from tkinter import messagebox

        if is_error:
            messagebox.showerror("Supplier Directory", message)
        else:
            messagebox.showinfo("Supplier Directory", message)

    def _open_supplier_form(self, supplier=None):
        dialog = ctk.CTkToplevel(self)
        dialog.title("Edit Supplier" if supplier else "Add Supplier")
        dialog.geometry("640x560")
        dialog.configure(fg_color="#f8fafc")
        dialog.transient(self.winfo_toplevel())
        dialog.grab_set()

        form = ctk.CTkFrame(dialog, fg_color="#ffffff", corner_radius=18, border_width=1, border_color="#dfeaf8")
        form.pack(fill="both", expand=True, padx=18, pady=18)
        form.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(form, text="Supplier Details", font=("Segoe UI", 22, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 10), sticky="w")

        fields = {
            "supplier_name": ctk.CTkEntry(form, placeholder_text="Supplier Name", height=38),
            "contact_person": ctk.CTkEntry(form, placeholder_text="Contact Person", height=38),
            "phone": ctk.CTkEntry(form, placeholder_text="Phone", height=38),
            "email": ctk.CTkEntry(form, placeholder_text="Email", height=38),
            "address": ctk.CTkEntry(form, placeholder_text="Address", height=38),
            "notes": ctk.CTkEntry(form, placeholder_text="Notes", height=38),
        }
        category_var = ctk.StringVar(value=supplier["category"] if supplier else "Coffee and Beverages")
        fields["category"] = ctk.CTkOptionMenu(form, values=VALID_CATEGORIES, variable=category_var, width=240)

        for index, widget in enumerate(fields.values(), start=1):
            widget.grid(row=index, column=0, padx=18, pady=8, sticky="ew")

        if supplier:
            fields["supplier_name"].insert(0, supplier.get("supplier_name", ""))
            fields["contact_person"].insert(0, supplier.get("contact_person", ""))
            fields["phone"].insert(0, supplier.get("phone", ""))
            fields["email"].insert(0, supplier.get("email", ""))
            fields["address"].insert(0, supplier.get("address", ""))
            fields["notes"].insert(0, supplier.get("notes", ""))
            category_var.set(supplier.get("category", "Coffee and Beverages"))

        actions = ctk.CTkFrame(form, fg_color="transparent")
        actions.grid(row=8, column=0, padx=18, pady=(8, 18), sticky="ew")
        actions.grid_columnconfigure((0, 1), weight=1)

        save_btn = ctk.CTkButton(actions, text="Save Supplier", command=lambda: self._save_supplier(dialog, supplier, fields, category_var), fg_color="#10B981", hover_color="#059669", height=38)
        save_btn.grid(row=0, column=0, padx=(0, 8), sticky="e")
        cancel_btn = ctk.CTkButton(actions, text="Cancel", command=dialog.destroy, fg_color="#f8fafc", hover_color="#eef2ff", text_color="#111827", border_width=1, border_color="#dfeaf8", height=38)
        cancel_btn.grid(row=0, column=1, padx=(8, 0), sticky="e")

    def _save_supplier(self, dialog, supplier, fields, category_var):
        payload = {
            "supplier_name": fields["supplier_name"].get().strip(),
            "contact_person": fields["contact_person"].get().strip(),
            "phone": fields["phone"].get().strip(),
            "email": fields["email"].get().strip(),
            "address": fields["address"].get().strip(),
            "category": category_var.get().strip(),
            "notes": fields["notes"].get().strip(),
        }
        if not payload["supplier_name"]:
            self._show_message("Supplier name is required.", True)
            return
        if supplier:
            result = update_supplier(session.current_cafe_id, supplier["supplier_id"], **payload)
        else:
            result = add_supplier(session.current_cafe_id, **payload)
        if not result["success"]:
            self._show_message(result["message"], True)
            return
        dialog.destroy()
        self.refresh()
        self._show_message(result["message"])

    def view_supplier(self, supplier):
        details = get_supplier_by_id(session.current_cafe_id, supplier["supplier_id"])
        if not details:
            self._show_message("Supplier could not be found.", True)
            return
        popup = ctk.CTkToplevel(self)
        popup.title(f"Supplier: {details['supplier_name']}")
        popup.geometry("520x420")
        popup.configure(fg_color="#f8fafc")
        popup.transient(self.winfo_toplevel())
        popup.grab_set()

        ctk.CTkLabel(popup, text=details["supplier_name"], font=("Segoe UI", 22, "bold"), text_color="#111827", anchor="w").pack(anchor="w", padx=18, pady=(18, 4))
        ctk.CTkLabel(popup, text=f"{details['category']} • {'Active' if details['is_active'] else 'Inactive'}", text_color="#475569", font=("Segoe UI", 12), anchor="w").pack(anchor="w", padx=18, pady=(0, 12))

        info = ctk.CTkScrollableFrame(popup, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        info.pack(fill="both", expand=True, padx=18, pady=(0, 18))
        info.grid_columnconfigure(0, weight=1)
        fields = [
            ("Contact person", details.get("contact_person") or "—"),
            ("Phone", details.get("phone") or "—"),
            ("Email", details.get("email") or "—"),
            ("Address", details.get("address") or "—"),
            ("Notes", details.get("notes") or "—"),
        ]
        for idx, (label, value) in enumerate(fields, start=1):
            ctk.CTkLabel(info, text=f"{label}: {value}", text_color="#111827", font=("Segoe UI", 11), anchor="w", justify="left", wraplength=440).grid(row=idx, column=0, padx=16, pady=8, sticky="w")

    def toggle_supplier(self, supplier):
        if supplier.get("is_active"):
            result = deactivate_supplier(session.current_cafe_id, supplier["supplier_id"])
        else:
            result = reactivate_supplier(session.current_cafe_id, supplier["supplier_id"])
        if not result["success"]:
            self._show_message(result["message"], True)
            return
        self.refresh()
        self._show_message(result["message"])

    def refresh(self):
        for widget in self.winfo_children():
            widget.destroy()

        header = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        header.grid(row=0, column=0, padx=28, pady=(22, 18), sticky="ew")
        header.grid_columnconfigure(0, weight=1)
        header.grid_columnconfigure(1, weight=0)
        ctk.CTkLabel(header, text="Supplier Directory", font=("Segoe UI", 25, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 8), sticky="w")
        ctk.CTkButton(header, text="Add Supplier", command=self._open_supplier_form, fg_color="#2563EB", hover_color="#1d4f91", height=38, corner_radius=10).grid(row=0, column=1, padx=(0, 18), pady=(18, 8), sticky="e")

        ctk.CTkLabel(self, text="Manage your café's suppliers and purchasing relationships.", font=("Segoe UI", 12), text_color="#475569", anchor="w").grid(row=1, column=0, padx=28, pady=(0, 12), sticky="w")

        suppliers = list_suppliers(
            session.current_cafe_id,
            search=self.search_var.get() if hasattr(self, "search_var") else "",
            status=self.status_var.get() if hasattr(self, "status_var") else "All",
            category=self.category_var.get() if hasattr(self, "category_var") else "All",
        )
        cards = ctk.CTkFrame(self, fg_color="transparent")
        cards.grid(row=2, column=0, padx=28, pady=(0, 16), sticky="ew")
        cards.grid_columnconfigure((0, 1, 2), weight=1)
        all_suppliers = list_suppliers(session.current_cafe_id)
        metrics = [
            ("Total Suppliers", len(all_suppliers)),
            ("Active", sum(1 for item in all_suppliers if item.get("is_active"))),
            ("Inactive", sum(1 for item in all_suppliers if not item.get("is_active"))),
        ]
        for idx, (label, value) in enumerate(metrics):
            card = ctk.CTkFrame(cards, corner_radius=16, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
            card.grid(row=0, column=idx, padx=8, sticky="ew")
            card.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(card, text=label, text_color="#475569", font=("Segoe UI", 12), anchor="w").grid(row=0, column=0, padx=18, pady=(14, 0), sticky="w")
            ctk.CTkLabel(card, text=str(value), text_color="#111827", font=("Segoe UI", 24, "bold"), anchor="w").grid(row=1, column=0, padx=18, pady=(10, 16), sticky="w")

        toolbar = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        toolbar.grid(row=3, column=0, padx=28, pady=(0, 16), sticky="ew")
        toolbar.grid_columnconfigure((0, 1, 2), weight=1)
        ctk.CTkEntry(toolbar, textvariable=self.search_var, placeholder_text="Search suppliers", height=38).grid(row=0, column=0, padx=16, pady=16, sticky="ew")
        category_menu = ctk.CTkOptionMenu(toolbar, values=["All", *VALID_CATEGORIES], variable=self.category_var, command=lambda *_: self.refresh())
        category_menu.grid(row=0, column=1, padx=(0, 10), pady=16, sticky="ew")
        status_menu = ctk.CTkOptionMenu(toolbar, values=["All", "Active", "Inactive"], variable=self.status_var, command=lambda *_: self.refresh())
        status_menu.grid(row=0, column=2, padx=(0, 16), pady=16, sticky="ew")
        self.search_var.trace_add("write", lambda *_: self.refresh())

        container = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        container.grid(row=4, column=0, padx=28, pady=(0, 28), sticky="nsew")
        container.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(container, text="Suppliers", font=("Segoe UI", 18, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 8), sticky="w")
        if not suppliers:
            ctk.CTkLabel(container, text="No suppliers match the active filters for this café.", text_color="#475569", font=("Segoe UI", 12), anchor="w").grid(row=1, column=0, padx=18, pady=(0, 18), sticky="w")
            return

        for index, supplier in enumerate(suppliers, start=1):
            row = ctk.CTkFrame(container, fg_color="#f8fafc")
            row.grid(row=index, column=0, padx=18, pady=8, sticky="ew")
            row.grid_columnconfigure((0, 1, 2, 3), weight=1)
            ctk.CTkLabel(row, text=f"{supplier['supplier_name']}", text_color="#111827", font=("Segoe UI", 12, "bold"), anchor="w").grid(row=0, column=0, padx=12, pady=10, sticky="w")
            ctk.CTkLabel(row, text=f"{supplier['category']}", text_color="#475569", anchor="w").grid(row=0, column=1, padx=12, pady=10, sticky="w")
            ctk.CTkLabel(row, text=f"{supplier.get('contact_person') or '—'}", text_color="#475569", anchor="w").grid(row=0, column=2, padx=12, pady=10, sticky="w")
            ctk.CTkLabel(row, text=f"{supplier.get('phone') or '—'}", text_color="#475569", anchor="w").grid(row=0, column=3, padx=12, pady=10, sticky="w")
            status_label = "Active" if supplier.get("is_active") else "Inactive"
            status_fg = "#dcfce7" if supplier.get("is_active") else "#fee2e2"
            status_text = "#166534" if supplier.get("is_active") else "#991b1b"
            ctk.CTkLabel(row, text=status_label, text_color=status_text, fg_color=status_fg, corner_radius=8, padx=8, pady=4, font=("Segoe UI", 10, "bold")).grid(row=1, column=0, padx=12, pady=(0, 10), sticky="w")
            ctk.CTkLabel(row, text=f"{supplier.get('email') or '—'}", text_color="#475569", anchor="w").grid(row=1, column=1, columnspan=2, padx=12, pady=(0, 10), sticky="w")

            actions = ctk.CTkFrame(row, fg_color="transparent")
            actions.grid(row=0, column=4, rowspan=2, padx=(0, 12), pady=10, sticky="e")
            ctk.CTkButton(actions, text="View", command=lambda item=supplier: self.view_supplier(item), width=70, height=28, fg_color="#e0ecff", hover_color="#d5e7ff", text_color="#111827").grid(row=0, column=0, padx=(0, 6), sticky="w")
            ctk.CTkButton(actions, text="Edit", command=lambda item=supplier: self._open_supplier_form(item), width=70, height=28, fg_color="#dcfce7", hover_color="#bbf7d0", text_color="#14532d").grid(row=0, column=1, padx=(0, 6), sticky="w")
            ctk.CTkButton(actions, text="Deactivate" if supplier.get("is_active") else "Activate", command=lambda item=supplier: self.toggle_supplier(item), width=80, height=28, fg_color="#f1f5f9", hover_color="#e2e8f0", text_color="#111827").grid(row=0, column=2, sticky="w")


class PurchaseManagementPage(ctk.CTkScrollableFrame):
    """Purchase management page for supplier orders and goods receipts."""

    def __init__(self, master, app):
        super().__init__(master, corner_radius=0, fg_color="#f4f7fb")
        self.app = app
        self.grid_columnconfigure(0, weight=1)
        self.search_var = ctk.StringVar(value="")
        self.status_var = ctk.StringVar(value="All")
        self.refresh()

    def _show_message(self, message, is_error=False):
        from tkinter import messagebox

        if is_error:
            messagebox.showerror("Purchase Management", message)
        else:
            messagebox.showinfo("Purchase Management", message)

    def _open_purchase_form(self):
        if not session.current_cafe_id:
            self._show_message("No active café is selected.", True)
            return

        suppliers = list_suppliers(session.current_cafe_id, status="Active")
        ingredients = list_ingredients(session.current_cafe_id)
        if not suppliers:
            self._show_message("Add at least one active supplier before creating a purchase.", True)
            return
        if not ingredients:
            self._show_message("Add at least one inventory ingredient before creating a purchase.", True)
            return

        dialog = ctk.CTkToplevel(self)
        dialog.title("Create Purchase")
        dialog.geometry("820x620")
        dialog.configure(fg_color="#f8fafc")
        dialog.transient(self.winfo_toplevel())
        dialog.grab_set()

        form = ctk.CTkFrame(dialog, fg_color="#ffffff", border_width=1, border_color="#dfeaf8", corner_radius=18)
        form.pack(fill="both", expand=True, padx=18, pady=18)
        form.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(form, text="Purchase Details", font=("Segoe UI", 22, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 10), sticky="w")

        supplier_var = ctk.StringVar(value=suppliers[0]["supplier_name"])
        supplier_menu = ctk.CTkOptionMenu(form, values=[item["supplier_name"] for item in suppliers], variable=supplier_var, width=260)
        supplier_menu.grid(row=1, column=0, padx=18, pady=(0, 12), sticky="ew")

        date_entry = ctk.CTkEntry(form, placeholder_text="Expected Delivery Date (YYYY-MM-DD)", height=38)
        date_entry.grid(row=2, column=0, padx=18, pady=(0, 12), sticky="ew")

        notes_entry = ctk.CTkEntry(form, placeholder_text="Notes (optional)", height=38)
        notes_entry.grid(row=3, column=0, padx=18, pady=(0, 12), sticky="ew")

        line_container = ctk.CTkScrollableFrame(form, fg_color="#f8fafc", border_width=1, border_color="#dfeaf8")
        line_container.grid(row=4, column=0, padx=18, pady=(0, 12), sticky="nsew")
        line_container.grid_columnconfigure((0, 1, 2, 3), weight=1)
        line_rows = []

        def add_line(default_data=None):
            row = ctk.CTkFrame(line_container, fg_color="#ffffff", corner_radius=10, border_width=1, border_color="#e2e8f0")
            row.grid_columnconfigure((0, 1, 2, 3), weight=1)
            ingredient_var = ctk.StringVar(value=(default_data or {}).get("ingredient_name") or ingredients[0]["name"])
            ingredient_menu = ctk.CTkOptionMenu(row, values=[item["name"] for item in ingredients], variable=ingredient_var, width=220)
            ingredient_menu.grid(row=0, column=0, padx=12, pady=10, sticky="ew")

            qty_entry = ctk.CTkEntry(row, placeholder_text="Qty", width=120)
            qty_entry.grid(row=0, column=1, padx=8, pady=10, sticky="ew")
            if default_data:
                qty_entry.insert(0, str(default_data.get("ordered_quantity", "")))

            unit_entry = ctk.CTkEntry(row, placeholder_text="Unit", width=120)
            unit_entry.grid(row=0, column=2, padx=8, pady=10, sticky="ew")
            if default_data:
                unit_entry.insert(0, str(default_data.get("unit", ingredients[0]["unit"])))
            else:
                unit_entry.insert(0, ingredients[0]["unit"])

            unit_cost_entry = ctk.CTkEntry(row, placeholder_text="Unit Cost", width=120)
            unit_cost_entry.grid(row=0, column=3, padx=(8, 12), pady=10, sticky="ew")
            if default_data:
                unit_cost_entry.insert(0, str(default_data.get("unit_cost", "")))

            remove_btn = ctk.CTkButton(row, text="Remove", command=lambda target=row: target.destroy(), fg_color="#fee2e2", hover_color="#fecaca", text_color="#7f1d1d", width=80)
            remove_btn.grid(row=0, column=4, padx=(0, 12), pady=10, sticky="e")
            line_rows.append({"row": row, "ingredient_var": ingredient_var, "quantity": qty_entry, "unit": unit_entry, "unit_cost": unit_cost_entry})
            row.grid(sticky="ew", pady=6)

        add_line()

        button_row = ctk.CTkFrame(form, fg_color="transparent")
        button_row.grid(row=5, column=0, padx=18, pady=(0, 18), sticky="ew")
        button_row.grid_columnconfigure((0, 1, 2), weight=1)
        ctk.CTkButton(button_row, text="Add Ingredient Line", command=add_line, fg_color="#dbeafe", hover_color="#bfdbfe", text_color="#0f172a", height=36).grid(row=0, column=0, padx=(0, 8), sticky="w")
        save_btn = ctk.CTkButton(button_row, text="Create Draft", command=lambda: self._save_purchase(dialog, supplier_var, date_entry, notes_entry, line_rows), fg_color="#10B981", hover_color="#059669", height=36)
        save_btn.grid(row=0, column=1, padx=8, sticky="e")
        ctk.CTkButton(button_row, text="Cancel", command=dialog.destroy, fg_color="#f8fafc", hover_color="#eef2ff", text_color="#0f172a", border_width=1, border_color="#dfeaf8", height=36).grid(row=0, column=2, padx=(8, 0), sticky="e")

    def _save_purchase(self, dialog, supplier_var, date_entry, notes_entry, line_rows):
        supplier_name = supplier_var.get().strip()
        supplier = next((item for item in list_suppliers(session.current_cafe_id, status="Active") if item["supplier_name"] == supplier_name), None)
        if not supplier:
            self._show_message("Select a valid active supplier.", True)
            return

        items = []
        seen = set()
        for row_data in line_rows:
            ingredient_name = row_data["ingredient_var"].get().strip()
            ingredient = next((item for item in list_ingredients(session.current_cafe_id) if item["name"] == ingredient_name), None)
            if ingredient is None:
                self._show_message("Each line must reference a valid ingredient.", True)
                return
            if ingredient["ingredient_id"] in seen:
                self._show_message("Duplicate ingredient lines are not allowed in the same purchase.", True)
                return
            seen.add(ingredient["ingredient_id"])
            try:
                qty = float(row_data["quantity"].get().strip())
            except ValueError:
                self._show_message(f"Enter a valid quantity for {ingredient['name']}.", True)
                return
            if qty <= 0:
                self._show_message(f"Quantity for {ingredient['name']} must be greater than zero.", True)
                return
            unit = row_data["unit"].get().strip() or ingredient["unit"]
            try:
                unit_cost = float(row_data["unit_cost"].get().strip())
            except ValueError:
                self._show_message(f"Enter a valid unit cost for {ingredient['name']}.", True)
                return
            if unit_cost < 0:
                self._show_message(f"Unit cost for {ingredient['name']} cannot be negative.", True)
                return
            items.append({
                "ingredient_id": ingredient["ingredient_id"],
                "ingredient_name": ingredient["name"],
                "ordered_quantity": qty,
                "unit": unit,
                "unit_cost": unit_cost,
            })
        if not items:
            self._show_message("At least one ingredient line is required.", True)
            return

        result = create_purchase(
            cafe_id=session.current_cafe_id,
            supplier_id=supplier["supplier_id"],
            expected_date=date_entry.get().strip(),
            items=items,
            notes=notes_entry.get().strip(),
            created_by=session.current_user_id or "system",
            status="Draft",
        )
        if not result["success"]:
            self._show_message(result["message"], True)
            return
        dialog.destroy()
        self.refresh()
        self._show_message(result["message"])

    def view_purchase(self, purchase):
        details = get_purchase_by_id(session.current_cafe_id, purchase["purchase_id"])
        if not details:
            self._show_message("Purchase record could not be found.", True)
            return
        supplier = get_supplier_by_id(session.current_cafe_id, details["supplier_id"])
        popup = ctk.CTkToplevel(self)
        popup.title(f"Purchase {details['purchase_id']}")
        popup.geometry("620x500")
        popup.configure(fg_color="#f8fafc")
        popup.transient(self.winfo_toplevel())
        popup.grab_set()
        ctk.CTkLabel(popup, text=f"{details['purchase_id']} • {supplier['supplier_name'] if supplier else 'Supplier'}", font=("Segoe UI", 22, "bold"), text_color="#111827", anchor="w").pack(anchor="w", padx=18, pady=(18, 4))
        ctk.CTkLabel(popup, text=f"Status: {details['status']} • Subtotal: ₹{float(details['subtotal'] or 0):,.2f}", text_color="#475569", font=("Segoe UI", 12), anchor="w").pack(anchor="w", padx=18, pady=(0, 12))

        area = ctk.CTkScrollableFrame(popup, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        area.pack(fill="both", expand=True, padx=18, pady=(0, 18))
        area.grid_columnconfigure(0, weight=1)
        for idx, item in enumerate(details.get("items", []), start=1):
            row = ctk.CTkFrame(area, fg_color="#f8fafc", border_width=1, border_color="#e2e8f0", corner_radius=10)
            row.grid(row=idx, column=0, padx=16, pady=8, sticky="ew")
            row.grid_columnconfigure((0, 1), weight=1)
            ctk.CTkLabel(row, text=f"{item['ingredient_name']} • {item['ordered_quantity']} {item['unit']}", text_color="#111827", font=("Segoe UI", 12, "bold"), anchor="w").grid(row=0, column=0, padx=12, pady=10, sticky="w")
            ctk.CTkLabel(row, text=f"Received: {item['received_quantity']} • Total: ₹{float(item['line_total'] or 0):,.2f}", text_color="#475569", font=("Segoe UI", 11), anchor="e").grid(row=0, column=1, padx=12, pady=10, sticky="e")

    def mark_ordered(self, purchase):
        result = update_purchase_status(session.current_cafe_id, purchase["purchase_id"], "Ordered")
        if not result["success"]:
            self._show_message(result["message"], True)
            return
        self.refresh()
        self._show_message(result["message"])

    def cancel_purchase_record(self, purchase):
        result = cancel_purchase(session.current_cafe_id, purchase["purchase_id"])
        if not result["success"]:
            self._show_message(result["message"], True)
            return
        self.refresh()
        self._show_message(result["message"])

    def receive_goods(self, purchase):
        details = get_purchase_by_id(session.current_cafe_id, purchase["purchase_id"])
        if not details:
            self._show_message("Purchase record could not be found.", True)
            return
        if details["status"] not in {"Ordered", "Partially Received"}:
            self._show_message("Only ordered purchases can receive goods.", True)
            return

        dialog = ctk.CTkToplevel(self)
        dialog.title(f"Receive Goods: {details['purchase_id']}")
        dialog.geometry("700x520")
        dialog.configure(fg_color="#f8fafc")
        dialog.transient(self.winfo_toplevel())
        dialog.grab_set()

        form = ctk.CTkFrame(dialog, fg_color="#ffffff", border_width=1, border_color="#dfeaf8", corner_radius=18)
        form.pack(fill="both", expand=True, padx=18, pady=18)
        form.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(form, text="Receive Goods", font=("Segoe UI", 22, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 10), sticky="w")

        line_container = ctk.CTkScrollableFrame(form, fg_color="#f8fafc", border_width=1, border_color="#dfeaf8")
        line_container.grid(row=1, column=0, padx=18, pady=(0, 12), sticky="nsew")
        line_container.grid_columnconfigure((0, 1, 2, 3), weight=1)
        entries = []
        for idx, item in enumerate(details["items"], start=1):
            row = ctk.CTkFrame(line_container, fg_color="#ffffff", corner_radius=10, border_width=1, border_color="#e2e8f0")
            row.grid(row=idx, column=0, padx=12, pady=8, sticky="ew")
            row.grid_columnconfigure((0, 1, 2, 3), weight=1)
            ordered = float(item.get("ordered_quantity") or 0)
            received = float(item.get("received_quantity") or 0)
            remaining = ordered - received
            ctk.CTkLabel(row, text=f"{item['ingredient_name']}", text_color="#111827", font=("Segoe UI", 12, "bold"), anchor="w").grid(row=0, column=0, padx=12, pady=10, sticky="w")
            ctk.CTkLabel(row, text=f"Ordered {ordered} {item['unit']} • Remaining {remaining}", text_color="#475569", font=("Segoe UI", 10), anchor="w").grid(row=1, column=0, padx=12, pady=(0, 10), sticky="w")
            qty_field = ctk.CTkEntry(row, placeholder_text="Receive qty", width=120)
            qty_field.grid(row=0, column=1, padx=8, pady=10, sticky="ew")
            qty_field.insert(0, str(max(0, remaining)))
            entries.append({"ingredient_id": item["ingredient_id"], "quantity": qty_field, "ingredient_name": item["ingredient_name"], "unit": item["unit"]})

        def submit_receipt():
            received_items = []
            for record in entries:
                try:
                    qty = float(record["quantity"].get().strip())
                except ValueError:
                    self._show_message(f"Enter a valid quantity for {record['ingredient_name']}.", True)
                    return
                if qty <= 0:
                    continue
                received_items.append({
                    "ingredient_id": record["ingredient_id"],
                    "ingredient_name": record["ingredient_name"],
                    "quantity_received": qty,
                    "unit": record["unit"],
                })
            if not received_items:
                self._show_message("Enter at least one quantity to receive.", True)
                return
            result = record_receipt(session.current_cafe_id, details["purchase_id"], received_items, session.current_user_id or "system")
            if not result["success"]:
                self._show_message(result["message"], True)
                return
            dialog.destroy()
            self.refresh()
            self._show_message(result["message"])

        actions = ctk.CTkFrame(form, fg_color="transparent")
        actions.grid(row=2, column=0, padx=18, pady=(0, 18), sticky="ew")
        actions.grid_columnconfigure((0, 1), weight=1)
        ctk.CTkButton(actions, text="Confirm Receipt", command=submit_receipt, fg_color="#2563EB", hover_color="#1d4f91", height=36).grid(row=0, column=0, padx=(0, 8), sticky="e")
        ctk.CTkButton(actions, text="Cancel", command=dialog.destroy, fg_color="#f8fafc", hover_color="#eef2ff", text_color="#111827", border_width=1, border_color="#dfeaf8", height=36).grid(row=0, column=1, padx=(8, 0), sticky="e")

    def refresh(self):
        for widget in self.winfo_children():
            widget.destroy()

        header = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        header.grid(row=0, column=0, padx=28, pady=(22, 18), sticky="ew")
        header.grid_columnconfigure(0, weight=1)
        header.grid_columnconfigure(1, weight=0)
        ctk.CTkLabel(header, text="Purchase Management", font=("Segoe UI", 25, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 8), sticky="w")
        ctk.CTkButton(header, text="Create Purchase", command=self._open_purchase_form, fg_color="#2563EB", hover_color="#1d4f91", height=38, corner_radius=10).grid(row=0, column=1, padx=(0, 18), pady=(18, 8), sticky="e")

        ctk.CTkLabel(self, text="Manage supplier orders, incoming ingredients and stock replenishment.", font=("Segoe UI", 12), text_color="#475569", anchor="w").grid(row=1, column=0, padx=28, pady=(0, 12), sticky="w")

        summary = get_purchase_summary(session.current_cafe_id)
        cards = ctk.CTkFrame(self, fg_color="transparent")
        cards.grid(row=2, column=0, padx=28, pady=(0, 16), sticky="ew")
        cards.grid_columnconfigure((0, 1, 2, 3), weight=1)
        metrics = [
            ("Total Purchases", summary["total_purchases"]),
            ("Draft Purchases", summary["draft_purchases"]),
            ("Awaiting Delivery", summary.get("awaiting_delivery_purchases", 0)),
            ("Received Purchases", summary["received_purchases"]),
        ]
        for idx, (label, value) in enumerate(metrics):
            card = ctk.CTkFrame(cards, corner_radius=16, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
            card.grid(row=0, column=idx, padx=8, sticky="ew")
            card.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(card, text=label, text_color="#475569", font=("Segoe UI", 12), anchor="w").grid(row=0, column=0, padx=18, pady=(14, 0), sticky="w")
            ctk.CTkLabel(card, text=str(value), text_color="#111827", font=("Segoe UI", 24, "bold"), anchor="w").grid(row=1, column=0, padx=18, pady=(10, 16), sticky="w")

        toolbar = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        toolbar.grid(row=3, column=0, padx=28, pady=(0, 16), sticky="ew")
        toolbar.grid_columnconfigure((0, 1), weight=1)
        ctk.CTkEntry(toolbar, textvariable=self.search_var, placeholder_text="Search by purchase ID or supplier", height=38).grid(row=0, column=0, padx=16, pady=16, sticky="ew")
        status_menu = ctk.CTkOptionMenu(toolbar, values=["All", "Draft", "Ordered", "Partially Received", "Received", "Cancelled"], variable=self.status_var, command=lambda *_: self.refresh())
        status_menu.grid(row=0, column=1, padx=(0, 16), pady=16, sticky="ew")
        self.search_var.trace_add("write", lambda *_: self.refresh())

        all_rows = list_purchases(session.current_cafe_id)
        filtered = []
        search_term = self.search_var.get().strip().lower()
        for purchase in all_rows:
            supplier = get_supplier_by_id(session.current_cafe_id, purchase["supplier_id"])
            supplier_name = supplier["supplier_name"] if supplier else ""
            matches_status = self.status_var.get() == "All" or purchase["status"] == self.status_var.get()
            matches_search = not search_term or search_term in purchase["purchase_id"].lower() or search_term in supplier_name.lower()
            if matches_status and matches_search:
                filtered.append(purchase)

        container = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        container.grid(row=4, column=0, padx=28, pady=(0, 28), sticky="nsew")
        container.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(container, text="Purchase History", font=("Segoe UI", 18, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 8), sticky="w")
        if not filtered:
            ctk.CTkLabel(container, text="No purchase records match the selected filters.", text_color="#475569", font=("Segoe UI", 12), anchor="w").grid(row=1, column=0, padx=18, pady=(0, 18), sticky="w")
            return

        for index, purchase in enumerate(filtered, start=1):
            supplier = get_supplier_by_id(session.current_cafe_id, purchase["supplier_id"])
            row = ctk.CTkFrame(container, fg_color="#f8fafc")
            row.grid(row=index, column=0, padx=18, pady=8, sticky="ew")
            row.grid_columnconfigure((0, 1, 2, 3, 4), weight=1)
            ctk.CTkLabel(row, text=f"{purchase['purchase_id']}", text_color="#111827", font=("Segoe UI", 12, "bold"), anchor="w").grid(row=0, column=0, padx=12, pady=10, sticky="w")
            ctk.CTkLabel(row, text=f"{supplier['supplier_name'] if supplier else 'Supplier'}", text_color="#475569", anchor="w").grid(row=0, column=1, padx=12, pady=10, sticky="w")
            ctk.CTkLabel(row, text=f"{purchase['created_at'][:10]}", text_color="#475569", anchor="w").grid(row=0, column=2, padx=12, pady=10, sticky="w")
            ctk.CTkLabel(row, text=f"₹{float(purchase.get('subtotal') or 0):,.2f}", text_color="#111827", anchor="w").grid(row=0, column=3, padx=12, pady=10, sticky="w")
            status_color = {"Draft": "#fef3c7", "Ordered": "#dbeafe", "Partially Received": "#dcfce7", "Received": "#dcfce7", "Cancelled": "#fee2e2"}.get(purchase["status"], "#f1f5f9")
            status_text = {"Draft": "#92400e", "Ordered": "#1d4ed8", "Partially Received": "#166534", "Received": "#166534", "Cancelled": "#991b1b"}.get(purchase["status"], "#111827")
            ctk.CTkLabel(row, text=purchase["status"], text_color=status_text, fg_color=status_color, corner_radius=8, padx=8, pady=4, font=("Segoe UI", 10, "bold")).grid(row=0, column=4, padx=12, pady=10, sticky="w")

            action_row = ctk.CTkFrame(row, fg_color="transparent")
            action_row.grid(row=1, column=0, columnspan=5, padx=12, pady=(0, 10), sticky="w")
            ctk.CTkButton(action_row, text="View", command=lambda item=purchase: self.view_purchase(item), height=28, width=70, fg_color="#e0ecff", hover_color="#d5e7ff", text_color="#111827").grid(row=0, column=0, padx=(0, 8), sticky="w")
            if purchase["status"] == "Draft":
                ctk.CTkButton(action_row, text="Mark Ordered", command=lambda item=purchase: self.mark_ordered(item), height=28, width=100, fg_color="#dbeafe", hover_color="#bfdbfe", text_color="#1d4ed8").grid(row=0, column=1, padx=(0, 8), sticky="w")
            if purchase["status"] in {"Ordered", "Partially Received"}:
                ctk.CTkButton(action_row, text="Receive Goods", command=lambda item=purchase: self.receive_goods(item), height=28, width=100, fg_color="#dcfce7", hover_color="#bbf7d0", text_color="#14532d").grid(row=0, column=2, padx=(0, 8), sticky="w")
            if purchase["status"] in {"Draft", "Ordered"}:
                ctk.CTkButton(action_row, text="Cancel", command=lambda item=purchase: self.cancel_purchase_record(item), height=28, width=80, fg_color="#fee2e2", hover_color="#fecaca", text_color="#7f1d1d").grid(row=0, column=3, sticky="w")


class MenuManagementPage(ctk.CTkScrollableFrame):
    """Menu management workspace for café owners."""

    def __init__(self, master, app):
        super().__init__(master, corner_radius=0, fg_color="#f4f7fb")
        self.app = app
        self.grid_columnconfigure(0, weight=1)
        self.current_edit_item_id = None

        header = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        header.grid(row=0, column=0, padx=28, pady=(22, 18), sticky="ew")
        header.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            header,
            text="Menu Management",
            font=("Segoe UI", 27, "bold"),
            text_color="#111827",
            anchor="w",
        ).grid(row=0, column=0, padx=18, pady=(18, 4), sticky="w")

        ctk.CTkLabel(
            header,
            text="Manage your café's products, categories and selling prices.",
            font=("Segoe UI", 12),
            text_color="#475569",
            anchor="w",
        ).grid(row=1, column=0, padx=18, pady=(0, 18), sticky="w")

        cards_frame = ctk.CTkFrame(self, corner_radius=18, fg_color="transparent")
        cards_frame.grid(row=1, column=0, padx=28, pady=(0, 16), sticky="ew")
        cards_frame.grid_columnconfigure((0, 1, 2, 3), weight=1)

        self.summary_cards = []
        summary_labels = [
            ("Total Items", "total_items"),
            ("Available Items", "available_items"),
            ("Unavailable Items", "unavailable_items"),
            ("Categories", "category_count"),
        ]
        for idx, (title, key) in enumerate(summary_labels):
            card = ctk.CTkFrame(cards_frame, corner_radius=16, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
            card.grid(row=0, column=idx, padx=10, sticky="ew")
            card.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(card, text=title, text_color="#5a6475", font=("Segoe UI", 12, "normal"), anchor="w").grid(row=0, column=0, padx=16, pady=(18, 0), sticky="w")
            value_label = ctk.CTkLabel(card, text="0", text_color="#0f172a", font=("Segoe UI", 22, "bold"), anchor="w")
            value_label.grid(row=1, column=0, padx=16, pady=(10, 18), sticky="w")
            self.summary_cards.append((key, value_label))

        self.notice_label = ctk.CTkLabel(self, text="", text_color="#0f172a", font=("Segoe UI", 12, "bold"), anchor="w")
        self.notice_label.grid(row=2, column=0, padx=28, pady=(0, 6), sticky="w")

        toolbar = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
        toolbar.grid(row=3, column=0, padx=28, pady=(0, 16), sticky="ew")
        toolbar.grid_columnconfigure(0, weight=2)
        toolbar.grid_columnconfigure(1, weight=1)
        toolbar.grid_columnconfigure(2, weight=1)
        toolbar.grid_columnconfigure(3, weight=0)

        self.search_var = ctk.StringVar(value="")
        self.category_var = ctk.StringVar(value="All")
        self.availability_var = ctk.StringVar(value="All")

        search_entry = ctk.CTkEntry(toolbar, textvariable=self.search_var, placeholder_text="Search items or category", height=38)
        search_entry.grid(row=0, column=0, padx=16, pady=16, sticky="ew")
        search_entry.bind("<KeyRelease>", lambda event: self.refresh_menu())

        category_menu = ctk.CTkOptionMenu(toolbar, values=["All", *ALLOWED_CATEGORIES], variable=self.category_var, command=lambda _value: self.refresh_menu())
        category_menu.grid(row=0, column=1, padx=(0, 10), pady=16, sticky="ew")

        availability_menu = ctk.CTkOptionMenu(toolbar, values=["All", "Available", "Unavailable"], variable=self.availability_var, command=lambda _value: self.refresh_menu())
        availability_menu.grid(row=0, column=2, padx=(0, 10), pady=16, sticky="ew")

        add_item_button = ctk.CTkButton(toolbar, text="Add Item", command=self.show_add_form, height=38, corner_radius=10, fg_color="#2563eb", hover_color="#1d4f91")
        add_item_button.grid(row=0, column=3, padx=(0, 16), pady=16, sticky="e")

        self.form_frame = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        self.form_frame.grid(row=4, column=0, padx=28, pady=(0, 16), sticky="ew")
        self.form_frame.grid_columnconfigure(0, weight=1)
        self.form_frame.grid_remove()

        self.form_title = ctk.CTkLabel(self.form_frame, text="Add Menu Item", font=("Segoe UI", 18, "bold"), text_color="#111827", anchor="w")
        self.form_title.grid(row=0, column=0, padx=18, pady=(18, 8), sticky="w")

        self.form_fields = {
            "item_name": ctk.CTkEntry(self.form_frame, placeholder_text="Item Name", height=38),
            "category": ctk.CTkComboBox(self.form_frame, values=ALLOWED_CATEGORIES, height=38, width=300, state="normal"),
            "selling_price": ctk.CTkEntry(self.form_frame, placeholder_text="Selling Price", height=38),
            "description": ctk.CTkEntry(self.form_frame, placeholder_text="Description (optional)", height=38),
        }

        self.availability_checkbox = ctk.CTkCheckBox(self.form_frame, text="Available", onvalue=True, offvalue=False)
        self.availability_checkbox.select()

        for idx, widget in enumerate(self.form_fields.values(), start=1):
            widget.grid(row=idx, column=0, padx=18, pady=8, sticky="ew")
        self.availability_checkbox.grid(row=5, column=0, padx=18, pady=(8, 12), sticky="w")

        button_row = ctk.CTkFrame(self.form_frame, fg_color="transparent")
        button_row.grid(row=6, column=0, padx=18, pady=(0, 18), sticky="w")
        ctk.CTkButton(button_row, text="Save", command=self.save_item, height=38, corner_radius=10, fg_color="#16a34a", hover_color="#15803d").grid(row=0, column=0, padx=(0, 10), sticky="w")
        ctk.CTkButton(button_row, text="Cancel", command=self.hide_form, height=38, corner_radius=10, fg_color="#f8fafc", hover_color="#eef2ff", text_color="#0f172a", border_width=1, border_color="#dfeaf8").grid(row=0, column=1, sticky="w")

        self.items_frame = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
        self.items_frame.grid(row=5, column=0, padx=28, pady=(0, 28), sticky="nsew")
        self.items_frame.grid_columnconfigure(0, weight=1)

        self.refresh_menu()

    def _set_notice(self, message, success=True):
        color = "#197C3B" if success else "#b42318"
        self.notice_label.configure(text=message, text_color=color)

    def _clear_form(self):
        for widget in self.form_fields.values():
            widget.delete(0, "end")
        self.availability_checkbox.select()
        self.current_edit_item_id = None
        self.form_title.configure(text="Add Menu Item")

    def hide_form(self):
        self.form_frame.grid_remove()
        self._clear_form()

    def show_add_form(self):
        self.form_frame.grid()
        self._clear_form()

    def show_edit_form(self, item):
        self.form_frame.grid()
        self.current_edit_item_id = item["item_id"]
        self.form_title.configure(text="Edit Menu Item")
        self.form_fields["item_name"].delete(0, "end")
        self.form_fields["item_name"].insert(0, item["item_name"])
        self.form_fields["category"].delete(0, "end")
        self.form_fields["category"].insert(0, item["category"])
        self.form_fields["selling_price"].delete(0, "end")
        self.form_fields["selling_price"].insert(0, str(item["selling_price"]))
        self.form_fields["description"].delete(0, "end")
        self.form_fields["description"].insert(0, item["description"])
        if item["is_available"]:
            self.availability_checkbox.select()
        else:
            self.availability_checkbox.deselect()

    def save_item(self):
        if session.current_cafe_id is None:
            self._set_notice("No active café is selected.", False)
            return

        item_name = self.form_fields["item_name"].get().strip()
        category = self.form_fields["category"].get().strip()
        price_value = self.form_fields["selling_price"].get().strip()
        description = self.form_fields["description"].get().strip()
        availability = bool(self.availability_checkbox.get())

        if not item_name:
            self._set_notice("Item name is required.", False)
            return
        if not category:
            self._set_notice("Category is required.", False)
            return
        try:
            price = float(price_value)
        except (TypeError, ValueError):
            self._set_notice("Please enter a valid selling price greater than zero.", False)
            return
        if price <= 0:
            self._set_notice("Selling price must be greater than zero.", False)
            return

        if self.current_edit_item_id:
            result = update_menu_item(
                cafe_id=session.current_cafe_id,
                item_id=self.current_edit_item_id,
                item_name=item_name,
                category=category,
                selling_price=price,
                description=description,
            )
            if not result["success"]:
                self._set_notice(result["message"], False)
                return
            self._set_notice(result["message"], True)
            self.hide_form()
        else:
            result = add_menu_item(
                cafe_id=session.current_cafe_id,
                item_name=item_name,
                category=category,
                selling_price=price,
                description=description,
                availability=availability,
            )
            if not result["success"]:
                self._set_notice(result["message"], False)
                return
            self._set_notice(result["message"], True)
            self.hide_form()

        self.refresh_menu()

    def toggle_item(self, item):
        result = toggle_item_availability(session.current_cafe_id, item["item_id"])
        if not result["success"]:
            self._set_notice(result["message"], False)
            return
        self._set_notice(result["message"], True)
        self.refresh_menu()

    def archive_item(self, item):
        from tkinter import messagebox

        if not messagebox.askyesno("Archive Menu Item", f"Archive {item['item_name']}? This will keep the record for historical safety but deactivate it from active selling."):
            return

        result = archive_menu_item(session.current_cafe_id, item["item_id"])
        if not result["success"]:
            self._set_notice(result["message"], False)
            return
        self._set_notice(result["message"], True)
        self.refresh_menu()

    def refresh_menu(self):
        for child in self.items_frame.winfo_children():
            child.destroy()

        if session.current_cafe_id is None:
            self._set_notice("No café is currently selected.", False)
            empty = ctk.CTkLabel(self.items_frame, text="Your menu is empty.\nAdd your first menu item to get started.", text_color="#475569", justify="left", font=("Segoe UI", 15), anchor="w", wraplength=800)
            empty.grid(row=0, column=0, padx=22, pady=28, sticky="w")
            self._update_summary_cards({"total_items": 0, "available_items": 0, "unavailable_items": 0, "category_count": 0})
            return

        rows = list_menu_items(
            cafe_id=session.current_cafe_id,
            search=self.search_var.get(),
            category=self.category_var.get(),
            availability=self.availability_var.get(),
        )

        if not rows:
            empty = ctk.CTkLabel(self.items_frame, text="Your menu is empty.\nAdd your first menu item to get started.", text_color="#475569", justify="left", font=("Segoe UI", 15), anchor="w", wraplength=800)
            empty.grid(row=0, column=0, padx=22, pady=28, sticky="w")
            add_button = ctk.CTkButton(self.items_frame, text="Add Menu Item", command=self.show_add_form, height=38, corner_radius=10, fg_color="#2563eb", hover_color="#1d4f91")
            add_button.grid(row=1, column=0, padx=22, pady=(0, 22), sticky="w")
            self._update_summary_cards({"total_items": 0, "available_items": 0, "unavailable_items": 0, "category_count": 0})
            return

        summary = get_menu_summary(session.current_cafe_id)
        self._update_summary_cards(summary)

        for index, item in enumerate(rows, start=0):
            card = ctk.CTkFrame(self.items_frame, corner_radius=16, fg_color="#f8fafc", border_width=1, border_color="#e2e8f0")
            card.grid(row=index, column=0, padx=18, pady=10, sticky="ew")
            card.grid_columnconfigure(0, weight=2)
            card.grid_columnconfigure(1, weight=1)
            card.grid_columnconfigure(2, weight=0)
            card.grid_columnconfigure(3, weight=0)

            ctk.CTkLabel(card, text=item["item_name"], text_color="#111827", font=("Segoe UI", 16, "bold"), anchor="w").grid(row=0, column=0, padx=16, pady=(14, 4), sticky="w")
            ctk.CTkLabel(card, text=item["category"], text_color="#475569", font=("Segoe UI", 11), anchor="w").grid(row=1, column=0, padx=16, pady=(0, 8), sticky="w")
            ctk.CTkLabel(card, text=f"₹ {item['selling_price']:.2f}", text_color="#0f172a", font=("Segoe UI", 13, "bold"), anchor="e").grid(row=0, column=1, padx=(0, 16), pady=(14, 4), sticky="e")

            availability = "Available" if item["is_available"] else "Unavailable"
            badge_color = "#dcfce7" if item["is_available"] else "#fee2e2"
            badge_text = "#166534" if item["is_available"] else "#991b1b"
            badge = ctk.CTkLabel(card, text=availability, text_color=badge_text, fg_color=badge_color, corner_radius=8, padx=8, pady=4, font=("Segoe UI", 10, "bold"))
            badge.grid(row=0, column=2, padx=(0, 10), pady=(12, 4), sticky="e")

            actions = ctk.CTkFrame(card, fg_color="transparent")
            actions.grid(row=1, column=1, columnspan=2, padx=(0, 12), pady=(0, 12), sticky="e")
            actions.grid_columnconfigure((0, 1, 2), weight=0)
            ctk.CTkButton(actions, text="Edit", command=lambda item=item: self.show_edit_form(item), height=30, corner_radius=8, fg_color="#e0ecff", hover_color="#d0e3ff", text_color="#0f172a").grid(row=0, column=0, padx=(0, 8), sticky="w")
            ctk.CTkButton(actions, text="Toggle", command=lambda item=item: self.toggle_item(item), height=30, corner_radius=8, fg_color="#fef3c7", hover_color="#fde68a", text_color="#0f172a").grid(row=0, column=1, padx=(0, 8), sticky="w")
            ctk.CTkButton(actions, text="Archive", command=lambda item=item: self.archive_item(item), height=30, corner_radius=8, fg_color="#fee2e2", hover_color="#fecaca", text_color="#7f1d1d").grid(row=0, column=2, sticky="w")

            if item.get("description"):
                ctk.CTkLabel(card, text=item["description"], text_color="#475569", font=("Segoe UI", 11), anchor="w", justify="left", wraplength=560).grid(row=2, column=0, columnspan=3, padx=16, pady=(0, 14), sticky="w")

    def _update_summary_cards(self, summary):
        mapping = {
            "total_items": summary.get("total_items", 0),
            "available_items": summary.get("available_items", 0),
            "unavailable_items": summary.get("unavailable_items", 0),
            "category_count": summary.get("category_count", 0),
        }
        for key, label in self.summary_cards:
            label.configure(text=str(mapping.get(key, 0)))


class InventoryManagementPage(ctk.CTkScrollableFrame):
    """Inventory management workspace for café owners."""

    def __init__(self, master, app):
        super().__init__(master, corner_radius=0, fg_color="#f4f7fb")
        self.app = app
        self.grid_columnconfigure(0, weight=1)
        self.current_edit_ingredient_id = None

        header = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        header.grid(row=0, column=0, padx=28, pady=(22, 18), sticky="ew")
        header.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(header, text="Inventory Management", font=("Segoe UI", 27, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 4), sticky="w")
        ctk.CTkLabel(header, text="Track ingredients, stock health, and stock movements for your café.", font=("Segoe UI", 12), text_color="#475569", anchor="w").grid(row=1, column=0, padx=18, pady=(0, 18), sticky="w")

        cards_frame = ctk.CTkFrame(self, corner_radius=18, fg_color="transparent")
        cards_frame.grid(row=1, column=0, padx=28, pady=(0, 12), sticky="ew")
        cards_frame.grid_columnconfigure((0, 1, 2, 3), weight=1)

        self.summary_cards = []
        summary_labels = [
            ("Total Ingredients", "total_ingredients"),
            ("Low Stock", "low_stock_ingredients"),
            ("Out of Stock", "out_of_stock_ingredients"),
            ("Inventory Value", "inventory_value"),
        ]
        for idx, (title, key) in enumerate(summary_labels):
            card = ctk.CTkFrame(cards_frame, corner_radius=16, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
            card.grid(row=0, column=idx, padx=10, sticky="ew")
            card.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(card, text=title, text_color="#5a6475", font=("Segoe UI", 12), anchor="w").grid(row=0, column=0, padx=16, pady=(18, 0), sticky="w")
            value_label = ctk.CTkLabel(card, text="0", text_color="#0f172a", font=("Segoe UI", 22, "bold"), anchor="w")
            value_label.grid(row=1, column=0, padx=16, pady=(10, 18), sticky="w")
            self.summary_cards.append((key, value_label))

        self.notice_label = ctk.CTkLabel(self, text="", text_color="#197C3B", font=("Segoe UI", 12, "bold"), anchor="w")
        self.notice_label.grid(row=2, column=0, padx=28, pady=(0, 8), sticky="w")

        toolbar = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
        toolbar.grid(row=3, column=0, padx=28, pady=(0, 16), sticky="ew")
        toolbar.grid_columnconfigure(0, weight=2)
        toolbar.grid_columnconfigure(1, weight=1)
        toolbar.grid_columnconfigure(2, weight=0)
        toolbar.grid_columnconfigure(3, weight=0)
        toolbar.grid_columnconfigure(4, weight=0)

        self.search_var = ctk.StringVar(value="")
        self.status_var = ctk.StringVar(value="All")

        search_entry = ctk.CTkEntry(toolbar, textvariable=self.search_var, placeholder_text="Search ingredient name", height=38)
        search_entry.grid(row=0, column=0, padx=16, pady=16, sticky="ew")
        search_entry.bind("<KeyRelease>", lambda event: self.refresh_inventory())

        status_menu = ctk.CTkOptionMenu(toolbar, values=["All", "In stock", "Low stock", "Out of stock"], variable=self.status_var, command=lambda _value: self.refresh_inventory())
        status_menu.grid(row=0, column=1, padx=(0, 10), pady=16, sticky="ew")

        add_button = ctk.CTkButton(toolbar, text="Add Ingredient", command=self.show_add_ingredient_form, height=38, corner_radius=10, fg_color="#2563eb", hover_color="#1d4f91")
        add_button.grid(row=0, column=2, padx=(0, 8), pady=16, sticky="e")

        movement_button = ctk.CTkButton(toolbar, text="Record Stock Movement", command=self.show_movement_form, height=38, corner_radius=10, fg_color="#10B981", hover_color="#059669")
        movement_button.grid(row=0, column=3, padx=(0, 8), pady=16, sticky="e")

        history_button = ctk.CTkButton(toolbar, text="Stock History", command=self.show_history_panel, height=38, corner_radius=10, fg_color="#f8fafc", hover_color="#eef2ff", text_color="#0f172a", border_width=1, border_color="#dfeaf8")
        history_button.grid(row=0, column=4, padx=(0, 16), pady=16, sticky="e")

        self.ingredient_form = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        self.ingredient_form.grid(row=4, column=0, padx=28, pady=(0, 16), sticky="ew")
        self.ingredient_form.grid_columnconfigure(0, weight=1)
        self.ingredient_form.grid_remove()

        self.ingredient_form_title = ctk.CTkLabel(self.ingredient_form, text="Add Ingredient", font=("Segoe UI", 18, "bold"), text_color="#111827", anchor="w")
        self.ingredient_form_title.grid(row=0, column=0, padx=18, pady=(18, 8), sticky="w")

        self.ingredient_fields = {}
        field_specs = [
            ("name", "Ingredient Name", ctk.CTkEntry(self.ingredient_form, height=38)),
            ("unit", "Unit", ctk.CTkOptionMenu(self.ingredient_form, values=["g", "kg", "ml", "litre", "pcs"], dynamic_resizing=False)),
            ("opening_stock", "Opening Stock (quantity available when first entered)", ctk.CTkEntry(self.ingredient_form, height=38)),
            ("minimum_stock", "Minimum Stock Threshold", ctk.CTkEntry(self.ingredient_form, height=38)),
            ("unit_cost", "Cost per Unit (optional)", ctk.CTkEntry(self.ingredient_form, height=38)),
        ]
        for idx, (key, label, widget) in enumerate(field_specs):
            self.ingredient_fields[key] = widget
            label_row = idx * 2 + 1
            ctk.CTkLabel(self.ingredient_form, text=label, text_color="#334155", anchor="w").grid(row=label_row, column=0, padx=18, pady=(8, 0), sticky="w")
            widget.grid(row=label_row + 1, column=0, padx=18, pady=(2, 8), sticky="ew")

        self.ingredient_action_row = ctk.CTkFrame(self.ingredient_form, fg_color="transparent")
        self.ingredient_action_row.grid(row=11, column=0, padx=18, pady=(0, 18), sticky="w")
        ctk.CTkButton(self.ingredient_action_row, text="Save", command=self.save_ingredient, height=38, corner_radius=10, fg_color="#16a34a", hover_color="#15803d").grid(row=0, column=0, padx=(0, 10), sticky="w")
        ctk.CTkButton(self.ingredient_action_row, text="Cancel", command=self.hide_ingredient_form, height=38, corner_radius=10, fg_color="#f8fafc", hover_color="#eef2ff", text_color="#0f172a", border_width=1, border_color="#dfeaf8").grid(row=0, column=1, sticky="w")

        self.movement_form = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        self.movement_form.grid(row=5, column=0, padx=28, pady=(0, 16), sticky="ew")
        self.movement_form.grid_columnconfigure(0, weight=1)
        self.movement_form.grid_remove()

        self.movement_form_title = ctk.CTkLabel(self.movement_form, text="Record Stock Movement", font=("Segoe UI", 18, "bold"), text_color="#111827", anchor="w")
        self.movement_form_title.grid(row=0, column=0, padx=18, pady=(18, 8), sticky="w")

        self.movement_fields = {
            "ingredient": ctk.CTkOptionMenu(self.movement_form, values=[], dynamic_resizing=False),
            "movement_type": ctk.CTkOptionMenu(self.movement_form, values=["opening_stock", "purchase_receipt", "manual_stock_increase", "manual_stock_decrease", "waste_adjustment"], dynamic_resizing=False),
            "quantity": ctk.CTkEntry(self.movement_form, placeholder_text="Quantity", height=38),
            "unit": ctk.CTkOptionMenu(self.movement_form, values=["g", "kg", "ml", "litre", "pcs"], dynamic_resizing=False),
            "reference": ctk.CTkEntry(self.movement_form, placeholder_text="Reference (optional)", height=38),
            "reason": ctk.CTkEntry(self.movement_form, placeholder_text="Reason", height=38),
        }
        for idx, widget in enumerate(self.movement_fields.values(), start=1):
            widget.grid(row=idx, column=0, padx=18, pady=8, sticky="ew")

        self.movement_action_row = ctk.CTkFrame(self.movement_form, fg_color="transparent")
        self.movement_action_row.grid(row=7, column=0, padx=18, pady=(0, 18), sticky="w")
        ctk.CTkButton(self.movement_action_row, text="Save Movement", command=self.save_stock_movement, height=38, corner_radius=10, fg_color="#10B981", hover_color="#059669").grid(row=0, column=0, padx=(0, 10), sticky="w")
        ctk.CTkButton(self.movement_action_row, text="Cancel", command=self.hide_movement_form, height=38, corner_radius=10, fg_color="#f8fafc", hover_color="#eef2ff", text_color="#0f172a", border_width=1, border_color="#dfeaf8").grid(row=0, column=1, sticky="w")

        self.table_frame = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
        self.table_frame.grid(row=6, column=0, padx=28, pady=(0, 28), sticky="nsew")
        self.table_frame.grid_columnconfigure(0, weight=1)

        self.refresh_inventory()

    def _set_notice(self, message, ok=True):
        self.notice_label.configure(text=message, text_color="#197C3B" if ok else "#b42318")

    def hide_ingredient_form(self):
        self.ingredient_form.grid_remove()
        self.current_edit_ingredient_id = None
        self.ingredient_form_title.configure(text="Add Ingredient")
        for widget in self.ingredient_fields.values():
            if hasattr(widget, "delete"):
                widget.delete(0, "end")

    def hide_movement_form(self):
        self.movement_form.grid_remove()
        for widget in self.movement_fields.values():
            if hasattr(widget, "delete"):
                widget.delete(0, "end")

    def show_add_ingredient_form(self):
        self.hide_movement_form()
        self.ingredient_form.grid()
        self.current_edit_ingredient_id = None
        self.ingredient_form_title.configure(text="Add Ingredient")
        for widget in self.ingredient_fields.values():
            if hasattr(widget, "delete"):
                widget.delete(0, "end")

    def save_ingredient(self):
        if session.current_cafe_id is None:
            self._set_notice("No active café is selected.", False)
            return

        payload = {
            "name": self.ingredient_fields["name"].get().strip(),
            "unit": self.ingredient_fields["unit"].get(),
            "opening_stock": self.ingredient_fields["opening_stock"].get().strip(),
            "minimum_stock": self.ingredient_fields["minimum_stock"].get().strip(),
            "unit_cost": self.ingredient_fields["unit_cost"].get().strip(),
        }
        if not payload["name"]:
            self._set_notice("Ingredient name is required.", False)
            return
        try:
            if self.current_edit_ingredient_id:
                result = update_ingredient(
                cafe_id=session.current_cafe_id,
                ingredient_id=self.current_edit_ingredient_id,
                name=payload["name"],
                unit=payload["unit"],
                minimum_stock=payload["minimum_stock"],
                unit_cost=payload["unit_cost"],
                )
            else:
                result = add_ingredient(
                cafe_id=session.current_cafe_id,
                name=payload["name"],
                unit=payload["unit"],
                minimum_stock=payload["minimum_stock"],
                unit_cost=payload["unit_cost"],
                    opening_stock=payload["opening_stock"],
                )
        except Exception:
            self._set_notice("The ingredient could not be saved. Please try again.", False)
            return
        if not result["success"]:
            self._set_notice(result["message"], False)
            return
        self._set_notice(result["message"], True)
        self.hide_ingredient_form()
        self.refresh_inventory()

    def show_movement_form(self):
        self.hide_ingredient_form()
        self.movement_form.grid()
        ingredients = list_ingredients(session.current_cafe_id) if session.current_cafe_id else []
        if not ingredients:
            self._set_notice("Add at least one ingredient before recording a movement.", False)
            self.movement_form.grid_remove()
            return
        values = [item["name"] for item in ingredients]
        self.movement_fields["ingredient"].configure(values=values)
        self.movement_fields["ingredient"].set(values[0])

    def save_stock_movement(self):
        if session.current_cafe_id is None:
            self._set_notice("No active café is selected.", False)
            return

        ingredient_name = self.movement_fields["ingredient"].get().strip()
        ingredients = list_ingredients(session.current_cafe_id) if session.current_cafe_id else []
        ingredient = next((item for item in ingredients if item["name"] == ingredient_name), None)
        if ingredient is None:
            self._set_notice("Select a valid ingredient.", False)
            return

        quantity = self.movement_fields["quantity"].get().strip()
        if not quantity:
            self._set_notice("Quantity is required.", False)
            return
        reason = self.movement_fields["reason"].get().strip()
        result = record_stock_movement(
            cafe_id=session.current_cafe_id,
            ingredient_id=ingredient["ingredient_id"],
            movement_type=self.movement_fields["movement_type"].get(),
            quantity=quantity,
            unit=self.movement_fields["unit"].get(),
            reference=self.movement_fields["reference"].get().strip(),
            reason=reason,
            actor_id=session.current_user_id or "system",
        )
        if not result["success"]:
            self._set_notice(result["message"], False)
            return
        self._set_notice(result["message"], True)
        self.hide_movement_form()
        self.refresh_inventory()

    def show_history_panel(self):
        self.hide_ingredient_form()
        self.hide_movement_form()
        rows = list_stock_movements(session.current_cafe_id) if session.current_cafe_id else []
        for child in self.table_frame.winfo_children():
            child.destroy()
        if not rows:
            ctk.CTkLabel(self.table_frame, text="No stock movement history yet.", text_color="#475569", font=("Segoe UI", 13), anchor="w").grid(row=0, column=0, padx=18, pady=20, sticky="w")
            return
        for idx, movement in enumerate(rows[:20], start=0):
            card = ctk.CTkFrame(self.table_frame, corner_radius=12, fg_color="#f8fafc", border_width=1, border_color="#e2e8f0")
            card.grid(row=idx, column=0, padx=18, pady=8, sticky="ew")
            card.grid_columnconfigure(0, weight=2)
            card.grid_columnconfigure(1, weight=1)
            ctk.CTkLabel(card, text=f"{movement['movement_type']} • {movement['quantity']} {movement['unit']}", text_color="#111827", font=("Segoe UI", 13, "bold"), anchor="w").grid(row=0, column=0, padx=12, pady=10, sticky="w")
            ctk.CTkLabel(card, text=f"{movement['created_at']} • {movement['reason'] or movement['reference'] or 'No note'}", text_color="#475569", font=("Segoe UI", 11), anchor="w", justify="left", wraplength=700).grid(row=1, column=0, columnspan=2, padx=12, pady=(0, 10), sticky="w")

    def _update_summary_cards(self, summary):
        mapping = {
            "total_ingredients": summary.get("total_ingredients", 0),
            "low_stock_ingredients": summary.get("low_stock_ingredients", 0),
            "out_of_stock_ingredients": summary.get("out_of_stock_ingredients", 0),
            "inventory_value": summary.get("inventory_value_label", "Not available"),
        }
        for key, label in self.summary_cards:
            label.configure(text=str(mapping.get(key, 0)))

    def refresh_inventory(self):
        for child in self.table_frame.winfo_children():
            child.destroy()

        if session.current_cafe_id is None:
            self._set_notice("No café is selected.", False)
            label = ctk.CTkLabel(self.table_frame, text="No café is currently selected. Select a café to view inventory.", text_color="#475569", font=("Segoe UI", 15), anchor="w")
            label.grid(row=0, column=0, padx=18, pady=24, sticky="w")
            return

        rows = list_ingredients(
            cafe_id=session.current_cafe_id,
            search=self.search_var.get(),
            status=self.status_var.get(),
        )

        summary = get_inventory_dashboard(session.current_cafe_id)
        self._update_summary_cards(summary)

        if not rows:
            ctk.CTkLabel(self.table_frame, text="No ingredients match the active filter.", text_color="#475569", font=("Segoe UI", 13), anchor="w").grid(row=0, column=0, padx=18, pady=20, sticky="w")
            return

        header = ctk.CTkFrame(self.table_frame, fg_color="#f8fafc")
        header.grid(row=0, column=0, padx=18, pady=(14, 8), sticky="ew")
        header.grid_columnconfigure((0, 1, 2, 3, 4, 5), weight=1)
        for idx, title in enumerate(["Ingredient", "Unit", "Stock", "Minimum", "Status", "Actions"]):
            ctk.CTkLabel(header, text=title, text_color="#475569", font=("Segoe UI", 11, "bold"), anchor="w").grid(row=0, column=idx, padx=12, pady=10, sticky="w")

        for idx, ingredient in enumerate(rows, start=1):
            row = ctk.CTkFrame(self.table_frame, fg_color="transparent", border_width=1, border_color="#e2e8f0")
            row.grid(row=idx, column=0, padx=18, pady=8, sticky="ew")
            row.grid_columnconfigure((0, 1, 2, 3, 4, 5), weight=1)

            ctk.CTkLabel(row, text=ingredient["name"], text_color="#111827", font=("Segoe UI", 12, "bold"), anchor="w").grid(row=0, column=0, padx=12, pady=10, sticky="w")
            ctk.CTkLabel(row, text=ingredient["unit"], text_color="#475569", anchor="w").grid(row=0, column=1, padx=12, pady=10, sticky="w")
            ctk.CTkLabel(row, text=f"{ingredient['current_stock']:.2f}", text_color="#0f172a", anchor="w").grid(row=0, column=2, padx=12, pady=10, sticky="w")
            ctk.CTkLabel(row, text=f"{ingredient['minimum_stock']:.2f}", text_color="#475569", anchor="w").grid(row=0, column=3, padx=12, pady=10, sticky="w")
            status = ingredient["stock_status"]
            badge_color = {"In stock": "#dcfce7", "Low stock": "#fef3c7", "Out of stock": "#fee2e2"}.get(status, "#f1f5f9")
            badge_text = {"In stock": "#166534", "Low stock": "#92400e", "Out of stock": "#991b1b"}.get(status, "#0f172a")
            ctk.CTkLabel(row, text=status, text_color=badge_text, fg_color=badge_color, corner_radius=8, padx=8, pady=4, font=("Segoe UI", 10, "bold")).grid(row=0, column=4, padx=12, pady=10, sticky="w")

            action_row = ctk.CTkFrame(row, fg_color="transparent")
            action_row.grid(row=0, column=5, padx=(0, 12), pady=8, sticky="e")
            ctk.CTkButton(action_row, text="Edit", command=lambda item=ingredient: self.edit_ingredient(item), height=28, corner_radius=8, fg_color="#e0ecff", hover_color="#d4e6ff", text_color="#0f172a").grid(row=0, column=0, padx=(0, 6), sticky="w")
            ctk.CTkButton(action_row, text="History", command=lambda item=ingredient: self.show_ingredient_history(item), height=28, corner_radius=8, fg_color="#f1f5f9", hover_color="#e2e8f0", text_color="#0f172a").grid(row=0, column=1, sticky="w")

    def edit_ingredient(self, ingredient):
        self.hide_movement_form()
        self.ingredient_form.grid()
        self.current_edit_ingredient_id = ingredient["ingredient_id"]
        self.ingredient_form_title.configure(text="Edit Ingredient")
        self.ingredient_fields["name"].delete(0, "end")
        self.ingredient_fields["name"].insert(0, ingredient["name"])
        self.ingredient_fields["unit"].set(ingredient["unit"])
        self.ingredient_fields["minimum_stock"].delete(0, "end")
        self.ingredient_fields["minimum_stock"].insert(0, str(ingredient["minimum_stock"]))
        if ingredient.get("unit_cost") is not None:
            self.ingredient_fields["unit_cost"].delete(0, "end")
            self.ingredient_fields["unit_cost"].insert(0, str(ingredient["unit_cost"]))

    def show_ingredient_history(self, ingredient):
        self.hide_ingredient_form()
        self.hide_movement_form()
        rows = list_stock_movements(session.current_cafe_id, ingredient_id=ingredient["ingredient_id"]) if session.current_cafe_id else []
        for child in self.table_frame.winfo_children():
            child.destroy()
        if not rows:
            ctk.CTkLabel(self.table_frame, text=f"No stock history for {ingredient['name']} yet.", text_color="#475569", font=("Segoe UI", 13), anchor="w").grid(row=0, column=0, padx=18, pady=20, sticky="w")
            return
        for idx, movement in enumerate(rows[:20], start=0):
            card = ctk.CTkFrame(self.table_frame, corner_radius=12, fg_color="#f8fafc", border_width=1, border_color="#e2e8f0")
            card.grid(row=idx, column=0, padx=18, pady=8, sticky="ew")
            ctk.CTkLabel(card, text=f"{movement['movement_type']} • {movement['quantity']} {movement['unit']}", text_color="#111827", font=("Segoe UI", 13, "bold"), anchor="w").grid(row=0, column=0, padx=12, pady=10, sticky="w")
            ctk.CTkLabel(card, text=f"{movement['created_at']} • {movement['reason'] or movement['reference'] or 'No note'}", text_color="#475569", font=("Segoe UI", 11), anchor="w", justify="left", wraplength=700).grid(row=1, column=0, padx=12, pady=(0, 10), sticky="w")


class OrdersManagementPage(ctk.CTkScrollableFrame):
    """Orders management workspace for café owners."""

    def __init__(self, master, app):
        super().__init__(master, corner_radius=0, fg_color="#f4f7fb")
        self.app = app
        self.grid_columnconfigure(0, weight=1)
        self.current_order_detail = None

        header = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        header.grid(row=0, column=0, padx=28, pady=(22, 18), sticky="ew")
        header.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(header, text="Orders", font=("Segoe UI", 27, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 4), sticky="w")
        ctk.CTkLabel(header, text="Create and manage your café's sales orders.", font=("Segoe UI", 12), text_color="#475569", anchor="w").grid(row=1, column=0, padx=18, pady=(0, 18), sticky="w")

        self.summary_cards = []
        cards_frame = ctk.CTkFrame(self, corner_radius=18, fg_color="transparent")
        cards_frame.grid(row=1, column=0, padx=28, pady=(0, 12), sticky="ew")
        cards_frame.grid_columnconfigure((0, 1, 2, 3), weight=1)
        for idx, title in enumerate(["Total Orders", "Today's Orders", "Today's Sales", "Average Order Value"]):
            card = ctk.CTkFrame(cards_frame, corner_radius=16, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
            card.grid(row=0, column=idx, padx=10, sticky="ew")
            card.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(card, text=title, text_color="#5a6475", font=("Segoe UI", 12), anchor="w").grid(row=0, column=0, padx=16, pady=(18, 0), sticky="w")
            value_label = ctk.CTkLabel(card, text="0", text_color="#0f172a", font=("Segoe UI", 22, "bold"), anchor="w")
            value_label.grid(row=1, column=0, padx=16, pady=(10, 18), sticky="w")
            self.summary_cards.append(value_label)

        toolbar = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
        toolbar.grid(row=2, column=0, padx=28, pady=(0, 16), sticky="ew")
        toolbar.grid_columnconfigure(0, weight=2)
        toolbar.grid_columnconfigure(1, weight=1)
        toolbar.grid_columnconfigure(2, weight=1)
        toolbar.grid_columnconfigure(3, weight=0)

        self.search_var = ctk.StringVar(value="")
        self.status_var = ctk.StringVar(value="All")
        self.date_var = ctk.StringVar(value="All")

        search_entry = ctk.CTkEntry(toolbar, textvariable=self.search_var, placeholder_text="Search order ID", height=38)
        search_entry.grid(row=0, column=0, padx=16, pady=16, sticky="ew")
        search_entry.bind("<KeyRelease>", lambda event: self.refresh_orders())

        status_menu = ctk.CTkOptionMenu(toolbar, values=["All", "Completed", "Cancelled"], variable=self.status_var, command=lambda _value: self.refresh_orders())
        status_menu.grid(row=0, column=1, padx=(0, 10), pady=16, sticky="ew")

        date_menu = ctk.CTkOptionMenu(toolbar, values=["All", "Today", "7 Days"], variable=self.date_var, command=lambda _value: self.refresh_orders())
        date_menu.grid(row=0, column=2, padx=(0, 10), pady=16, sticky="ew")

        create_button = ctk.CTkButton(toolbar, text="Create New Order", command=self.show_order_builder, height=38, corner_radius=10, fg_color="#2563eb", hover_color="#1d4f91")
        create_button.grid(row=0, column=3, padx=(0, 16), pady=16, sticky="e")

        self.notice_label = ctk.CTkLabel(self, text="", text_color="#197C3B", font=("Segoe UI", 12, "bold"), anchor="w")
        self.notice_label.grid(row=3, column=0, padx=28, pady=(0, 6), sticky="w")

        self.builder = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        self.builder.grid(row=4, column=0, padx=28, pady=(0, 16), sticky="ew")
        self.builder.grid_columnconfigure(0, weight=1)
        self.builder.grid_remove()

        self.builder_title = ctk.CTkLabel(self.builder, text="New Order", font=("Segoe UI", 18, "bold"), text_color="#111827", anchor="w")
        self.builder_title.grid(row=0, column=0, padx=18, pady=(18, 8), sticky="w")

        self.builder_content = ctk.CTkFrame(self.builder, fg_color="transparent")
        self.builder_content.grid(row=1, column=0, padx=18, pady=(0, 18), sticky="nsew")
        self.builder_content.grid_columnconfigure(0, weight=1)

        self.draft_items = {}
        self.order_form = None

        self.history_frame = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
        self.history_frame.grid(row=5, column=0, padx=28, pady=(0, 28), sticky="nsew")
        self.history_frame.grid_columnconfigure(0, weight=1)
        self.history_frame.grid_rowconfigure(0, weight=0)

        self.refresh_summary()
        self.refresh_orders()

    def _set_notice(self, message, ok=True):
        color = "#197C3B" if ok else "#b42318"
        self.notice_label.configure(text=message, text_color=color)

    def refresh_summary(self):
        if session.current_cafe_id is None:
            for label in self.summary_cards:
                label.configure(text="0")
            return

        summary = get_order_summary(session.current_cafe_id)
        values = [
            str(int(summary.get("total_orders", 0))),
            str(int(summary.get("today_orders", 0))),
            f"₹ {summary.get('today_sales', 0):.2f}",
            f"₹ {summary.get('average_order_value', 0):.2f}",
        ]
        for label, value in zip(self.summary_cards, values):
            label.configure(text=value)

    def _clear_builder(self):
        for child in self.builder_content.winfo_children():
            child.destroy()
        self.draft_items = {}

    def show_order_builder(self):
        self.builder.grid()
        self._clear_builder()

        if session.current_cafe_id is None:
            empty = ctk.CTkLabel(self.builder_content, text="No active café is selected.", text_color="#475569", font=("Segoe UI", 13), anchor="w")
            empty.grid(row=0, column=0, padx=12, pady=12, sticky="w")
            return

        menu_items = list_menu_items(session.current_cafe_id)
        available_items = [item for item in menu_items if item.get("is_available")]

        if not available_items:
            empty = ctk.CTkLabel(self.builder_content, text="No available menu items for this café. Open Menu Management to add products before creating an order.", text_color="#475569", font=("Segoe UI", 13), anchor="w", justify="left", wraplength=800)
            empty.grid(row=0, column=0, padx=12, pady=12, sticky="w")
            action = ctk.CTkButton(self.builder_content, text="Open Menu Management", command=lambda: self.app.show_page("Menu"), height=38, corner_radius=10, fg_color="#2563eb", hover_color="#1d4f91")
            action.grid(row=1, column=0, padx=12, pady=(0, 12), sticky="w")
            return

        search_box = ctk.CTkEntry(self.builder_content, placeholder_text="Search menu items", height=36)
        search_box.grid(row=0, column=0, padx=12, pady=(8, 12), sticky="ew")
        search_box.bind("<KeyRelease>", lambda event: self._render_menu_candidates(search_box.get()))

        self.menu_candidate_panel = ctk.CTkScrollableFrame(self.builder_content, fg_color="transparent", width=700, height=200)
        self.menu_candidate_panel.grid(row=1, column=0, padx=12, pady=(0, 12), sticky="nsew")
        self.menu_candidate_panel.grid_columnconfigure(0, weight=1)
        self._render_menu_candidates("")

        draft_wrapper = ctk.CTkFrame(self.builder_content, fg_color="#f8fafc", border_width=1, border_color="#dfeaf8")
        draft_wrapper.grid(row=2, column=0, padx=12, pady=(0, 12), sticky="ew")
        draft_wrapper.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(draft_wrapper, text="Order Draft", font=("Segoe UI", 15, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=12, pady=(12, 8), sticky="w")

        self.draft_panel = ctk.CTkFrame(draft_wrapper, fg_color="transparent")
        self.draft_panel.grid(row=1, column=0, padx=12, pady=(0, 12), sticky="nsew")
        self.draft_panel.grid_columnconfigure(0, weight=1)
        self._render_draft()

        actions = ctk.CTkFrame(self.builder_content, fg_color="transparent")
        actions.grid(row=3, column=0, padx=12, pady=(0, 12), sticky="w")
        ctk.CTkButton(actions, text="Save Order", command=self.save_order, height=38, corner_radius=10, fg_color="#10B981", hover_color="#059669").grid(row=0, column=0, padx=(0, 10), sticky="w")
        ctk.CTkButton(actions, text="Cancel", command=self.hide_builder, height=38, corner_radius=10, fg_color="#f8fafc", hover_color="#eef2ff", text_color="#0f172a", border_width=1, border_color="#dfeaf8").grid(row=0, column=1, sticky="w")

    def _render_menu_candidates(self, search_term=""):
        if not hasattr(self, "menu_candidate_panel"):
            return
        for child in self.menu_candidate_panel.winfo_children():
            child.destroy()

        items = [item for item in list_menu_items(session.current_cafe_id) if item.get("is_available")]
        if search_term:
            term = search_term.lower()
            items = [item for item in items if term in item.get("item_name", "").lower() or term in item.get("category", "").lower()]

        if not items:
            empty = ctk.CTkLabel(self.menu_candidate_panel, text="No matching items available.", text_color="#475569", anchor="w")
            empty.grid(row=0, column=0, padx=12, pady=12, sticky="w")
            return

        for idx, item in enumerate(items):
            row = ctk.CTkFrame(self.menu_candidate_panel, fg_color="#f8fafc", border_width=1, border_color="#e2e8f0")
            row.grid(row=idx, column=0, padx=8, pady=6, sticky="ew")
            row.grid_columnconfigure(0, weight=2)
            row.grid_columnconfigure(1, weight=1)
            row.grid_columnconfigure(2, weight=0)
            ctk.CTkLabel(row, text=item["item_name"], text_color="#111827", font=("Segoe UI", 13, "bold"), anchor="w").grid(row=0, column=0, padx=12, pady=10, sticky="w")
            ctk.CTkLabel(row, text=f"₹ {float(item['selling_price']):.2f}", text_color="#0f172a", font=("Segoe UI", 12), anchor="e").grid(row=0, column=1, padx=(0, 12), pady=10, sticky="e")
            ctk.CTkButton(row, text="Add", command=lambda item=item: self.add_draft_item(item), height=28, corner_radius=8, fg_color="#2563eb", hover_color="#1d4f91").grid(row=0, column=2, padx=(0, 10), pady=10, sticky="e")

    def add_draft_item(self, item):
        item_id = str(item["item_id"])
        self.draft_items[item_id] = self.draft_items.get(item_id, 0) + 1
        if not hasattr(self, "draft_panel"):
            return
        self._render_draft()

    def update_quantity(self, item_id, delta):
        current = self.draft_items.get(item_id, 0) + delta
        if current <= 0:
            self.draft_items.pop(item_id, None)
        else:
            self.draft_items[item_id] = current
        self._render_draft()

    def _render_draft(self):
        if not hasattr(self, "draft_panel"):
            return
        for child in self.draft_panel.winfo_children():
            child.destroy()

        if not self.draft_items:
            empty = ctk.CTkLabel(self.draft_panel, text="No items selected yet.", text_color="#475569", font=("Segoe UI", 12), anchor="w")
            empty.grid(row=0, column=0, padx=12, pady=12, sticky="w")
            return

        menu_items = {str(item["item_id"]): item for item in list_menu_items(session.current_cafe_id)}
        subtotal = 0.0
        for idx, (item_id, quantity) in enumerate(self.draft_items.items()):
            item = menu_items.get(item_id)
            if not item:
                continue
            line_total = float(item["selling_price"]) * quantity
            subtotal += line_total
            row = ctk.CTkFrame(self.draft_panel, fg_color="transparent")
            row.grid(row=idx, column=0, padx=8, pady=6, sticky="ew")
            row.grid_columnconfigure(0, weight=2)
            row.grid_columnconfigure(1, weight=1)
            row.grid_columnconfigure(2, weight=0)
            row.grid_columnconfigure(3, weight=0)
            ctk.CTkLabel(row, text=item["item_name"], text_color="#111827", font=("Segoe UI", 12, "bold"), anchor="w").grid(row=0, column=0, padx=8, pady=6, sticky="w")
            ctk.CTkLabel(row, text=f"₹ {float(item['selling_price']):.2f}", text_color="#475569", anchor="w").grid(row=0, column=1, padx=(0, 8), pady=6, sticky="w")
            ctk.CTkButton(row, text="-", command=lambda item_id=item_id: self.update_quantity(item_id, -1), width=32, height=24, corner_radius=8, fg_color="#e2e8f0", hover_color="#dfeaf8", text_color="#0f172a").grid(row=0, column=2, padx=(0, 6), pady=6, sticky="w")
            ctk.CTkLabel(row, text=str(quantity), text_color="#111827", font=("Segoe UI", 12, "bold")).grid(row=0, column=3, padx=(0, 6), pady=6, sticky="w")
            ctk.CTkButton(row, text="+", command=lambda item_id=item_id: self.update_quantity(item_id, 1), width=32, height=24, corner_radius=8, fg_color="#e2e8f0", hover_color="#dfeaf8", text_color="#0f172a").grid(row=0, column=4, padx=(0, 6), pady=6, sticky="w")
            ctk.CTkLabel(row, text=f"₹ {line_total:.2f}", text_color="#0f172a", font=("Segoe UI", 12, "bold"), anchor="e").grid(row=0, column=5, padx=(0, 8), pady=6, sticky="e")

        total_row = ctk.CTkFrame(self.draft_panel, fg_color="transparent")
        total_row.grid(row=len(self.draft_items), column=0, padx=8, pady=(8, 8), sticky="ew")
        total_row.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(total_row, text="Subtotal", text_color="#475569", font=("Segoe UI", 13, "bold"), anchor="w").grid(row=0, column=0, padx=8, pady=8, sticky="w")
        ctk.CTkLabel(total_row, text=f"₹ {subtotal:.2f}", text_color="#111827", font=("Segoe UI", 14, "bold"), anchor="e").grid(row=0, column=1, padx=8, pady=8, sticky="e")

    def save_order(self):
        if session.current_cafe_id is None:
            self._set_notice("No active café is selected.", False)
            return
        if not self.draft_items:
            self._set_notice("Add at least one menu item before saving the order.", False)
            return

        items = [{"menu_item_id": item_id, "quantity": quantity} for item_id, quantity in self.draft_items.items()]
        result = create_order(session.current_cafe_id, items)
        if not result["success"]:
            self._set_notice(result["message"], False)
            return
        self._set_notice(result["message"], True)
        self.hide_builder()
        self.refresh_summary()
        self.refresh_orders()

    def hide_builder(self):
        self.builder.grid_remove()
        self._clear_builder()

    def refresh_orders(self):
        for child in self.history_frame.winfo_children():
            child.destroy()

        if session.current_cafe_id is None:
            empty = ctk.CTkLabel(self.history_frame, text="No café selected.", text_color="#475569", font=("Segoe UI", 13), anchor="w")
            empty.grid(row=0, column=0, padx=18, pady=20, sticky="w")
            return

        rows = list_orders(session.current_cafe_id, search=self.search_var.get(), status=self.status_var.get(), date_filter=self.date_var.get())
        if not rows:
            empty = ctk.CTkLabel(self.history_frame, text="No orders found. Create a new order to get started.", text_color="#475569", font=("Segoe UI", 13), anchor="w")
            empty.grid(row=0, column=0, padx=18, pady=20, sticky="w")
            return

        header = ctk.CTkFrame(self.history_frame, fg_color="#f8fafc")
        header.grid(row=0, column=0, padx=18, pady=(14, 8), sticky="ew")
        header.grid_columnconfigure((0, 1, 2, 3, 4, 5), weight=1)
        for idx, title in enumerate(["Order ID", "Date & Time", "Items", "Total", "Status", "Actions"]):
            ctk.CTkLabel(header, text=title, text_color="#475569", font=("Segoe UI", 11, "bold"), anchor="w").grid(row=0, column=idx, padx=12, pady=10, sticky="w")

        for index, order in enumerate(rows, start=1):
            row = ctk.CTkFrame(self.history_frame, fg_color="transparent", border_width=1, border_color="#e2e8f0")
            row.grid(row=index, column=0, padx=18, pady=8, sticky="ew")
            row.grid_columnconfigure((0, 1, 2, 3, 4, 5), weight=1)
            ctk.CTkLabel(row, text=order["order_id"], text_color="#111827", anchor="w").grid(row=0, column=0, padx=12, pady=10, sticky="w")
            ctk.CTkLabel(row, text=str(order["created_at"]), text_color="#475569", anchor="w").grid(row=0, column=1, padx=12, pady=10, sticky="w")
            ctk.CTkLabel(row, text=str(order["item_count"]), text_color="#0f172a", anchor="w").grid(row=0, column=2, padx=12, pady=10, sticky="w")
            ctk.CTkLabel(row, text=f"₹ {order['total_amount']:.2f}", text_color="#0f172a", anchor="w").grid(row=0, column=3, padx=12, pady=10, sticky="w")
            status_color = "#dcfce7" if order["order_status"] == "Completed" else "#fee2e2"
            status_text = "#166534" if order["order_status"] == "Completed" else "#991b1b"
            ctk.CTkLabel(row, text=order["order_status"], text_color=status_text, fg_color=status_color, corner_radius=8, padx=8, pady=4, font=("Segoe UI", 10, "bold")).grid(row=0, column=4, padx=12, pady=10, sticky="w")
            actions = ctk.CTkFrame(row, fg_color="transparent")
            actions.grid(row=0, column=5, padx=(0, 12), pady=8, sticky="e")
            ctk.CTkButton(actions, text="View", command=lambda order=order: self.view_order(order), height=28, corner_radius=8, fg_color="#e0ecff", hover_color="#d0e3ff", text_color="#0f172a").grid(row=0, column=0, padx=(0, 8), sticky="w")
            if order["order_status"] != "Cancelled":
                ctk.CTkButton(actions, text="Cancel", command=lambda order=order: self.cancel_selected_order(order), height=28, corner_radius=8, fg_color="#fee2e2", hover_color="#fecaca", text_color="#7f1d1d").grid(row=0, column=1, sticky="w")

    def view_order(self, order):
        detail = get_order_detail(session.current_cafe_id, order["order_id"])
        if not detail["success"]:
            self._set_notice(detail["message"], False)
            return

        self.current_order_detail = detail
        info = detail["order"]
        self._set_notice(f"Viewing {info['order_id']}", True)

        for child in self.history_frame.winfo_children():
            child.destroy()

        panel = ctk.CTkFrame(self.history_frame, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
        panel.grid(row=0, column=0, padx=18, pady=18, sticky="ew")
        panel.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(panel, text=f"Order {info['order_id']}", font=("Segoe UI", 18, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 8), sticky="w")
        ctk.CTkLabel(panel, text=f"Date & Time: {info['created_at']}", text_color="#475569", anchor="w").grid(row=1, column=0, padx=18, pady=4, sticky="w")
        ctk.CTkLabel(panel, text=f"Status: {info['order_status']}", text_color="#475569", anchor="w").grid(row=2, column=0, padx=18, pady=4, sticky="w")
        ctk.CTkLabel(panel, text=f"Total: ₹ {info['total_amount']:.2f}", text_color="#111827", font=("Segoe UI", 13, "bold"), anchor="w").grid(row=3, column=0, padx=18, pady=(4, 12), sticky="w")

        lines = detail["line_items"]
        for idx, line in enumerate(lines, start=4):
            row = ctk.CTkFrame(panel, fg_color="#f8fafc")
            row.grid(row=idx, column=0, padx=18, pady=6, sticky="ew")
            row.grid_columnconfigure((0, 1, 2, 3, 4), weight=1)
            ctk.CTkLabel(row, text=line["item_name_snapshot"], text_color="#111827", anchor="w").grid(row=0, column=0, padx=12, pady=8, sticky="w")
            ctk.CTkLabel(row, text=f"₹ {line['unit_price_snapshot']:.2f}", text_color="#475569", anchor="w").grid(row=0, column=1, padx=12, pady=8, sticky="w")
            ctk.CTkLabel(row, text=f"Qty: {line['quantity']}", text_color="#475569", anchor="w").grid(row=0, column=2, padx=12, pady=8, sticky="w")
            ctk.CTkLabel(row, text=f"Line total: ₹ {line['line_total']:.2f}", text_color="#0f172a", anchor="e").grid(row=0, column=3, padx=12, pady=8, sticky="e")

        back = ctk.CTkButton(panel, text="Back", command=lambda: self.refresh_orders(), height=36, corner_radius=10, fg_color="#f8fafc", hover_color="#eef2ff", text_color="#0f172a", border_width=1, border_color="#dfeaf8")
        back.grid(row=max(4 + len(lines), 5), column=0, padx=18, pady=(12, 18), sticky="w")

    def cancel_selected_order(self, order):
        from tkinter import messagebox

        if not messagebox.askyesno("Cancel Order", f"Cancel {order['order_id']}? This will preserve the original record but mark it cancelled."):
            return

        result = cancel_order(session.current_cafe_id, order["order_id"])
        if not result["success"]:
            self._set_notice(result["message"], False)
            return
        self._set_notice(result["message"], True)
        self.refresh_summary()
        self.refresh_orders()


class BillingManagementPage(ctk.CTkScrollableFrame):
    """Billing and receipt management for café owners."""

    def __init__(self, master, app):
        super().__init__(master, corner_radius=0, fg_color="#f4f7fb")
        self.app = app
        self.grid_columnconfigure(0, weight=1)

        self.summary_cards = []
        self.current_bill = None

        header = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        header.grid(row=0, column=0, padx=28, pady=(22, 18), sticky="ew")
        header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(header, text="Billing & Receipts", font=("Segoe UI", 27, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 4), sticky="w")
        ctk.CTkLabel(header, text="Generate bills, record payments and manage receipts.", font=("Segoe UI", 12), text_color="#475569", anchor="w").grid(row=1, column=0, padx=18, pady=(0, 18), sticky="w")

        cards_frame = ctk.CTkFrame(self, corner_radius=18, fg_color="transparent")
        cards_frame.grid(row=1, column=0, padx=28, pady=(0, 12), sticky="ew")
        cards_frame.grid_columnconfigure((0, 1, 2, 3), weight=1)

        for idx, title in enumerate(["Total Bills", "Today's Billed Sales", "Payments Received Today", "Outstanding Balance"]):
            card = ctk.CTkFrame(cards_frame, corner_radius=16, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
            card.grid(row=0, column=idx, padx=10, sticky="ew")
            card.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(card, text=title, text_color="#5a6475", font=("Segoe UI", 12), anchor="w").grid(row=0, column=0, padx=16, pady=(18, 0), sticky="w")
            value_label = ctk.CTkLabel(card, text="0", text_color="#0f172a", font=("Segoe UI", 22, "bold"), anchor="w")
            value_label.grid(row=1, column=0, padx=16, pady=(10, 18), sticky="w")
            self.summary_cards.append(value_label)

        toolbar = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
        toolbar.grid(row=2, column=0, padx=28, pady=(0, 16), sticky="ew")
        toolbar.grid_columnconfigure(0, weight=2)
        toolbar.grid_columnconfigure(1, weight=1)
        toolbar.grid_columnconfigure(2, weight=1)
        toolbar.grid_columnconfigure(3, weight=1)
        toolbar.grid_columnconfigure(4, weight=0)

        self.search_var = ctk.StringVar(value="")
        self.status_var = ctk.StringVar(value="All")
        self.date_var = ctk.StringVar(value="All")
        self.method_var = ctk.StringVar(value="All")

        search_entry = ctk.CTkEntry(toolbar, textvariable=self.search_var, placeholder_text="Search bill or order ID", height=38)
        search_entry.grid(row=0, column=0, padx=16, pady=16, sticky="ew")
        search_entry.bind("<KeyRelease>", lambda event: self.refresh_bills())

        status_filter = ctk.CTkOptionMenu(toolbar, values=["All", "Pending", "Partially Paid", "Paid"], variable=self.status_var, command=lambda _value: self.refresh_bills())
        status_filter.grid(row=0, column=1, padx=(0, 10), pady=16, sticky="ew")

        date_filter = ctk.CTkOptionMenu(toolbar, values=["All", "Today", "7 Days"], variable=self.date_var, command=lambda _value: self.refresh_bills())
        date_filter.grid(row=0, column=2, padx=(0, 10), pady=16, sticky="ew")

        method_filter = ctk.CTkOptionMenu(toolbar, values=["All", "Cash", "UPI", "Card", "Other"], variable=self.method_var, command=lambda _value: self.refresh_bills())
        method_filter.grid(row=0, column=3, padx=(0, 10), pady=16, sticky="ew")

        generate_button = ctk.CTkButton(toolbar, text="Generate Bill", command=self.show_generate_panel, height=38, corner_radius=10, fg_color="#2563eb", hover_color="#1d4f91")
        generate_button.grid(row=0, column=4, padx=(0, 16), pady=16, sticky="e")

        self.notice_label = ctk.CTkLabel(self, text="", text_color="#197C3B", font=("Segoe UI", 12, "bold"), anchor="w")
        self.notice_label.grid(row=3, column=0, padx=28, pady=(0, 6), sticky="w")

        self.generate_panel = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        self.generate_panel.grid(row=4, column=0, padx=28, pady=(0, 16), sticky="ew")
        self.generate_panel.grid_columnconfigure(0, weight=1)
        self.generate_panel.grid_remove()

        self.bill_panel = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        self.bill_panel.grid(row=5, column=0, padx=28, pady=(0, 28), sticky="nsew")
        self.bill_panel.grid_columnconfigure(0, weight=1)

        self.refresh_summary()
        self.refresh_bills()

    def _set_notice(self, message, ok=True):
        self.notice_label.configure(text=message, text_color="#197C3B" if ok else "#b42318")

    def refresh_summary(self):
        if session.current_cafe_id is None:
            for label in self.summary_cards:
                label.configure(text="0")
            return
        summary = get_bill_summary(session.current_cafe_id)
        values = [
            str(summary.get("total_bills", 0)),
            f"₹ {summary.get('today_billed_sales', 0):.2f}",
            f"₹ {summary.get('payments_received_today', 0):.2f}",
            f"₹ {summary.get('outstanding_balance', 0):.2f}",
        ]
        for label, value in zip(self.summary_cards, values):
            label.configure(text=value)

    def _clear_generate_panel(self):
        for child in self.generate_panel.winfo_children():
            child.destroy()

    def show_generate_panel(self):
        self.generate_panel.grid()
        self._clear_generate_panel()

        if session.current_cafe_id is None:
            empty = ctk.CTkLabel(self.generate_panel, text="No active café is selected.", text_color="#475569", font=("Segoe UI", 13), anchor="w")
            empty.grid(row=0, column=0, padx=18, pady=18, sticky="w")
            return

        eligible = list_eligible_orders(session.current_cafe_id)
        if not eligible:
            empty = ctk.CTkLabel(self.generate_panel, text="No eligible sales orders available for billing.", text_color="#475569", font=("Segoe UI", 13), anchor="w")
            empty.grid(row=0, column=0, padx=18, pady=18, sticky="w")
            return

        ctk.CTkLabel(self.generate_panel, text="Eligible Orders", font=("Segoe UI", 18, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 8), sticky="w")
        for index, order in enumerate(eligible, start=1):
            row = ctk.CTkFrame(self.generate_panel, fg_color="#f8fafc", border_width=1, border_color="#e2e8f0")
            row.grid(row=index, column=0, padx=18, pady=8, sticky="ew")
            row.grid_columnconfigure(0, weight=2)
            row.grid_columnconfigure(1, weight=1)
            row.grid_columnconfigure(2, weight=0)
            ctk.CTkLabel(row, text=f"{order['order_id']} • {order['created_at']}", text_color="#111827", anchor="w").grid(row=0, column=0, padx=12, pady=10, sticky="w")
            ctk.CTkLabel(row, text=f"₹ {order['total_amount']:.2f}", text_color="#0f172a", font=("Segoe UI", 12, "bold"), anchor="e").grid(row=0, column=1, padx=12, pady=10, sticky="e")
            ctk.CTkButton(row, text="Generate Bill", command=lambda order=order: self.generate_bill(order), height=30, corner_radius=8, fg_color="#10B981", hover_color="#059669").grid(row=0, column=2, padx=(0, 12), pady=10, sticky="e")

        close_button = ctk.CTkButton(self.generate_panel, text="Close", command=self.hide_generate_panel, height=36, corner_radius=10, fg_color="#f8fafc", hover_color="#eef2ff", text_color="#0f172a", border_width=1, border_color="#dfeaf8")
        close_button.grid(row=len(eligible) + 1, column=0, padx=18, pady=(10, 18), sticky="w")

    def hide_generate_panel(self):
        self.generate_panel.grid_remove()
        self._clear_generate_panel()

    def generate_bill(self, order):
        result = create_bill_from_order(session.current_cafe_id, order["order_id"])
        if not result["success"]:
            self._set_notice(result["message"], False)
            self.hide_generate_panel()
            self.refresh_bills()
            self.refresh_summary()
            if result.get("bill"):
                self.show_bill_detail(result["bill"]["bill_id"])
            return
        self._set_notice(result["message"], True)
        self.hide_generate_panel()
        self.refresh_bills()
        self.refresh_summary()
        self.show_bill_detail(result["bill"]["bill_id"])

    def refresh_bills(self):
        for child in self.bill_panel.winfo_children():
            child.destroy()

        if session.current_cafe_id is None:
            empty = ctk.CTkLabel(self.bill_panel, text="No café selected.", text_color="#475569", font=("Segoe UI", 13), anchor="w")
            empty.grid(row=0, column=0, padx=18, pady=20, sticky="w")
            return

        bills = list_bills(session.current_cafe_id, search=self.search_var.get(), payment_status=self.status_var.get(), date_filter=self.date_var.get(), payment_method=self.method_var.get())
        if not bills:
            empty = ctk.CTkLabel(self.bill_panel, text="No bills found. Generate a bill from an eligible order to begin.", text_color="#475569", font=("Segoe UI", 13), anchor="w")
            empty.grid(row=0, column=0, padx=18, pady=20, sticky="w")
            return

        header = ctk.CTkFrame(self.bill_panel, fg_color="#f8fafc")
        header.grid(row=0, column=0, padx=18, pady=(14, 8), sticky="ew")
        header.grid_columnconfigure((0, 1, 2, 3, 4, 5, 6, 7), weight=1)
        for idx, title in enumerate(["Bill ID", "Order ID", "Date", "Bill Total", "Amount Paid", "Balance Due", "Payment Status", "Actions"]):
            ctk.CTkLabel(header, text=title, text_color="#475569", font=("Segoe UI", 11, "bold"), anchor="w").grid(row=0, column=idx, padx=12, pady=10, sticky="w")

        for index, bill in enumerate(bills, start=1):
            row = ctk.CTkFrame(self.bill_panel, fg_color="transparent", border_width=1, border_color="#e2e8f0")
            row.grid(row=index, column=0, padx=18, pady=8, sticky="ew")
            row.grid_columnconfigure((0, 1, 2, 3, 4, 5, 6, 7), weight=1)
            ctk.CTkLabel(row, text=bill["bill_id"], text_color="#111827", anchor="w").grid(row=0, column=0, padx=12, pady=10, sticky="w")
            ctk.CTkLabel(row, text=bill["order_id"], text_color="#475569", anchor="w").grid(row=0, column=1, padx=12, pady=10, sticky="w")
            ctk.CTkLabel(row, text=str(bill["issued_at"]), text_color="#475569", anchor="w").grid(row=0, column=2, padx=12, pady=10, sticky="w")
            ctk.CTkLabel(row, text=f"₹ {bill['total_amount']:.2f}", text_color="#111827", anchor="w").grid(row=0, column=3, padx=12, pady=10, sticky="w")
            ctk.CTkLabel(row, text=f"₹ {bill['amount_paid']:.2f}", text_color="#111827", anchor="w").grid(row=0, column=4, padx=12, pady=10, sticky="w")
            ctk.CTkLabel(row, text=f"₹ {bill['balance_due']:.2f}", text_color="#111827", anchor="w").grid(row=0, column=5, padx=12, pady=10, sticky="w")
            status_color = {"Paid": "#dcfce7", "Partially Paid": "#fef3c7", "Pending": "#fee2e2"}.get(bill["payment_status"], "#e2e8f0")
            status_text = {"Paid": "#166534", "Partially Paid": "#92400e", "Pending": "#991b1b"}.get(bill["payment_status"], "#0f172a")
            ctk.CTkLabel(row, text=bill["payment_status"], text_color=status_text, fg_color=status_color, corner_radius=8, padx=8, pady=4, font=("Segoe UI", 10, "bold")).grid(row=0, column=6, padx=12, pady=10, sticky="w")
            actions = ctk.CTkFrame(row, fg_color="transparent")
            actions.grid(row=0, column=7, padx=(0, 12), pady=8, sticky="e")
            ctk.CTkButton(actions, text="View", command=lambda bill=bill: self.show_bill_detail(bill["bill_id"]), height=28, corner_radius=8, fg_color="#e0ecff", hover_color="#d0e3ff", text_color="#0f172a").grid(row=0, column=0, padx=(0, 8), sticky="w")
            ctk.CTkButton(actions, text="Receipt", command=lambda bill=bill: self.export_receipt(bill), height=28, corner_radius=8, fg_color="#dbeafe", hover_color="#bfdbfe", text_color="#0f172a").grid(row=0, column=1, sticky="w")

    def show_bill_detail(self, bill_id):
        if session.current_cafe_id is None:
            return
        detail = get_bill_detail(session.current_cafe_id, bill_id)
        if not detail["success"]:
            self._set_notice(detail["message"], False)
            return

        self.current_bill = detail["bill"]
        bill = detail["bill"]
        self._set_notice(f"Viewing {bill['bill_id']}", True)

        for child in self.bill_panel.winfo_children():
            child.destroy()

        panel = ctk.CTkFrame(self.bill_panel, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        panel.grid(row=0, column=0, padx=18, pady=18, sticky="ew")
        panel.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(panel, text=f"Bill {bill['bill_id']}", font=("Segoe UI", 18, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 8), sticky="w")
        ctk.CTkLabel(panel, text=f"Order: {bill['order_id']}", text_color="#475569", anchor="w").grid(row=1, column=0, padx=18, pady=4, sticky="w")
        ctk.CTkLabel(panel, text=f"Issued: {bill['issued_at']}", text_color="#475569", anchor="w").grid(row=2, column=0, padx=18, pady=4, sticky="w")
        ctk.CTkLabel(panel, text=f"Status: {bill['payment_status']}", text_color="#475569", anchor="w").grid(row=3, column=0, padx=18, pady=4, sticky="w")
        ctk.CTkLabel(panel, text=f"Total: ₹ {bill['total_amount']:.2f} | Amount Paid: ₹ {bill['amount_paid']:.2f} | Balance Due: ₹ {bill['balance_due']:.2f}", text_color="#111827", font=("Segoe UI", 13, "bold"), anchor="w").grid(row=4, column=0, padx=18, pady=(4, 12), sticky="w")

        self.payment_form = ctk.CTkFrame(panel, fg_color="#f8fafc", border_width=1, border_color="#dfeaf8")
        self.payment_form.grid(row=5, column=0, padx=18, pady=(0, 18), sticky="ew")
        self.payment_form.grid_columnconfigure((0, 1, 2, 3), weight=1)

        ctk.CTkLabel(self.payment_form, text="Record Payment", font=("Segoe UI", 16, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, columnspan=4, padx=14, pady=(14, 8), sticky="w")

        self.amount_var = ctk.StringVar(value="")
        self.method_var_ui = ctk.StringVar(value="Cash")
        self.reference_var = ctk.StringVar(value="")
        self.notes_var = ctk.StringVar(value="")

        ctk.CTkEntry(self.payment_form, textvariable=self.amount_var, placeholder_text="Amount", height=36).grid(row=1, column=0, padx=14, pady=8, sticky="ew")
        method_menu = ctk.CTkOptionMenu(self.payment_form, values=["Cash", "UPI", "Card", "Other"], variable=self.method_var_ui)
        method_menu.grid(row=1, column=1, padx=14, pady=8, sticky="ew")
        ctk.CTkEntry(self.payment_form, textvariable=self.reference_var, placeholder_text="Reference (optional)", height=36).grid(row=1, column=2, padx=14, pady=8, sticky="ew")
        ctk.CTkEntry(self.payment_form, textvariable=self.notes_var, placeholder_text="Notes (optional)", height=36).grid(row=1, column=3, padx=14, pady=8, sticky="ew")
        ctk.CTkButton(self.payment_form, text="Record Payment", command=self.record_payment, height=36, corner_radius=10, fg_color="#10B981", hover_color="#059669").grid(row=2, column=0, padx=14, pady=(8, 14), sticky="w")
        ctk.CTkButton(self.payment_form, text="Export Receipt", command=lambda: self.export_receipt(bill), height=36, corner_radius=10, fg_color="#e0ecff", hover_color="#d0e3ff", text_color="#0f172a").grid(row=2, column=1, padx=14, pady=(8, 14), sticky="w")
        ctk.CTkButton(self.payment_form, text="Back", command=lambda: self.refresh_bills(), height=36, corner_radius=10, fg_color="#f8fafc", hover_color="#eef2ff", text_color="#0f172a", border_width=1, border_color="#dfeaf8").grid(row=2, column=2, padx=14, pady=(8, 14), sticky="w")

        payment_history = detail["payments"]
        if not payment_history:
            empty = ctk.CTkLabel(panel, text="No payments have been recorded for this bill yet.", text_color="#475569", anchor="w")
            empty.grid(row=6, column=0, padx=18, pady=(0, 10), sticky="w")
            return

        ctk.CTkLabel(panel, text="Payment History", font=("Segoe UI", 16, "bold"), text_color="#111827", anchor="w").grid(row=6, column=0, padx=18, pady=(0, 8), sticky="w")
        for idx, payment in enumerate(payment_history, start=7):
            row = ctk.CTkFrame(panel, fg_color="#f8fafc")
            row.grid(row=idx, column=0, padx=18, pady=6, sticky="ew")
            row.grid_columnconfigure((0, 1, 2, 3), weight=1)
            ctk.CTkLabel(row, text=payment["payment_id"], text_color="#111827", anchor="w").grid(row=0, column=0, padx=12, pady=8, sticky="w")
            ctk.CTkLabel(row, text=payment["payment_date"], text_color="#475569", anchor="w").grid(row=0, column=1, padx=12, pady=8, sticky="w")
            ctk.CTkLabel(row, text=f"₹ {payment['amount']:.2f}", text_color="#0f172a", anchor="w").grid(row=0, column=2, padx=12, pady=8, sticky="w")
            ctk.CTkLabel(row, text=payment["payment_method"], text_color="#0f172a", anchor="w").grid(row=0, column=3, padx=12, pady=8, sticky="w")

    def record_payment(self):
        if session.current_cafe_id is None or self.current_bill is None:
            self._set_notice("No bill is currently selected.", False)
            return

        try:
            amount = float(self.amount_var.get())
        except ValueError:
            self._set_notice("Payment amount must be numeric.", False)
            return

        result = record_payment(
            session.current_cafe_id,
            self.current_bill["bill_id"],
            amount,
            self.method_var_ui.get(),
            reference=self.reference_var.get(),
            notes=self.notes_var.get(),
        )
        if not result["success"]:
            self._set_notice(result["message"], False)
            return
        self._set_notice(result["message"], True)
        self.show_bill_detail(self.current_bill["bill_id"])
        self.refresh_summary()
        self.refresh_bills()

    def export_receipt(self, bill):
        if session.current_cafe_id is None:
            self._set_notice("No active café is selected.", False)
            return
        result = export_receipt_pdf(session.current_cafe_id, bill["bill_id"])
        if not result["success"]:
            self._set_notice(result["message"], False)
            return
        self._set_notice(f"Receipt exported: {result['path']}", True)
        try:
            import os
            os.startfile(result["path"])
        except Exception:
            pass


class PlatformActivityPage(ctk.CTkScrollableFrame):
    """Platform audit log and activity management screen."""

    def __init__(self, master, app):
        super().__init__(master, corner_radius=0, fg_color="#f4f7fb")
        self.app = app
        self.grid_columnconfigure(0, weight=1)

        self.search_string = ctk.StringVar(value="")
        self.action_filter = ctk.StringVar(value="All")
        self.status_filter = ctk.StringVar(value="All")
        self.actor_filter = ctk.StringVar(value="All")
        self.date_filter = ctk.StringVar(value="All")

        self.header = ctk.CTkFrame(self, fg_color="transparent")
        self.header.grid(row=0, column=0, padx=28, pady=(20, 12), sticky="ew")
        self.header.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            self.header,
            text="Platform Activity",
            font=("Segoe UI", 24, "bold"),
            text_color="#111827",
            anchor="w",
        ).grid(row=0, column=0, sticky="w")
        ctk.CTkLabel(
            self.header,
            text="Track important actions across the CaféSync platform.",
            font=("Segoe UI", 12),
            text_color="#475569",
            anchor="w",
        ).grid(row=1, column=0, sticky="w")

        summary = get_platform_activity_summary()
        cards_frame = ctk.CTkFrame(self, corner_radius=18, fg_color="transparent")
        cards_frame.grid(row=1, column=0, padx=28, pady=(0, 16), sticky="ew")
        cards_frame.grid_columnconfigure((0, 1, 2, 3), weight=1)

        metric_items = [
            ("Total Activities", str(summary["total"])),
            ("Today's Activities", str(summary["today"])),
            ("Café Changes", str(summary["cafe_changes"])),
            ("Admin Actions", str(summary["admin_actions"])),
        ]
        for idx, (title, value) in enumerate(metric_items):
            card = ctk.CTkFrame(cards_frame, corner_radius=16, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
            card.grid(row=0, column=idx, padx=10, sticky="ew")
            card.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(card, text=title, text_color="#5a6475", font=("Segoe UI", 12), anchor="w").grid(row=0, column=0, padx=16, pady=(16, 0), sticky="w")
            ctk.CTkLabel(card, text=value, text_color="#0f172a", font=("Segoe UI", 25, "bold"), anchor="w").grid(row=1, column=0, padx=16, pady=(10, 18), sticky="w")

        toolbar = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
        toolbar.grid(row=2, column=0, padx=28, pady=(0, 14), sticky="ew")
        toolbar.grid_columnconfigure(0, weight=2)
        toolbar.grid_columnconfigure(1, weight=1)
        toolbar.grid_columnconfigure(2, weight=1)
        toolbar.grid_columnconfigure(3, weight=1)

        search_entry = ctk.CTkEntry(toolbar, textvariable=self.search_string, placeholder_text="🔍 Search activity...", height=38)
        search_entry.grid(row=0, column=0, padx=16, pady=16, sticky="ew")
        search_entry.bind("<KeyRelease>", lambda event: self.refresh_list())

        action_menu = ctk.CTkOptionMenu(toolbar, values=["All", "CAFE_REGISTERED", "ACTIVATE_CAFE", "DEACTIVATE_CAFE", "REACTIVATE_CAFE"], variable=self.action_filter, command=lambda value: self.refresh_list())
        action_menu.grid(row=0, column=1, padx=(0, 10), pady=16, sticky="ew")

        status_menu = ctk.CTkOptionMenu(toolbar, values=["All", "SUCCESS", "FAILED"], variable=self.status_filter, command=lambda value: self.refresh_list())
        status_menu.grid(row=0, column=2, padx=(0, 10), pady=16, sticky="ew")

        date_menu = ctk.CTkOptionMenu(toolbar, values=["All", "Today", "Last 7 Days", "Last 30 Days"], variable=self.date_filter, command=lambda value: self.refresh_list())
        date_menu.grid(row=0, column=3, pady=16, sticky="ew")

        self.activity_panel = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
        self.activity_panel.grid(row=3, column=0, padx=28, pady=(0, 28), sticky="nsew")
        self.activity_panel.grid_columnconfigure(0, weight=1)
        self.detail_panel = None
        self.refresh_list()

    def refresh_list(self):
        for child in self.activity_panel.winfo_children():
            child.destroy()

        rows = list_platform_activity(
            search=self.search_string.get(),
            action_filter=self.action_filter.get(),
            status_filter=self.status_filter.get(),
            actor_filter="All",
            date_filter=self.date_filter.get(),
        )

        if not rows:
            empty_label = ctk.CTkLabel(self.activity_panel, text="No activity found.\nTry changing your search or filters.", text_color="#475569", justify="left", height=90)
            empty_label.grid(row=0, column=0, padx=18, pady=20, sticky="w")
            return

        header = ctk.CTkFrame(self.activity_panel, fg_color="#f8fafc")
        header.grid(row=0, column=0, padx=18, pady=(14, 8), sticky="ew")
        header.grid_columnconfigure((0, 1, 2, 3, 4, 5), weight=1)
        for idx, title in enumerate(["Time", "Actor", "Action", "Café", "Status", "Details"]):
            ctk.CTkLabel(header, text=title, text_color="#475569", font=("Segoe UI", 11, "bold"), anchor="w").grid(row=0, column=idx, padx=12, pady=10, sticky="w")

        for index, row in enumerate(rows, start=1):
            item = ctk.CTkFrame(self.activity_panel, fg_color="transparent", border_width=1, border_color="#e2e8f0")
            item.grid(row=index, column=0, padx=18, pady=8, sticky="ew")
            item.grid_columnconfigure((0, 1, 2, 3, 4, 5), weight=1)

            timestamp = row.get("timestamp", "")
            actor_name = row.get("actor_name", "Unknown")
            actor_id = row.get("actor_id", "")
            action = row.get("action", "UNKNOWN")
            target_name = row.get("target_name", "Unknown")
            target_id = row.get("target_id", "")
            status = row.get("status", "FAILED")
            details = row.get("details", "")

            ctk.CTkLabel(item, text=timestamp, text_color="#475569", anchor="w").grid(row=0, column=0, padx=12, pady=12, sticky="w")
            ctk.CTkLabel(item, text=f"{actor_name}\n{actor_id}", text_color="#0f172a", justify="left", anchor="w").grid(row=0, column=1, padx=12, pady=12, sticky="w")
            ctk.CTkLabel(item, text=action, text_color="#0f172a", font=("Segoe UI", 12, "bold"), anchor="w").grid(row=0, column=2, padx=12, pady=12, sticky="w")
            ctk.CTkLabel(item, text=f"{target_name}\n{target_id}", text_color="#0f172a", justify="left", anchor="w").grid(row=0, column=3, padx=12, pady=12, sticky="w")
            ctk.CTkLabel(item, text=f"● {status.title()}", text_color="#16a34a" if status.upper() == "SUCCESS" else "#ef4444", font=("Segoe UI", 12, "bold"), anchor="w").grid(row=0, column=4, padx=12, pady=12, sticky="w")
            ctk.CTkButton(item, text="View", command=lambda activity_id=row.get("activity_id"): self.show_detail(activity_id), width=70, height=30, corner_radius=8, fg_color="#e0ecff", hover_color="#d0e3ff", text_color="#0f172a").grid(row=0, column=5, padx=12, pady=12, sticky="e")
            label = ctk.CTkLabel(item, text=details, text_color="#475569", justify="left", anchor="w")
            label.grid(row=1, column=0, columnspan=6, padx=12, pady=(0, 12), sticky="w")

    def show_detail(self, activity_id):
        detail = get_activity_detail(activity_id)
        if not detail:
            return

        if self.detail_panel is not None:
            self.detail_panel.destroy()
        self.detail_panel = ctk.CTkToplevel(self.app.root)
        self.detail_panel.title("Activity Details")
        self.detail_panel.geometry("520x420")
        self.detail_panel.resizable(False, False)

        content = ctk.CTkFrame(self.detail_panel, corner_radius=18, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
        content.pack(fill="both", expand=True, padx=20, pady=20)
        content.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(content, text="Activity Details", font=("Segoe UI", 22, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 8), sticky="w")

        info = [
            ("Activity ID", detail.get("activity_id", "")),
            ("Timestamp", detail.get("timestamp", "")),
            ("Actor", detail.get("actor_name", "")),
            ("Actor ID", detail.get("actor_id", "")),
            ("Role", detail.get("actor_role", "")),
            ("Action", detail.get("action", "")),
            ("Target", detail.get("target_name", "")),
            ("Target ID", detail.get("target_id", "")),
            ("Status", detail.get("status", "")),
            ("Details", detail.get("details", "")),
        ]
        for idx, (label, value) in enumerate(info):
            ctk.CTkLabel(content, text=f"{label}:", text_color="#64748b", font=("Segoe UI", 11, "bold"), anchor="w").grid(row=idx + 1, column=0, padx=18, pady=(0, 2), sticky="w")
            ctk.CTkLabel(content, text=str(value), text_color="#0f172a", justify="left", wraplength=440, anchor="w").grid(row=idx + 1, column=1, padx=(0, 18), pady=(0, 2), sticky="w")



class SetupWizardFrame(ctk.CTkFrame):
    """Progressive quick-start onboarding for a newly opened café."""

    def __init__(self, master, app):
        super().__init__(master, corner_radius=0, fg_color="#f4f7fb")
        self.app = app
        self.grid_columnconfigure(0, weight=1)
        self.step_index = 0
        self.step_titles = [
            "Welcome",
            "Café basics",
            "First menu items",
            "Ready to go",
        ]
        self.render()

    def _clear_widgets(self):
        for widget in self.winfo_children():
            widget.destroy()

    def get_current_cafe_id(self):
        return session.current_cafe_id

    def refresh_status(self):
        cafe_id = self.get_current_cafe_id()
        if not cafe_id:
            return {"quick_start_progress": 0, "setup_progress": 0, "quick_start_completed": False}
        status = get_setup_status(cafe_id)
        self.status = status
        return status

    def render(self):
        self._clear_widgets()
        self.grid_columnconfigure(0, weight=1)

        status = self.refresh_status()
        progress = int(status.get("quick_start_progress", 0) or 0)

        header = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        header.grid(row=0, column=0, padx=28, pady=(22, 18), sticky="ew")
        header.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            header,
            text="Quick Start",
            font=("Segoe UI", 26, "bold"),
            text_color="#111827",
            anchor="w",
        ).grid(row=0, column=0, padx=20, pady=(18, 4), sticky="w")

        ctk.CTkLabel(
            header,
            text=f"Progress: {progress}%",
            font=("Segoe UI", 12, "bold"),
            text_color="#1d4f91",
            anchor="w",
        ).grid(row=1, column=0, padx=20, pady=(0, 10), sticky="w")

        progress_bar = ctk.CTkProgressBar(header, height=14, width=500)
        progress_bar.grid(row=2, column=0, padx=20, pady=(0, 20), sticky="ew")
        progress_bar.set(progress / 100)

        panel = ctk.CTkFrame(self, corner_radius=22, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        panel.grid(row=1, column=0, padx=28, pady=(0, 20), sticky="nsew")
        panel.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            panel,
            text=f"Step {self.step_index + 1} of {len(self.step_titles)} · {self.step_titles[self.step_index]}",
            font=("Segoe UI", 18, "bold"),
            text_color="#111827",
            anchor="w",
        ).grid(row=0, column=0, padx=22, pady=(20, 12), sticky="w")

        self.message_label = ctk.CTkLabel(panel, text="", text_color="#b42318", font=("Segoe UI", 12), wraplength=700)
        self.message_label.grid(row=1, column=0, padx=22, pady=(0, 10), sticky="w")

        self.content_frame = ctk.CTkFrame(panel, fg_color="transparent")
        self.content_frame.grid(row=2, column=0, padx=22, pady=(0, 18), sticky="nsew")
        self.content_frame.grid_columnconfigure(0, weight=1)

        self.build_step_content()

        nav_row = ctk.CTkFrame(panel, fg_color="transparent")
        nav_row.grid(row=3, column=0, padx=22, pady=(0, 22), sticky="ew")
        nav_row.grid_columnconfigure(0, weight=1)
        nav_row.grid_columnconfigure(1, weight=0)
        nav_row.grid_columnconfigure(2, weight=0)

        self.prev_button = ctk.CTkButton(nav_row, text="Previous", command=self.go_previous, height=40, corner_radius=10, fg_color="#e2e8f0", hover_color="#dfeaf8", text_color="#0f172a")
        self.prev_button.grid(row=0, column=1, padx=(0, 8), sticky="w")

        self.skip_button = ctk.CTkButton(nav_row, text="Skip for now", command=self.skip_for_now, height=40, corner_radius=10, fg_color="#f8fafc", hover_color="#eef2ff", text_color="#0f172a", border_width=1, border_color="#dfeaf8")
        self.skip_button.grid(row=0, column=0, padx=(0, 8), sticky="w")

        self.next_button = ctk.CTkButton(nav_row, text="Continue", command=self.go_next, height=40, corner_radius=10, fg_color="#2563eb", hover_color="#1d4f91")
        self.next_button.grid(row=0, column=2, sticky="e")

        if self.step_index == 0:
            self.prev_button.configure(state="disabled")
        if self.step_index == 3:
            self.next_button.configure(text="Continue to Dashboard")
            self.skip_button.configure(text="Return later", command=self.skip_for_now)

    def build_step_content(self):
        if self.step_index == 0:
            self._build_welcome_step()
            return
        if self.step_index == 1:
            self._build_profile_step()
            return
        if self.step_index == 2:
            self._build_menu_step()
            return
        self._build_complete_step()

    def _build_welcome_step(self):
        ctk.CTkLabel(
            self.content_frame,
            text="Start selling quickly with the essentials. Add your café basics and your first menu item, then move to the dashboard. You can finish the rest later whenever you’re ready.",
            font=("Segoe UI", 14),
            text_color="#475569",
            justify="left",
            wraplength=700,
        ).grid(row=0, column=0, padx=4, pady=(10, 18), sticky="w")

        checklist = [
            "Enter your café name and location",
            "Add your first menu item or use demo items",
            "Continue to the dashboard immediately after quick start",
        ]
        for index, item in enumerate(checklist, start=1):
            ctk.CTkLabel(self.content_frame, text=f"{index}. {item}", text_color="#0f172a", font=("Segoe UI", 13), anchor="w").grid(row=index, column=0, padx=4, pady=4, sticky="w")

    def _build_profile_step(self):
        fields = {
            "cafe_name": ctk.CTkEntry(self.content_frame, placeholder_text="Café name", width=650, height=42),
            "location": ctk.CTkEntry(self.content_frame, placeholder_text="Location", width=650, height=42),
            "phone": ctk.CTkEntry(self.content_frame, placeholder_text="Phone", width=650, height=42),
            "cafe_type": ctk.CTkEntry(self.content_frame, placeholder_text="Café type (optional)", width=650, height=42),
            "opening_date": ctk.CTkEntry(self.content_frame, placeholder_text="Opening date (optional)", width=650, height=42),
            "opening_time": ctk.CTkEntry(self.content_frame, placeholder_text="Opening time (optional)", width=650, height=42),
            "closing_time": ctk.CTkEntry(self.content_frame, placeholder_text="Closing time (optional)", width=650, height=42),
        }
        self.profile_fields = fields

        cafe = self.app.get_current_cafe_data()
        defaults = cafe or {}
        for idx, (key, widget) in enumerate(fields.items(), start=0):
            widget.insert(0, str(defaults.get(key, "") or ""))
            widget.grid(row=idx, column=0, padx=4, pady=8, sticky="ew")

    def _build_menu_step(self):
        self.menu_fields = {
            "item_name": ctk.CTkEntry(self.content_frame, placeholder_text="Menu item name", width=650, height=42),
            "category": ctk.CTkEntry(self.content_frame, placeholder_text="Category", width=650, height=42),
            "price": ctk.CTkEntry(self.content_frame, placeholder_text="Price", width=650, height=42),
        }
        for idx, widget in enumerate(self.menu_fields.values(), start=0):
            widget.grid(row=idx, column=0, padx=4, pady=8, sticky="ew")

        button_row = ctk.CTkFrame(self.content_frame, fg_color="transparent")
        button_row.grid(row=3, column=0, padx=4, pady=(14, 0), sticky="w")
        ctk.CTkButton(button_row, text="Add item", command=self.add_menu_item, height=38, corner_radius=10, fg_color="#16a34a", hover_color="#15803d").grid(row=0, column=0, padx=(0, 8), sticky="w")
        ctk.CTkButton(button_row, text="Use demo items", command=self.use_demo_menu, height=38, corner_radius=10, fg_color="#e0ecff", hover_color="#d0e3ff", text_color="#0f172a").grid(row=0, column=1, padx=(0, 8), sticky="w")
        ctk.CTkButton(button_row, text="Skip menu setup", command=self.skip_menu_setup, height=38, corner_radius=10, fg_color="#f8fafc", hover_color="#eef2ff", text_color="#0f172a", border_width=1, border_color="#dfeaf8").grid(row=0, column=2, sticky="w")

    def _build_complete_step(self):
        status = self.refresh_status()
        ctk.CTkLabel(self.content_frame, text="Quick Start complete", text_color="#0f172a", font=("Segoe UI", 20, "bold"), wraplength=700).grid(row=0, column=0, padx=4, pady=(10, 8), sticky="w")
        ctk.CTkLabel(self.content_frame, text="Your café is ready to operate. You can continue to the dashboard now and finish optional setup later.", text_color="#475569", font=("Segoe UI", 13), wraplength=700).grid(row=1, column=0, padx=4, pady=(0, 12), sticky="w")
        ctk.CTkLabel(self.content_frame, text=f"Quick Start progress: {status.get('quick_start_progress', 0)}%", text_color="#1d4f91", font=("Segoe UI", 14, "bold")).grid(row=2, column=0, padx=4, pady=4, sticky="w")
        ctk.CTkLabel(self.content_frame, text=f"Optional setup progress: {status.get('optional_setup_progress', 0)}%", text_color="#64748b", font=("Segoe UI", 12)).grid(row=3, column=0, padx=4, pady=(0, 12), sticky="w")
        ctk.CTkButton(self.content_frame, text="Continue to Dashboard", command=self.complete_setup, height=42, corner_radius=10, fg_color="#2563eb", hover_color="#1d4f91").grid(row=4, column=0, padx=4, pady=(8, 0), sticky="w")

    def add_menu_item(self):
        cafe_id = self.get_current_cafe_id()
        item_name = self.menu_fields["item_name"].get().strip()
        category = self.menu_fields["category"].get().strip()
        price = self.menu_fields["price"].get().strip()

        if not item_name and not category and not price:
            self.message_label.configure(text="No menu item added yet. You can add one later from the Setup checklist.", text_color="#475569")
            self.step_index = 3
            self.render()
            return

        if not item_name or not category or not price:
            self.message_label.configure(text="Add the item name, category, and price, or skip this step.", text_color="#b42318")
            return

        result = save_menu_item(cafe_id, item_name, category, price)
        if result.get("success"):
            self.message_label.configure(text=result["message"], text_color="#197C3B")
            self.refresh_status()
            self.step_index = 3
            self.render()
        else:
            self.message_label.configure(text=result["message"], text_color="#b42318")

    def use_demo_menu(self):
        cafe_id = self.get_current_cafe_id()
        if not cafe_id:
            self.message_label.configure(text="No active café found.", text_color="#b42318")
            return

        result = seed_demo_menu_items(cafe_id)
        self.message_label.configure(text=result.get("message", "Demo menu items added."), text_color="#197C3B")
        self.refresh_status()
        self.step_index = 3
        self.render()

    def skip_menu_setup(self):
        self.message_label.configure(text="Menu setup can be completed later from the Setup checklist.", text_color="#475569")
        self.step_index = 3
        self.render()

    def save_profile(self):
        cafe_id = self.get_current_cafe_id()
        if not cafe_id:
            self.message_label.configure(text="No active café found.", text_color="#b42318")
            return

        payload = {key: widget.get().strip() for key, widget in self.profile_fields.items()}
        if not payload.get("cafe_name") or not payload.get("location"):
            self.message_label.configure(text="Please enter the café name and location to continue.", text_color="#b42318")
            return

        result = update_cafe_profile(
            cafe_id,
            payload["cafe_name"],
            payload["location"],
            payload.get("phone", ""),
            payload.get("cafe_type", ""),
            payload.get("opening_date", ""),
            payload.get("opening_time", ""),
            payload.get("closing_time", ""),
        )
        if result.get("success"):
            self.message_label.configure(text=result["message"], text_color="#197C3B")
            self.refresh_status()
            self.step_index = 2
            self.render()
        else:
            self.message_label.configure(text=result["message"], text_color="#b42318")

    def complete_setup(self):
        cafe_id = self.get_current_cafe_id()
        if cafe_id:
            self.refresh_status()
        self.app.show_page("Dashboard")

    def skip_for_now(self):
        self.app.show_page("Dashboard")

    def go_previous(self):
        if self.step_index > 0:
            self.step_index -= 1
            self.render()

    def go_next(self):
        if self.step_index == 0:
            self.step_index = 1
            self.render()
            return
        if self.step_index == 1:
            self.save_profile()
            return
        if self.step_index == 2:
            self.add_menu_item()
            return
        self.complete_setup()


class OwnerDashboardFrame(ctk.CTkScrollableFrame):
    """Café owner dashboard with current café information."""

    def __init__(self, master, app):
        super().__init__(master, corner_radius=0, fg_color="#f4f7fb")
        self.app = app
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=0)
        self.grid_rowconfigure(1, weight=0)
        self.grid_rowconfigure(2, weight=1)
        self.grid_rowconfigure(3, weight=0)

        cafe = app.get_current_cafe_data()
        cafe_name = cafe["cafe_name"] if cafe else "Café"
        location = cafe["location"] if cafe else "Location"

        header = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        header.grid(row=0, column=0, padx=28, pady=(22, 16), sticky="ew")
        header.grid_columnconfigure(0, weight=1)
        header.grid_columnconfigure(1, weight=0)

        ctk.CTkLabel(
            header,
            text=f"Welcome, {session.current_user_name}",
            font=("Segoe UI", 22, "bold"),
            text_color="#111827",
            anchor="w",
        ).grid(row=0, column=0, padx=18, pady=(18, 6), sticky="w")

        ctk.CTkLabel(
            header,
            text=f"Business: {cafe_name}",
            font=("Segoe UI", 14, "bold"),
            text_color="#1d4f91",
            anchor="w",
        ).grid(row=1, column=0, padx=18, pady=(0, 6), sticky="w")

        ctk.CTkLabel(
            header,
            text=f"Location: {location}",
            font=("Segoe UI", 12),
            text_color="#475569",
            anchor="w",
        ).grid(row=2, column=0, padx=18, pady=(0, 18), sticky="w")

        current_cafe_chip = ctk.CTkLabel(
            header,
            text=f"Current Café: {cafe_name}",
            font=("Segoe UI", 11, "bold"),
            text_color="#0f172a",
            fg_color="#dfeaf8",
            corner_radius=10,
        )
        current_cafe_chip.grid(row=0, column=1, rowspan=3, padx=(0, 18), pady=18, sticky="e")

        setup_status = get_setup_status(session.current_cafe_id)
        quick_start_complete = bool(setup_status.get("quick_start_completed", False))
        optional_progress = int(setup_status.get("optional_setup_progress", 0) or 0)
        onboarding_dismissed = bool(setup_status.get("onboarding_dismissed", False))

        row_index = 1
        self.onboarding_frame = None
        if not onboarding_dismissed:
            self.onboarding_frame = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
            self.onboarding_frame.grid(row=row_index, column=0, padx=28, pady=(0, 20), sticky="ew")
            self.onboarding_frame.grid_columnconfigure(0, weight=1)
            self.onboarding_frame.grid_columnconfigure(1, weight=0)
            row_index += 1

            if quick_start_complete:
                ctk.CTkLabel(self.onboarding_frame, text="Optional setup checklist", font=("Segoe UI", 16, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 8), sticky="w")
                ctk.CTkLabel(self.onboarding_frame, text=f"{optional_progress}% complete", text_color="#1d4f91", font=("Segoe UI", 12, "bold"), anchor="w").grid(row=1, column=0, padx=18, pady=(0, 10), sticky="w")
                remaining_tasks = [
                    ("Add ingredients", bool(get_inventory_for_cafe(session.current_cafe_id).empty is False), "Inventory"),
                    ("Configure recipes", bool(get_recipes_for_cafe(session.current_cafe_id).empty is False), "Recipes"),
                    ("Set opening stock", bool(setup_status.get("opening_stock_complete", False)), "Inventory"),
                    ("Add suppliers", bool(get_suppliers_for_cafe(session.current_cafe_id).empty is False), "Suppliers"),
                ]
                task_rows = [(label, target) for label, complete, target in remaining_tasks if not complete]
                for index, (label, target) in enumerate(task_rows[:4], start=2):
                    row = ctk.CTkFrame(self.onboarding_frame, fg_color="#f8fafc")
                    row.grid(row=index, column=0, padx=18, pady=6, sticky="ew")
                    row.grid_columnconfigure(0, weight=1)
                    row.grid_columnconfigure(1, weight=0)
                    ctk.CTkLabel(row, text=label, text_color="#0f172a", anchor="w", font=("Segoe UI", 12, "bold")).grid(row=0, column=0, padx=12, pady=8, sticky="w")
                    ctk.CTkButton(row, text="Open", command=lambda page=target: self.app.show_page(page), height=28, width=80, corner_radius=8, fg_color="#e0ecff", hover_color="#d0e3ff", text_color="#0f172a").grid(row=0, column=1, padx=(0, 12), pady=8, sticky="e")

                if not task_rows:
                    ctk.CTkLabel(self.onboarding_frame, text="Everything recommended is already in place. You can keep serving and return to setup later.", text_color="#475569", anchor="w", justify="left", wraplength=800).grid(row=2, column=0, padx=18, pady=(0, 18), sticky="w")

                ctk.CTkButton(self.onboarding_frame, text="Continue Setup", command=lambda: self.app.show_page("Setup"), height=38, corner_radius=10, fg_color="#2563eb", hover_color="#1d4f91").grid(row=100, column=0, padx=18, pady=(10, 18), sticky="w")
                ctk.CTkButton(self.onboarding_frame, text="Dismiss", command=self.dismiss_onboarding_checklist, height=36, corner_radius=10, fg_color="#f8fafc", hover_color="#eef2ff", text_color="#0f172a", border_width=1, border_color="#dfeaf8").grid(row=100, column=1, padx=(0, 18), pady=(10, 18), sticky="e")
            else:
                ctk.CTkLabel(self.onboarding_frame, text="Finish your quick start", font=("Segoe UI", 16, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 8), sticky="w")
                ctk.CTkLabel(self.onboarding_frame, text="Set up your basic café profile and add at least one menu item to unlock the dashboard.", text_color="#475569", anchor="w", wraplength=800).grid(row=1, column=0, padx=18, pady=(0, 12), sticky="w")
                ctk.CTkButton(self.onboarding_frame, text="Continue Setup", command=lambda: self.app.show_page("Setup"), height=38, corner_radius=10, fg_color="#2563eb", hover_color="#1d4f91").grid(row=2, column=0, padx=18, pady=(0, 18), sticky="w")
                ctk.CTkButton(self.onboarding_frame, text="Dismiss", command=self.dismiss_onboarding_checklist, height=36, corner_radius=10, fg_color="#f8fafc", hover_color="#eef2ff", text_color="#0f172a", border_width=1, border_color="#dfeaf8").grid(row=2, column=1, padx=(0, 18), pady=(0, 18), sticky="e")

        checklist_frame = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        checklist_frame.grid(row=row_index, column=0, padx=28, pady=(0, 20), sticky="ew")
        checklist_frame.grid_columnconfigure(0, weight=1)
        row_index += 1

        ctk.CTkLabel(
            checklist_frame,
            text="Recommended Setup",
            font=("Segoe UI", 16, "bold"),
            text_color="#111827",
            anchor="w",
        ).grid(row=0, column=0, padx=18, pady=(18, 10), sticky="w")

        checklist = [
            ("Café profile", bool(session.current_cafe_name), "Create your café profile"),
            ("Menu", bool(get_menu_for_cafe(session.current_cafe_id).empty is False), "Add your first menu items"),
            ("Ingredients", bool(get_inventory_for_cafe(session.current_cafe_id).empty is False), "Add ingredients and stock thresholds"),
            ("Recipes", bool(get_recipes_for_cafe(session.current_cafe_id).empty is False), "Define recipe ingredients"),
            ("Opening stock", bool(setup_status.get("opening_stock_complete", False)), "Set opening stock"),
            ("Suppliers", bool(get_suppliers_for_cafe(session.current_cafe_id).empty is False), "Add suppliers"),
        ]

        for row_number, (label, complete, helper) in enumerate(checklist, start=1):
            status_text = "Complete" if complete else "Recommended"
            badge_color = "#dcfce7" if complete else "#e0ecff"
            badge_text = "#166534" if complete else "#1d4f91"
            row = ctk.CTkFrame(checklist_frame, fg_color="#f8fafc")
            row.grid(row=row_number, column=0, padx=18, pady=6, sticky="ew")
            row.grid_columnconfigure(0, weight=1)
            row.grid_columnconfigure(1, weight=0)
            ctk.CTkLabel(row, text=f"{label}", text_color="#0f172a", anchor="w", font=("Segoe UI", 12, "bold")).grid(row=0, column=0, padx=12, pady=8, sticky="w")
            ctk.CTkLabel(row, text=status_text, text_color=badge_text, fg_color=badge_color, corner_radius=8, padx=8, pady=4, font=("Segoe UI", 10, "bold")).grid(row=0, column=1, padx=(0, 12), pady=8, sticky="e")

        cards_frame = ctk.CTkFrame(self, corner_radius=18, fg_color="transparent")
        cards_frame.grid(row=row_index, column=0, padx=28, pady=(0, 20), sticky="ew")
        cards_frame.grid_columnconfigure((0, 1, 2, 3), weight=1)
        for col in range(4):
            cards_frame.grid_columnconfigure(col, weight=1, minsize=180)

        summary_cards = [
            ("Today's Sales", "₹ 18,540", "+12.4% vs yesterday"),
            ("Today's Orders", "128", "14 dine-in, 42 take-away"),
            ("Low Stock", "07", "3 critical items"),
            ("Waste", "12 kg", "Down 4.1% this week"),
        ]

        for idx, (title, value, subtitle) in enumerate(summary_cards):
            card = StatCard(cards_frame, title, value, subtitle)
            card.grid(row=0, column=idx, padx=10, pady=0, sticky="ew")

        content_row = ctk.CTkFrame(self, corner_radius=18, fg_color="transparent")
        content_row.grid(row=row_index + 1, column=0, padx=28, pady=(0, 20), sticky="nsew")
        content_row.grid_columnconfigure(0, weight=2)
        content_row.grid_columnconfigure(1, weight=1)

        recent_orders_frame = ctk.CTkFrame(
            content_row,
            corner_radius=16,
            fg_color="#ffffff",
            border_color="#dfeaf8",
            border_width=1,
        )
        recent_orders_frame.grid(row=0, column=0, padx=(0, 10), pady=0, sticky="nsew")

        ctk.CTkLabel(
            recent_orders_frame,
            text="Recent Orders",
            font=("Segoe UI", 18, "bold"),
            text_color="#111827",
            anchor="w",
        ).grid(row=0, column=0, padx=18, pady=(18, 12), sticky="w")

        for row_number, item in enumerate([("#1024", "Espresso + Croissant", "₹ 420"), ("#1025", "Signature Latte", "₹ 360"), ("#1026", "Veg Sandwich Combo", "₹ 620")], start=1):
            row = ctk.CTkFrame(recent_orders_frame, fg_color="transparent")
            row.grid(row=row_number, column=0, padx=18, pady=6, sticky="ew")
            row.grid_columnconfigure(0, weight=2)
            row.grid_columnconfigure(1, weight=1)
            row.grid_columnconfigure(2, weight=1)
            ctk.CTkLabel(row, text=item[0], text_color="#475569", anchor="w").grid(row=0, column=0, sticky="w")
            ctk.CTkLabel(row, text=item[1], text_color="#0f172a", anchor="w").grid(row=0, column=1, sticky="w")
            ctk.CTkLabel(row, text=item[2], text_color="#0f172a", anchor="e").grid(row=0, column=2, sticky="e")

        alerts_frame = ctk.CTkFrame(
            content_row,
            corner_radius=16,
            fg_color="#ffffff",
            border_color="#dfeaf8",
            border_width=1,
        )
        alerts_frame.grid(row=0, column=1, padx=(10, 0), pady=0, sticky="nsew")
        alerts_frame.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            alerts_frame,
            text="Low Stock Alerts",
            font=("Segoe UI", 18, "bold"),
            text_color="#111827",
            anchor="w",
        ).grid(row=0, column=0, padx=18, pady=(18, 12), sticky="w")

        for row_number, item in enumerate([("Milk", "3 cartons left"), ("Tomato Sauce", "1 bottle left"), ("Coffee Beans", "5 kg left")], start=1):
            alert_row = ctk.CTkFrame(alerts_frame, fg_color="#fff5f5")
            alert_row.grid(row=row_number, column=0, padx=18, pady=6, sticky="ew")
            alert_row.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(alert_row, text=f"• {item[0]}", text_color="#b42318", anchor="w", font=("Segoe UI", 12, "bold")).grid(row=0, column=0, padx=12, pady=8, sticky="w")
            ctk.CTkLabel(alert_row, text=item[1], text_color="#7a2e0e", anchor="e").grid(row=0, column=1, padx=12, pady=8, sticky="e")

    def dismiss_onboarding_checklist(self):
        if session.current_cafe_id:
            set_onboarding_dismissed(session.current_cafe_id, True)
        if self.onboarding_frame is not None:
            self.onboarding_frame.grid_remove()
    """Café owner dashboard with current café information."""

    def __init__(self, master, app):
        super().__init__(master, corner_radius=0, fg_color="#f4f7fb")
        self.app = app
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=0)
        self.grid_rowconfigure(1, weight=0)
        self.grid_rowconfigure(2, weight=1)
        self.grid_rowconfigure(3, weight=0)

        cafe = app.get_current_cafe_data()
        cafe_name = cafe["cafe_name"] if cafe else "Café"
        location = cafe["location"] if cafe else "Location"

        header = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        header.grid(row=0, column=0, padx=28, pady=(22, 16), sticky="ew")
        header.grid_columnconfigure(0, weight=1)
        header.grid_columnconfigure(1, weight=0)

        ctk.CTkLabel(
            header,
            text=f"Welcome, {session.current_user_name}",
            font=("Segoe UI", 22, "bold"),
            text_color="#111827",
            anchor="w",
        ).grid(row=0, column=0, padx=18, pady=(18, 6), sticky="w")

        ctk.CTkLabel(
            header,
            text=f"Business: {cafe_name}",
            font=("Segoe UI", 14, "bold"),
            text_color="#1d4f91",
            anchor="w",
        ).grid(row=1, column=0, padx=18, pady=(0, 6), sticky="w")

        ctk.CTkLabel(
            header,
            text=f"Location: {location}",
            font=("Segoe UI", 12),
            text_color="#475569",
            anchor="w",
        ).grid(row=2, column=0, padx=18, pady=(0, 18), sticky="w")

        current_cafe_chip = ctk.CTkLabel(
            header,
            text=f"Current Café: {cafe_name}",
            font=("Segoe UI", 11, "bold"),
            text_color="#0f172a",
            fg_color="#dfeaf8",
            corner_radius=10,
        )
        current_cafe_chip.grid(row=0, column=1, rowspan=3, padx=(0, 18), pady=18, sticky="e")

        setup_status = get_setup_status(session.current_cafe_id)
        quick_start_complete = bool(setup_status.get("quick_start_completed", False))
        optional_progress = int(setup_status.get("optional_setup_progress", 0) or 0)
        onboarding_dismissed = bool(setup_status.get("onboarding_dismissed", False))

        if not onboarding_dismissed:
            onboarding_frame = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
            onboarding_frame.grid(row=1, column=0, padx=28, pady=(0, 20), sticky="ew")
            onboarding_frame.grid_columnconfigure(0, weight=1)
            onboarding_frame.grid_columnconfigure(1, weight=0)

            if quick_start_complete:
                ctk.CTkLabel(onboarding_frame, text="Optional setup checklist", font=("Segoe UI", 16, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 8), sticky="w")
                ctk.CTkLabel(onboarding_frame, text=f"{optional_progress}% complete", text_color="#1d4f91", font=("Segoe UI", 12, "bold"), anchor="w").grid(row=1, column=0, padx=18, pady=(0, 10), sticky="w")
                remaining_tasks = [
                    ("Add ingredients", bool(get_inventory_for_cafe(session.current_cafe_id).empty is False), "Inventory"),
                    ("Configure recipes", bool(get_recipes_for_cafe(session.current_cafe_id).empty is False), "Recipes"),
                    ("Set opening stock", bool(setup_status.get("opening_stock_complete", False)), "Inventory"),
                    ("Add suppliers", bool(get_suppliers_for_cafe(session.current_cafe_id).empty is False), "Suppliers"),
                ]
                task_rows = []
                for label, complete, target in remaining_tasks:
                    if not complete:
                        task_rows.append((label, target))

                for index, (label, target) in enumerate(task_rows[:4], start=2):
                    row = ctk.CTkFrame(onboarding_frame, fg_color="#f8fafc")
                    row.grid(row=index, column=0, padx=18, pady=6, sticky="ew")
                    row.grid_columnconfigure(0, weight=1)
                    row.grid_columnconfigure(1, weight=0)
                    ctk.CTkLabel(row, text=label, text_color="#0f172a", anchor="w", font=("Segoe UI", 12, "bold")).grid(row=0, column=0, padx=12, pady=8, sticky="w")
                    ctk.CTkButton(row, text="Open", command=lambda page=target: self.app.show_page(page), height=28, width=80, corner_radius=8, fg_color="#e0ecff", hover_color="#d0e3ff", text_color="#0f172a").grid(row=0, column=1, padx=(0, 12), pady=8, sticky="e")

                if not task_rows:
                    ctk.CTkLabel(onboarding_frame, text="Everything recommended is already in place. You can keep serving and return to setup later.", text_color="#475569", anchor="w", justify="left", wraplength=800).grid(row=2, column=0, padx=18, pady=(0, 18), sticky="w")

                ctk.CTkButton(onboarding_frame, text="Continue Setup", command=lambda: self.app.show_page("Setup"), height=38, corner_radius=10, fg_color="#2563eb", hover_color="#1d4f91").grid(row=100, column=0, padx=18, pady=(10, 18), sticky="w")
                ctk.CTkButton(onboarding_frame, text="Dismiss", command=lambda: self.dismiss_onboarding_checklist(), height=36, corner_radius=10, fg_color="#f8fafc", hover_color="#eef2ff", text_color="#0f172a", border_width=1, border_color="#dfeaf8").grid(row=100, column=1, padx=(0, 18), pady=(10, 18), sticky="e")
            else:
                ctk.CTkLabel(onboarding_frame, text="Finish your quick start", font=("Segoe UI", 16, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 8), sticky="w")
                ctk.CTkLabel(onboarding_frame, text="Set up your basic café profile and add at least one menu item to unlock the dashboard.", text_color="#475569", anchor="w", wraplength=800).grid(row=1, column=0, padx=18, pady=(0, 12), sticky="w")
                ctk.CTkButton(onboarding_frame, text="Continue Setup", command=lambda: self.app.show_page("Setup"), height=38, corner_radius=10, fg_color="#2563eb", hover_color="#1d4f91").grid(row=2, column=0, padx=18, pady=(0, 18), sticky="w")
                ctk.CTkButton(onboarding_frame, text="Dismiss", command=lambda: self.dismiss_onboarding_checklist(), height=36, corner_radius=10, fg_color="#f8fafc", hover_color="#eef2ff", text_color="#0f172a", border_width=1, border_color="#dfeaf8").grid(row=2, column=1, padx=(0, 18), pady=(0, 18), sticky="e")

        checklist_frame = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        checklist_frame.grid(row=2 if not onboarding_dismissed else 1, column=0, padx=28, pady=(0, 20), sticky="ew")
        checklist_frame.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            checklist_frame,
            text="Recommended Setup",
            font=("Segoe UI", 16, "bold"),
            text_color="#111827",
            anchor="w",
        ).grid(row=0, column=0, padx=18, pady=(18, 10), sticky="w")

        checklist = [
            ("Café profile", bool(session.current_cafe_name), "Create your café profile"),
            ("Menu", bool(get_menu_for_cafe(session.current_cafe_id).empty is False), "Add your first menu items"),
            ("Ingredients", bool(get_inventory_for_cafe(session.current_cafe_id).empty is False), "Add ingredients and stock thresholds"),
            ("Recipes", bool(get_recipes_for_cafe(session.current_cafe_id).empty is False), "Define recipe ingredients"),
            ("Opening stock", bool(setup_status.get("opening_stock_complete", False)), "Set opening stock"),
            ("Suppliers", bool(get_suppliers_for_cafe(session.current_cafe_id).empty is False), "Add suppliers"),
        ]

        for row_index, (label, complete, helper) in enumerate(checklist, start=1):
            status_text = "Complete" if complete else "Recommended"
            badge_color = "#dcfce7" if complete else "#e0ecff"
            badge_text = "#166534" if complete else "#1d4f91"
            row = ctk.CTkFrame(checklist_frame, fg_color="#f8fafc")
            row.grid(row=row_index, column=0, padx=18, pady=6, sticky="ew")
            row.grid_columnconfigure(0, weight=1)
            row.grid_columnconfigure(1, weight=0)

            ctk.CTkLabel(row, text=f"{label}", text_color="#0f172a", anchor="w", font=("Segoe UI", 12, "bold")).grid(row=0, column=0, padx=12, pady=8, sticky="w")
            ctk.CTkLabel(row, text=status_text, text_color=badge_text, fg_color=badge_color, corner_radius=8, padx=8, pady=4, font=("Segoe UI", 10, "bold")).grid(row=0, column=1, padx=(0, 12), pady=8, sticky="e")

    def dismiss_onboarding_checklist(self):
        if session.current_cafe_id:
            set_onboarding_dismissed(session.current_cafe_id, True)
        for child in self.winfo_children():
            if hasattr(child, "grid_remove"):
                child.grid_remove()

        cards_frame = ctk.CTkFrame(self, corner_radius=18, fg_color="transparent")
        cards_frame.grid(row=2, column=0, padx=28, pady=(0, 20), sticky="ew")
        cards_frame.grid_columnconfigure((0, 1, 2, 3), weight=1)
        for col in range(4):
            cards_frame.grid_columnconfigure(col, weight=1, minsize=180)

        summary_cards = [
            ("Today's Sales", "₹ 18,540", "+12.4% vs yesterday"),
            ("Today's Orders", "128", "14 dine-in, 42 take-away"),
            ("Low Stock", "07", "3 critical items"),
            ("Waste", "12 kg", "Down 4.1% this week"),
        ]

        for idx, (title, value, subtitle) in enumerate(summary_cards):
            card = StatCard(cards_frame, title, value, subtitle)
            card.grid(row=0, column=idx, padx=10, pady=0, sticky="ew")

        content_row = ctk.CTkFrame(self, corner_radius=18, fg_color="transparent")
        content_row.grid(row=2, column=0, padx=28, pady=(0, 20), sticky="nsew")
        content_row.grid_columnconfigure(0, weight=2)
        content_row.grid_columnconfigure(1, weight=1)

        recent_orders_frame = ctk.CTkFrame(
            content_row,
            corner_radius=16,
            fg_color="#ffffff",
            border_color="#dfeaf8",
            border_width=1,
        )
        recent_orders_frame.grid(row=0, column=0, padx=(0, 10), pady=0, sticky="nsew")

        ctk.CTkLabel(
            recent_orders_frame,
            text="Recent Orders",
            font=("Segoe UI", 18, "bold"),
            text_color="#111827",
            anchor="w",
        ).grid(row=0, column=0, padx=18, pady=(18, 12), sticky="w")

        for row_index, item in enumerate([("#1024", "Espresso + Croissant", "₹ 420"), ("#1025", "Signature Latte", "₹ 360"), ("#1026", "Veg Sandwich Combo", "₹ 620")], start=1):
            row = ctk.CTkFrame(recent_orders_frame, fg_color="transparent")
            row.grid(row=row_index, column=0, padx=18, pady=6, sticky="ew")
            row.grid_columnconfigure(0, weight=2)
            row.grid_columnconfigure(1, weight=1)
            row.grid_columnconfigure(2, weight=1)
            ctk.CTkLabel(row, text=item[0], text_color="#475569", anchor="w").grid(row=0, column=0, sticky="w")
            ctk.CTkLabel(row, text=item[1], text_color="#0f172a", anchor="w").grid(row=0, column=1, sticky="w")
            ctk.CTkLabel(row, text=item[2], text_color="#0f172a", anchor="e").grid(row=0, column=2, sticky="e")

        alerts_frame = ctk.CTkFrame(
            content_row,
            corner_radius=16,
            fg_color="#ffffff",
            border_color="#dfeaf8",
            border_width=1,
        )
        alerts_frame.grid(row=0, column=1, padx=(10, 0), pady=0, sticky="nsew")
        alerts_frame.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            alerts_frame,
            text="Low Stock Alerts",
            font=("Segoe UI", 18, "bold"),
            text_color="#111827",
            anchor="w",
        ).grid(row=0, column=0, padx=18, pady=(18, 12), sticky="w")

        for row_index, item in enumerate([("Milk", "3 cartons left"), ("Tomato Sauce", "1 bottle left"), ("Coffee Beans", "5 kg left")], start=1):
            alert_row = ctk.CTkFrame(alerts_frame, fg_color="#fff5f5")
            alert_row.grid(row=row_index, column=0, padx=18, pady=6, sticky="ew")
            alert_row.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(alert_row, text=f"• {item[0]}", text_color="#b42318", anchor="w", font=("Segoe UI", 12, "bold")).grid(row=0, column=0, padx=12, pady=8, sticky="w")
            ctk.CTkLabel(alert_row, text=item[1], text_color="#7a2e0e", anchor="e").grid(row=0, column=1, padx=12, pady=8, sticky="e")


class PlatformAdminDashboard(ctk.CTkScrollableFrame):
    """Dashboard shown to the platform administrator."""

    def __init__(self, master, app):
        super().__init__(master, corner_radius=0, fg_color="#f4f7fb")
        self.app = app
        self.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            self,
            text="CaféSync Platform Administration",
            font=("Segoe UI", 24, "bold"),
            text_color="#111827",
            anchor="w",
        ).grid(row=0, column=0, padx=28, pady=(20, 12), sticky="w")

        summary = get_cafe_account_summary()
        cards_frame = ctk.CTkFrame(self, corner_radius=18, fg_color="transparent")
        cards_frame.grid(row=1, column=0, padx=28, pady=(0, 20), sticky="ew")
        cards_frame.grid_columnconfigure((0, 1, 2, 3), weight=1)

        for idx, (title, value, subtitle) in enumerate([
            ("Total Cafés", str(summary["total_cafes"]), "All registered business accounts"),
            ("Active", str(summary["active"]), "Live / enabled café accounts"),
            ("Inactive", str(summary["inactive"]), "Paused or disabled accounts"),
            ("Setup Pending", str(summary["setup_incomplete"]), "Accounts needing completion"),
        ]):
            card = StatCard(cards_frame, title, value, subtitle)
            card.grid(row=0, column=idx, padx=10, pady=0, sticky="ew")

        admin_content = ctk.CTkFrame(self, fg_color="transparent")
        admin_content.grid(row=2, column=0, padx=28, pady=(0, 20), sticky="nsew")
        admin_content.grid_columnconfigure(0, weight=1)
        admin_content.grid_columnconfigure(1, weight=1)

        cafe_accounts_frame = ctk.CTkFrame(admin_content, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        cafe_accounts_frame.grid(row=0, column=0, padx=(0, 10), sticky="nsew")
        ctk.CTkLabel(cafe_accounts_frame, text="Café Accounts", font=("Segoe UI", 18, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 12), sticky="w")

        cafes = list_cafe_accounts()
        if not cafes:
            ctk.CTkLabel(cafe_accounts_frame, text="No café accounts registered yet.", text_color="#475569", anchor="w").grid(row=1, column=0, padx=18, pady=(0, 18), sticky="w")
        else:
            for row_index, cafe in enumerate(cafes[:6]):
                row = ctk.CTkFrame(cafe_accounts_frame, fg_color="#f8fafc")
                row.grid(row=row_index + 1, column=0, padx=18, pady=6, sticky="ew")
                row.grid_columnconfigure(0, weight=2)
                row.grid_columnconfigure(1, weight=1)
                row.grid_columnconfigure(2, weight=1)
                ctk.CTkLabel(row, text=f"{cafe['cafe_name']}", text_color="#0f172a", anchor="w").grid(row=0, column=0, padx=12, pady=8, sticky="w")
                ctk.CTkLabel(row, text=f"{cafe['status']}", text_color="#1d4f91", anchor="w").grid(row=0, column=1, padx=12, pady=8, sticky="w")
                ctk.CTkLabel(row, text=f"Owner: {cafe['owner_name']}", text_color="#475569", anchor="w").grid(row=0, column=2, padx=12, pady=8, sticky="w")

        activity_frame = ctk.CTkFrame(admin_content, corner_radius=18, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        activity_frame.grid(row=0, column=1, padx=(10, 0), sticky="nsew")
        ctk.CTkLabel(activity_frame, text="Platform Activity", font=("Segoe UI", 18, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=18, pady=(18, 12), sticky="w")
        ctk.CTkLabel(activity_frame, text="- Platform admin can view the tenant lifecycle\n- Café owners are restricted to their own workspace\n- Account deactivation preserves all café data\n- Future admin activity logs will extend this panel", text_color="#475569", justify="left").grid(row=1, column=0, padx=18, pady=(0, 18), sticky="w")


class CafeAccountsPage(ctk.CTkScrollableFrame):
    """Platform admin café account management workspace."""

    def __init__(self, master, app):
        super().__init__(master, corner_radius=0, fg_color="#f4f7fb")
        self.app = app
        self.grid_columnconfigure(0, weight=1)

        self.search_string = ctk.StringVar(value="")
        self.status_filter = ctk.StringVar(value="All")
        self.setup_filter = ctk.StringVar(value="All")
        self.sort_filter = ctk.StringVar(value="Newest")

        self.header = ctk.CTkFrame(self, fg_color="transparent")
        self.header.grid(row=0, column=0, padx=28, pady=(20, 12), sticky="ew")
        self.header.grid_columnconfigure(0, weight=1)
        self.header.grid_columnconfigure(1, weight=0)

        ctk.CTkLabel(
            self.header,
            text="Café Accounts",
            font=("Segoe UI", 24, "bold"),
            text_color="#111827",
            anchor="w",
        ).grid(row=0, column=0, sticky="w")
        ctk.CTkLabel(
            self.header,
            text="Manage businesses registered on the CaféSync platform.",
            font=("Segoe UI", 12),
            text_color="#475569",
            anchor="w",
        ).grid(row=1, column=0, sticky="w")

        ctk.CTkButton(
            self.header,
            text="+ Add Café",
            command=self._add_cafe_placeholder,
            height=38,
            corner_radius=10,
            fg_color="#2563eb",
            hover_color="#1d4f91",
        ).grid(row=0, column=1, rowspan=2, padx=(12, 0), sticky="e")

        self.summary_panel = ctk.CTkFrame(self, corner_radius=18, fg_color="transparent")
        self.summary_panel.grid(row=1, column=0, padx=28, pady=(0, 16), sticky="ew")
        self.summary_panel.grid_columnconfigure((0, 1, 2, 3), weight=1)

        self.summary_cards = []
        self._render_summary_cards()

        toolbar = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
        toolbar.grid(row=2, column=0, padx=28, pady=(0, 14), sticky="ew")
        toolbar.grid_columnconfigure(0, weight=2)
        toolbar.grid_columnconfigure(1, weight=1)
        toolbar.grid_columnconfigure(2, weight=1)
        toolbar.grid_columnconfigure(3, weight=1)

        search_entry = ctk.CTkEntry(
            toolbar,
            textvariable=self.search_string,
            placeholder_text="🔍 Search cafés...",
            height=38,
        )
        search_entry.grid(row=0, column=0, padx=16, pady=16, sticky="ew")
        search_entry.bind("<KeyRelease>", lambda event: self.refresh_list())

        status_menu = ctk.CTkOptionMenu(toolbar, values=["All", "Active", "Inactive"], variable=self.status_filter, command=lambda value: self.refresh_list())
        status_menu.grid(row=0, column=1, padx=(0, 10), pady=16, sticky="ew")

        setup_menu = ctk.CTkOptionMenu(toolbar, values=["All", "Complete", "Incomplete"], variable=self.setup_filter, command=lambda value: self.refresh_list())
        setup_menu.grid(row=0, column=2, padx=(0, 10), pady=16, sticky="ew")

        sort_menu = ctk.CTkOptionMenu(toolbar, values=["Newest", "Oldest", "Name A-Z", "Name Z-A"], variable=self.sort_filter, command=lambda value: self.refresh_list())
        sort_menu.grid(row=0, column=3, pady=16, sticky="ew")

        self.listing_section = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
        self.listing_section.grid(row=3, column=0, padx=28, pady=(0, 28), sticky="nsew")
        self.listing_section.grid_columnconfigure(0, weight=1)

        self.notice_label = ctk.CTkLabel(self.listing_section, text="", text_color="#197C3B", anchor="w")
        self.notice_label.grid(row=0, column=0, padx=18, pady=(14, 0), sticky="w")

        self.detail_panel = None
        self.refresh_list()

    def _add_cafe_placeholder(self):
        self.notice_label.configure(text="Admin-created cafés are not enabled in this prototype.")

    def _render_summary_cards(self):
        for widget in self.summary_cards:
            widget.destroy()
        self.summary_cards.clear()

        summary = get_cafe_account_summary()
        cards = [
            ("Total Cafés", str(summary["total_cafes"])),
            ("Active", str(summary["active"])),
            ("Inactive", str(summary["inactive"])),
            ("Setup Incomplete", str(summary["setup_incomplete"])),
        ]
        for idx, (title, value) in enumerate(cards):
            card = ctk.CTkFrame(self.summary_panel, corner_radius=16, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
            card.grid(row=0, column=idx, padx=10, pady=0, sticky="ew")
            card.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(card, text=title, text_color="#5a6475", font=("Segoe UI", 12)).grid(row=0, column=0, padx=16, pady=(16, 0), sticky="w")
            ctk.CTkLabel(card, text=value, text_color="#0f172a", font=("Segoe UI", 25, "bold")).grid(row=1, column=0, padx=16, pady=(10, 18), sticky="w")
            self.summary_cards.append(card)

    def refresh_list(self):
        for child in self.listing_section.winfo_children():
            if child is not self.notice_label:
                child.destroy()

        self.notice_label.configure(text="")
        self._render_summary_cards()

        rows = list_cafe_accounts(
            search=self.search_string.get(),
            status_filter=self.status_filter.get(),
            setup_filter=self.setup_filter.get(),
            sort_order=self.sort_filter.get(),
        )

        if not rows:
            empty_label = ctk.CTkLabel(
                self.listing_section,
                text="No cafés found.\nTry a different café name, owner, or email.",
                text_color="#475569",
                justify="left",
                height=80,
            )
            empty_label.grid(row=1, column=0, padx=18, pady=22, sticky="w")
            return

        header = ctk.CTkFrame(self.listing_section, fg_color="#f8fafc")
        header.grid(row=1, column=0, padx=18, pady=(14, 8), sticky="ew")
        header.grid_columnconfigure((0, 1, 2, 3, 4, 5), weight=1)

        for col_index, title in enumerate(["Café", "Owner", "Status", "Setup", "Joined", "Actions"]):
            ctk.CTkLabel(header, text=title, text_color="#475569", font=("Segoe UI", 11, "bold"), anchor="w").grid(row=0, column=col_index, padx=12, pady=10, sticky="w")

        for index, cafe in enumerate(rows, start=2):
            row = ctk.CTkFrame(self.listing_section, fg_color="transparent", border_width=1, border_color="#e2e8f0")
            row.grid(row=index, column=0, padx=18, pady=8, sticky="ew")
            row.grid_columnconfigure((0, 1, 2, 3, 4, 5), weight=1)

            cafe_name = ctk.CTkLabel(row, text=cafe["cafe_name"], font=("Segoe UI", 13, "bold"), text_color="#0f172a", anchor="w")
            cafe_name.grid(row=0, column=0, padx=12, pady=14, sticky="w")

            owner_name = ctk.CTkLabel(row, text=f"{cafe['owner_name']}\n{cafe['owner_id']}", text_color="#475569", justify="left", anchor="w")
            owner_name.grid(row=0, column=1, padx=12, pady=14, sticky="w")

            status_color = "#16a34a" if cafe["status"] == "Active" else "#ef4444"
            status_label = ctk.CTkLabel(row, text=f"● {cafe['status']}", text_color=status_color, font=("Segoe UI", 12, "bold"), anchor="w")
            status_label.grid(row=0, column=2, padx=12, pady=14, sticky="w")

            setup_text = ctk.CTkLabel(row, text=f"{cafe['setup_progress']}%", text_color="#1d4f91", font=("Segoe UI", 12, "bold"), anchor="w")
            setup_text.grid(row=0, column=3, padx=12, pady=14, sticky="w")

            ctk.CTkLabel(row, text=cafe["created_at"] or "—", text_color="#475569", anchor="w").grid(row=0, column=4, padx=12, pady=14, sticky="w")

            button = ctk.CTkButton(
                row,
                text="View",
                command=lambda cafe_id=cafe["cafe_id"]: self.show_detail(cafe_id),
                width=80,
                height=32,
                corner_radius=8,
                fg_color="#e0ecff",
                hover_color="#d0e3ff",
                text_color="#0f172a",
            )
            button.grid(row=0, column=5, padx=12, pady=14, sticky="e")

        self.detail_panel = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
        self.detail_panel.grid(row=4, column=0, padx=28, pady=(0, 28), sticky="nsew")
        self.detail_panel.grid_columnconfigure(0, weight=1)
        self.detail_panel.grid_remove()

    def show_detail(self, cafe_id):
        detail = get_cafe_account_detail(cafe_id)
        if not detail:
            self.notice_label.configure(text="Café account details could not be loaded.")
            return

        if self.detail_panel is None:
            self.detail_panel = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
            self.detail_panel.grid(row=4, column=0, padx=28, pady=(0, 28), sticky="nsew")
            self.detail_panel.grid_columnconfigure(0, weight=1)

        for child in self.detail_panel.winfo_children():
            child.destroy()

        self.detail_panel.grid()
        title = ctk.CTkLabel(self.detail_panel, text=detail["cafe_name"], font=("Segoe UI", 22, "bold"), text_color="#111827", anchor="w")
        title.grid(row=0, column=0, padx=22, pady=(18, 4), sticky="w")

        status_label = ctk.CTkLabel(self.detail_panel, text=f"Status: ● {detail['status']}", text_color="#16a34a" if detail["status"] == "Active" else "#ef4444", font=("Segoe UI", 13, "bold"), anchor="w")
        status_label.grid(row=1, column=0, padx=22, pady=(0, 12), sticky="w")

        details = ctk.CTkFrame(self.detail_panel, fg_color="#f8fafc")
        details.grid(row=2, column=0, padx=22, pady=(0, 20), sticky="ew")
        details.grid_columnconfigure((0, 1), weight=1)

        fields = [
            ("Café ID", detail["cafe_id"]),
            ("Owner", detail["owner_name"]),
            ("Owner ID", detail["owner_id"]),
            ("Owner Email", detail["owner_email"] or "Not available"),
            ("Created", detail["created_at"] or "Unknown"),
            ("Last Activity", "No platform activity recorded yet."),
        ]

        for idx, (label, value) in enumerate(fields):
            ctk.CTkLabel(details, text=f"{label}:", text_color="#64748b", font=("Segoe UI", 11, "bold"), anchor="w").grid(row=idx, column=0, padx=16, pady=8, sticky="w")
            ctk.CTkLabel(details, text=str(value), text_color="#0f172a", anchor="w").grid(row=idx, column=1, padx=16, pady=8, sticky="w")

        setup_container = ctk.CTkFrame(self.detail_panel, fg_color="#f8fafc")
        setup_container.grid(row=3, column=0, padx=22, pady=(0, 18), sticky="ew")
        setup_container.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(setup_container, text="SETUP STATUS", font=("Segoe UI", 12, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=16, pady=(16, 8), sticky="w")
        progress = detail["setup_progress"]
        progress_bar = ctk.CTkProgressBar(setup_container, width=300, height=16)
        progress_bar.set(progress / 100)
        progress_bar.grid(row=1, column=0, padx=16, pady=(0, 8), sticky="w")
        ctk.CTkLabel(setup_container, text=f"{progress}%", text_color="#1d4f91", font=("Segoe UI", 12, "bold")).grid(row=1, column=1, padx=(8, 16), pady=(0, 8), sticky="w")

        checklist = [
            ("Café Profile", detail["profile_complete"]),
            ("Menu", detail["menu_complete"]),
            ("Ingredients", detail["ingredients_complete"]),
            ("Recipes", detail["recipes_complete"]),
            ("Opening Stock", detail["opening_stock_complete"]),
            ("Suppliers", detail["suppliers_complete"]),
        ]
        for index, (label, complete) in enumerate(checklist, start=2):
            marker = "✓" if complete else "○"
            ctk.CTkLabel(setup_container, text=f"{marker} {label}", text_color="#0f172a", anchor="w").grid(row=index, column=0, padx=16, pady=6, sticky="w")

        actions_row = ctk.CTkFrame(self.detail_panel, fg_color="transparent")
        actions_row.grid(row=4, column=0, padx=22, pady=(0, 22), sticky="w")

        action_label = "Deactivate Café" if detail["status"] == "Active" else "Reactivate"
        action_command = self.deactivate_cafe if detail["status"] == "Active" else self.reactivate_cafe
        ctk.CTkButton(
            actions_row,
            text=action_label,
            command=lambda: action_command(cafe_id),
            height=38,
            corner_radius=10,
            fg_color="#ef4444" if detail["status"] == "Active" else "#16a34a",
            hover_color="#dc2626" if detail["status"] == "Active" else "#15803d",
        ).grid(row=0, column=0, padx=0, sticky="w")

    def deactivate_cafe(self, cafe_id):
        try:
            from tkinter import messagebox
            message = f"Deactivate {get_cafe_account_detail(cafe_id)['cafe_name']}?\n\nThe café owner will no longer be able to access this café. Existing café data will be preserved."
            if not messagebox.askyesno("Deactivate Café", message):
                return
            result = deactivate_cafe_account(cafe_id, session.current_user_id, session.current_user_name or "Platform Admin")
            if result["success"]:
                self.notice_label.configure(text=result["message"])
                self.refresh_list()
                self.show_detail(cafe_id)
            else:
                self.notice_label.configure(text=result["message"])
            if result["success"]:
                detail = get_cafe_account_detail(cafe_id)
                if detail:
                    record_platform_activity(
                        actor_id=session.current_user_id,
                        actor_name=session.current_user_name or "Platform Admin",
                        actor_role=session.current_user_role or "platform_admin",
                        action="DEACTIVATE_CAFE",
                        target_type="CAFE",
                        target_id=detail.get("cafe_id", cafe_id),
                        target_name=detail.get("cafe_name", "Unknown Café"),
                        status="SUCCESS",
                        details="Café account deactivated by Platform Admin.",
                    )
            else:
                record_platform_activity(
                    actor_id=session.current_user_id,
                    actor_name=session.current_user_name or "Platform Admin",
                    actor_role=session.current_user_role or "platform_admin",
                    action="DEACTIVATE_CAFE",
                    target_type="CAFE",
                    target_id=cafe_id,
                    target_name=get_cafe_account_detail(cafe_id).get("cafe_name", "Unknown Café") if get_cafe_account_detail(cafe_id) else "Unknown Café",
                    status="FAILED",
                    details=result.get("message", "Unable to save café status."),
                )
        except Exception:
            self.notice_label.configure(text="Unable to deactivate this café account right now.")

    def reactivate_cafe(self, cafe_id):
        try:
            from tkinter import messagebox
            detail = get_cafe_account_detail(cafe_id)
            if not detail:
                self.notice_label.configure(text="Café account not found.")
                return
            if not messagebox.askyesno("Reactivate Café", f"Reactivate this café account?\n\nThis will restore owner access while preserving the café data."):
                return
            result = reactivate_cafe_account(cafe_id, session.current_user_id, session.current_user_name or "Platform Admin")
            if result["success"]:
                self.notice_label.configure(text=result["message"])
                self.refresh_list()
                self.show_detail(cafe_id)
            else:
                self.notice_label.configure(text=result["message"])
            if result["success"]:
                detail = get_cafe_account_detail(cafe_id)
                if detail:
                    record_platform_activity(
                        actor_id=session.current_user_id,
                        actor_name=session.current_user_name or "Platform Admin",
                        actor_role=session.current_user_role or "platform_admin",
                        action="REACTIVATE_CAFE",
                        target_type="CAFE",
                        target_id=detail.get("cafe_id", cafe_id),
                        target_name=detail.get("cafe_name", "Unknown Café"),
                        status="SUCCESS",
                        details="Café account reactivated by Platform Admin.",
                    )
            else:
                record_platform_activity(
                    actor_id=session.current_user_id,
                    actor_name=session.current_user_name or "Platform Admin",
                    actor_role=session.current_user_role or "platform_admin",
                    action="REACTIVATE_CAFE",
                    target_type="CAFE",
                    target_id=cafe_id,
                    target_name=get_cafe_account_detail(cafe_id).get("cafe_name", "Unknown Café") if get_cafe_account_detail(cafe_id) else "Unknown Café",
                    status="FAILED",
                    details=result.get("message", "Unable to restore café access."),
                )
        except Exception:
            self.notice_label.configure(text="Unable to reactivate this café account right now.")


class CafeOwnersPage(ctk.CTkScrollableFrame):
    """Platform admin owner management workspace."""

    def __init__(self, master, app):
        super().__init__(master, corner_radius=0, fg_color="#f4f7fb")
        self.app = app
        self.grid_columnconfigure(0, weight=1)

        self.search_string = ctk.StringVar(value="")
        self.owner_status = ctk.StringVar(value="All")
        self.cafe_status = ctk.StringVar(value="All")

        self.header = ctk.CTkFrame(self, fg_color="transparent")
        self.header.grid(row=0, column=0, padx=28, pady=(20, 12), sticky="ew")
        self.header.grid_columnconfigure(0, weight=1)
        self.header.grid_columnconfigure(1, weight=0)

        ctk.CTkLabel(
            self.header,
            text="Café Owners",
            font=("Segoe UI", 24, "bold"),
            text_color="#111827",
            anchor="w",
        ).grid(row=0, column=0, sticky="w")
        ctk.CTkLabel(
            self.header,
            text="Review ownership, café assignment, and access status across the platform.",
            font=("Segoe UI", 12),
            text_color="#475569",
            anchor="w",
        ).grid(row=1, column=0, sticky="w")

        self.summary_panel = ctk.CTkFrame(self, corner_radius=18, fg_color="transparent")
        self.summary_panel.grid(row=1, column=0, padx=28, pady=(0, 16), sticky="ew")
        self.summary_panel.grid_columnconfigure((0, 1, 2, 3), weight=1)

        self.summary_cards = []
        self._render_summary_cards()

        toolbar = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
        toolbar.grid(row=2, column=0, padx=28, pady=(0, 14), sticky="ew")
        toolbar.grid_columnconfigure(0, weight=2)
        toolbar.grid_columnconfigure(1, weight=1)
        toolbar.grid_columnconfigure(2, weight=1)

        search_entry = ctk.CTkEntry(toolbar, textvariable=self.search_string, placeholder_text="🔍 Search owner or café...", height=38)
        search_entry.grid(row=0, column=0, padx=16, pady=16, sticky="ew")
        search_entry.bind("<KeyRelease>", lambda event: self.refresh_list())

        owner_menu = ctk.CTkOptionMenu(toolbar, values=["All", "Active", "Inactive"], variable=self.owner_status, command=lambda value: self.refresh_list())
        owner_menu.grid(row=0, column=1, padx=(0, 10), pady=16, sticky="ew")

        cafe_menu = ctk.CTkOptionMenu(toolbar, values=["All", "Active Café", "Inactive Café"], variable=self.cafe_status, command=lambda value: self.refresh_list())
        cafe_menu.grid(row=0, column=2, pady=16, sticky="ew")

        self.listing_section = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
        self.listing_section.grid(row=3, column=0, padx=28, pady=(0, 28), sticky="nsew")
        self.listing_section.grid_columnconfigure(0, weight=1)

        self.notice_label = ctk.CTkLabel(self.listing_section, text="", text_color="#197C3B", anchor="w")
        self.notice_label.grid(row=0, column=0, padx=18, pady=(14, 0), sticky="w")

        self.detail_panel = None
        self.refresh_list()

    def _render_summary_cards(self):
        for widget in self.summary_cards:
            widget.destroy()
        self.summary_cards.clear()

        summary = get_owner_summary()
        cards = [
            ("Total Owners", str(summary["total_owners"])),
            ("Active Owners", str(summary["active_owners"])),
            ("Inactive Owners", str(summary["inactive_owners"])),
            ("Active Cafés", str(summary["owners_with_active_cafe"])),
        ]
        for idx, (title, value) in enumerate(cards):
            card = ctk.CTkFrame(self.summary_panel, corner_radius=16, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
            card.grid(row=0, column=idx, padx=10, sticky="ew")
            card.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(card, text=title, text_color="#5a6475", font=("Segoe UI", 12)).grid(row=0, column=0, padx=16, pady=(16, 0), sticky="w")
            ctk.CTkLabel(card, text=value, text_color="#0f172a", font=("Segoe UI", 25, "bold")).grid(row=1, column=0, padx=16, pady=(10, 18), sticky="w")
            self.summary_cards.append(card)

    def refresh_list(self):
        for child in self.listing_section.winfo_children():
            if child is not self.notice_label:
                child.destroy()

        self.notice_label.configure(text="")
        self._render_summary_cards()

        rows = list_owner_accounts(
            search=self.search_string.get(),
            owner_status=self.owner_status.get(),
            cafe_status=self.cafe_status.get(),
        )

        if not rows:
            empty_label = ctk.CTkLabel(
                self.listing_section,
                text="No café owners found.\nTry a different name, email, or café assignment.",
                text_color="#475569",
                justify="left",
                height=80,
            )
            empty_label.grid(row=1, column=0, padx=18, pady=22, sticky="w")
            return

        header = ctk.CTkFrame(self.listing_section, fg_color="#f8fafc")
        header.grid(row=1, column=0, padx=18, pady=(14, 8), sticky="ew")
        header.grid_columnconfigure((0, 1, 2, 3, 4, 5), weight=1)

        for col_index, title in enumerate(["Owner", "Café", "Owner Status", "Café Status", "Joined", "Actions"]):
            ctk.CTkLabel(header, text=title, text_color="#475569", font=("Segoe UI", 11, "bold"), anchor="w").grid(row=0, column=col_index, padx=12, pady=10, sticky="w")

        for index, owner in enumerate(rows, start=2):
            row = ctk.CTkFrame(self.listing_section, fg_color="transparent", border_width=1, border_color="#e2e8f0")
            row.grid(row=index, column=0, padx=18, pady=8, sticky="ew")
            row.grid_columnconfigure((0, 1, 2, 3, 4, 5), weight=1)

            owner_label = ctk.CTkLabel(row, text=f"{owner['name']}\n{owner['user_id']}", text_color="#0f172a", justify="left", anchor="w")
            owner_label.grid(row=0, column=0, padx=12, pady=14, sticky="w")

            cafe_label = ctk.CTkLabel(row, text=f"{owner['cafe_name']}\n{owner['cafe_id'] or 'No café assigned'}", text_color="#475569", justify="left", anchor="w")
            cafe_label.grid(row=0, column=1, padx=12, pady=14, sticky="w")

            owner_status_color = "#16a34a" if owner["status"] == "Active" else "#ef4444"
            ctk.CTkLabel(row, text=f"● {owner['status']}", text_color=owner_status_color, font=("Segoe UI", 12, "bold"), anchor="w").grid(row=0, column=2, padx=12, pady=14, sticky="w")

            cafe_status_color = "#16a34a" if owner["cafe_status"] == "Active" else "#ef4444"
            ctk.CTkLabel(row, text=f"● {owner['cafe_status']}", text_color=cafe_status_color, font=("Segoe UI", 12, "bold"), anchor="w").grid(row=0, column=3, padx=12, pady=14, sticky="w")
            ctk.CTkLabel(row, text=owner["created_at"] or "—", text_color="#475569", anchor="w").grid(row=0, column=4, padx=12, pady=14, sticky="w")

            action_button = ctk.CTkButton(
                row,
                text="View",
                command=lambda user_id=owner["user_id"]: self.show_detail(user_id),
                width=80,
                height=32,
                corner_radius=8,
                fg_color="#e0ecff",
                hover_color="#d0e3ff",
                text_color="#0f172a",
            )
            action_button.grid(row=0, column=5, padx=12, pady=14, sticky="e")

        self.detail_panel = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
        self.detail_panel.grid(row=4, column=0, padx=28, pady=(0, 28), sticky="nsew")
        self.detail_panel.grid_columnconfigure(0, weight=1)
        self.detail_panel.grid_remove()

    def show_detail(self, user_id):
        detail = get_owner_detail(user_id)
        if not detail:
            self.notice_label.configure(text="Owner details could not be loaded.")
            return

        if self.detail_panel is None:
            self.detail_panel = ctk.CTkFrame(self, corner_radius=18, fg_color="#ffffff", border_color="#dfeaf8", border_width=1)
            self.detail_panel.grid(row=4, column=0, padx=28, pady=(0, 28), sticky="nsew")
            self.detail_panel.grid_columnconfigure(0, weight=1)

        for child in self.detail_panel.winfo_children():
            child.destroy()

        self.detail_panel.grid()
        ctk.CTkLabel(self.detail_panel, text=detail["name"], font=("Segoe UI", 22, "bold"), text_color="#111827", anchor="w").grid(row=0, column=0, padx=22, pady=(18, 4), sticky="w")
        ctk.CTkLabel(self.detail_panel, text=f"Owner Status: ● {detail['status']}", text_color="#16a34a" if detail["status"] == "Active" else "#ef4444", font=("Segoe UI", 13, "bold"), anchor="w").grid(row=1, column=0, padx=22, pady=(0, 12), sticky="w")

        info_frame = ctk.CTkFrame(self.detail_panel, fg_color="#f8fafc")
        info_frame.grid(row=2, column=0, padx=22, pady=(0, 18), sticky="ew")
        info_frame.grid_columnconfigure((0, 1), weight=1)

        fields = [
            ("User ID", detail["user_id"]),
            ("Email", detail["email"]),
            ("Phone", detail["phone"] or "—"),
            ("Role", detail["role"]),
            ("Created", detail["created_at"] or "—"),
            ("Café", detail["cafe_name"]),
            ("Café ID", detail["cafe_id"] or "Not assigned"),
            ("Café Status", detail["cafe_status"]),
            ("Setup Progress", f"{detail['setup_progress']}%"),
            ("Location", detail["location"] or "Not available"),
        ]

        for idx, (label, value) in enumerate(fields):
            ctk.CTkLabel(info_frame, text=f"{label}:", text_color="#64748b", font=("Segoe UI", 11, "bold"), anchor="w").grid(row=idx, column=0, padx=16, pady=8, sticky="w")
            ctk.CTkLabel(info_frame, text=str(value), text_color="#0f172a", anchor="w").grid(row=idx, column=1, padx=16, pady=8, sticky="w")

        actions_row = ctk.CTkFrame(self.detail_panel, fg_color="transparent")
        actions_row.grid(row=3, column=0, padx=22, pady=(0, 22), sticky="w")

        action_label = "Deactivate Owner" if detail["status"] == "Active" else "Reactivate Owner"
        action_command = self.deactivate_owner if detail["status"] == "Active" else self.reactivate_owner
        ctk.CTkButton(
            actions_row,
            text=action_label,
            command=lambda: action_command(user_id),
            height=38,
            corner_radius=10,
            fg_color="#ef4444" if detail["status"] == "Active" else "#16a34a",
            hover_color="#dc2626" if detail["status"] == "Active" else "#15803d",
        ).grid(row=0, column=0, sticky="w")

    def deactivate_owner(self, user_id):
        try:
            from tkinter import messagebox
            detail = get_owner_detail(user_id)
            if not detail:
                self.notice_label.configure(text="Owner account not found.")
                return
            if not messagebox.askyesno("Deactivate Owner", f"Deactivate {detail['name']}?\n\nThis will revoke their account access and any café access tied to their profile."):
                return
            result = deactivate_owner_account(user_id, session.current_user_id, session.current_user_name or "Platform Admin")
            if result["success"]:
                self.notice_label.configure(text=result["message"])
                self.refresh_list()
                self.show_detail(user_id)
            else:
                self.notice_label.configure(text=result["message"])
        except Exception:
            self.notice_label.configure(text="Unable to deactivate this owner account right now.")

    def reactivate_owner(self, user_id):
        try:
            from tkinter import messagebox
            detail = get_owner_detail(user_id)
            if not detail:
                self.notice_label.configure(text="Owner account not found.")
                return
            if not messagebox.askyesno("Reactivate Owner", f"Reactivate {detail['name']}?\n\nThis will restore their platform access and café ownership."):
                return
            result = reactivate_owner_account(user_id, session.current_user_id, session.current_user_name or "Platform Admin")
            if result["success"]:
                self.notice_label.configure(text=result["message"])
                self.refresh_list()
                self.show_detail(user_id)
            else:
                self.notice_label.configure(text=result["message"])
        except Exception:
            self.notice_label.configure(text="Unable to reactivate this owner account right now.")


class LoginScreen(ctk.CTkFrame):
    """Authentication entry page for platform admin and café owners."""

    def __init__(self, master, app):
        super().__init__(master, corner_radius=0, fg_color="#edf3f9")
        self.app = app
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)

        panel = ctk.CTkFrame(self, width=520, corner_radius=24, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        panel.grid(row=0, column=0, padx=80, pady=50, sticky="nsew")
        panel.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(panel, text="CaféSync", font=("Segoe UI", 32, "bold"), text_color="#111827").grid(row=0, column=0, padx=24, pady=(28, 8), sticky="w")
        ctk.CTkLabel(panel, text="Café Management & Smart Inventory System", font=("Segoe UI", 14), text_color="#475569").grid(row=1, column=0, padx=24, pady=(0, 16), sticky="w")

        self.role_switch = ctk.CTkSegmentedButton(
            panel,
            values=["Platform Admin", "Café Owner"],
            command=self.app.on_login_mode_change,
            width=460,
        )
        self.role_switch.grid(row=2, column=0, padx=24, pady=(0, 20), sticky="ew")
        self.role_switch.set("Café Owner")

        self.email_entry = ctk.CTkEntry(panel, placeholder_text="Email address", width=460, height=42)
        self.email_entry.grid(row=3, column=0, padx=24, pady=(0, 12), sticky="ew")

        self.password_entry = ctk.CTkEntry(panel, placeholder_text="Password", show="*", width=460, height=42)
        self.password_entry.grid(row=4, column=0, padx=24, pady=(0, 18), sticky="ew")

        self.message_label = ctk.CTkLabel(panel, text="", text_color="#b42318", font=("Segoe UI", 12), wraplength=420)
        self.message_label.grid(row=5, column=0, padx=24, pady=(0, 10), sticky="w")

        self.login_button = ctk.CTkButton(panel, text="Login", command=self.app.handle_login, height=44, corner_radius=12, fg_color="#2563eb", hover_color="#1d4f91")
        self.login_button.grid(row=6, column=0, padx=24, pady=(0, 10), sticky="ew")

        self.create_account_button = ctk.CTkButton(panel, text="Create Café Account", command=self.app.show_registration, height=42, corner_radius=12, fg_color="#e0ecff", hover_color="#d0e3ff", text_color="#0f172a")
        self.create_account_button.grid(row=7, column=0, padx=24, pady=(0, 24), sticky="ew")

    def clear_message(self):
        self.message_label.configure(text="")


class RegistrationScreen(ctk.CTkFrame):
    """Café owner registration form."""

    def __init__(self, master, app):
        super().__init__(master, corner_radius=0, fg_color="#edf3f9")
        self.app = app
        self.grid_columnconfigure(0, weight=1)

        panel = ctk.CTkFrame(self, corner_radius=24, fg_color="#ffffff", border_width=1, border_color="#dfeaf8")
        panel.grid(row=0, column=0, padx=90, pady=32, sticky="nsew")
        panel.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(panel, text="Create Your CaféSync Account", font=("Segoe UI", 30, "bold"), text_color="#111827").grid(row=0, column=0, padx=24, pady=(24, 8), sticky="w")
        ctk.CTkLabel(panel, text="Register as a café owner and create your café profile automatically.", font=("Segoe UI", 14), text_color="#475569").grid(row=1, column=0, padx=24, pady=(0, 18), sticky="w")

        self.fields = {
            "owner_name": ctk.CTkEntry(panel, placeholder_text="Owner Name", width=500, height=42),
            "cafe_name": ctk.CTkEntry(panel, placeholder_text="Business / Café Name", width=500, height=42),
            "email": ctk.CTkEntry(panel, placeholder_text="Email", width=500, height=42),
            "phone": ctk.CTkEntry(panel, placeholder_text="Phone", width=500, height=42),
            "password": ctk.CTkEntry(panel, placeholder_text="Password", show="*", width=500, height=42),
            "confirm_password": ctk.CTkEntry(panel, placeholder_text="Confirm Password", show="*", width=500, height=42),
            "location": ctk.CTkEntry(panel, placeholder_text="Café Location", width=500, height=42),
        }

        for idx, field in enumerate(self.fields.values(), start=2):
            field.grid(row=idx, column=0, padx=24, pady=6, sticky="ew")

        self.message_label = ctk.CTkLabel(panel, text="", text_color="#b42318", font=("Segoe UI", 12), wraplength=500)
        self.message_label.grid(row=10, column=0, padx=24, pady=(12, 10), sticky="w")

        btn_row = ctk.CTkFrame(panel, fg_color="transparent")
        btn_row.grid(row=11, column=0, padx=24, pady=(0, 24), sticky="ew")
        btn_row.grid_columnconfigure(0, weight=1)
        btn_row.grid_columnconfigure(1, weight=1)

        ctk.CTkButton(btn_row, text="Create Account", command=self.app.handle_registration, height=44, corner_radius=12, fg_color="#2563eb", hover_color="#1d4f91").grid(row=0, column=0, padx=(0, 8), sticky="ew")
        ctk.CTkButton(btn_row, text="Back to Login", command=self.app.show_login, height=44, corner_radius=12, fg_color="#e0ecff", hover_color="#d0e3ff", text_color="#0f172a").grid(row=0, column=1, padx=(8, 0), sticky="ew")

    def clear_message(self):
        self.message_label.configure(text="")


class CafeSyncApp:
    """Main application shell with login, registration and role-based dashboards."""

    def __init__(self):
        ctk.set_default_color_theme("dark-blue")
        ctk.set_appearance_mode("System")

        self.root = ctk.CTk()
        self.root.title("CaféSync")
        self.root.geometry("1400x900")
        self.root.minsize(1100, 720)
        self.root.configure(fg_color="#edf3f9")
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(0, weight=0)
        self.root.grid_columnconfigure(1, weight=1)

        self.sidebar = None
        self.content_area = None
        self.nav_buttons = {}
        self.pages = {}

        self.login_screen = LoginScreen(self.root, self)
        self.login_screen.grid(row=0, column=0, columnspan=2, sticky="nsew")
        self.login_screen.grid_remove()

        self.registration_screen = RegistrationScreen(self.root, self)
        self.registration_screen.grid(row=0, column=0, columnspan=2, sticky="nsew")
        self.registration_screen.grid_remove()

        self.owner_dashboard = OwnerDashboardFrame(self.root, self)
        self.owner_dashboard.grid(row=0, column=0, columnspan=2, sticky="nsew")
        self.owner_dashboard.grid_remove()

        self.admin_dashboard = PlatformAdminDashboard(self.root, self)
        self.admin_dashboard.grid(row=0, column=0, columnspan=2, sticky="nsew")
        self.admin_dashboard.grid_remove()

        self.current_screen = None
        self.show_login()

    def on_login_mode_change(self, value):
        """Used for the segmented login switch."""
        self.login_screen.clear_message()

    def clear_sidebar(self):
        if self.sidebar is not None:
            self.sidebar.grid_remove()
            self.sidebar.destroy()
            self.sidebar = None

        if self.content_area is not None:
            self.content_area.grid_remove()
            self.content_area.destroy()
            self.content_area = None

        self.nav_buttons = {}
        self.pages = {}

    def build_owner_shell(self):
        """Build the owner dashboard shell with Phase 1 navigation and current café context."""
        self.clear_sidebar()

        self.sidebar = ctk.CTkFrame(self.root, width=260, corner_radius=0, fg_color="#111827")
        self.sidebar.grid_propagate(False)
        self.sidebar.grid(row=0, column=0, sticky="ns")
        self.sidebar.grid_rowconfigure(12, weight=1)

        ctk.CTkLabel(
            self.sidebar,
            text="CaféSync",
            font=("Segoe UI", 28, "bold"),
            text_color="#ffffff",
            anchor="w",
        ).grid(row=0, column=0, padx=22, pady=(22, 6), sticky="w")

        cafe_info = self.get_current_cafe_data()
        cafe_name = cafe_info["cafe_name"] if cafe_info else "Current Café"
        ctk.CTkLabel(
            self.sidebar,
            text=f"Current Café: {cafe_name}",
            font=("Segoe UI", 11, "bold"),
            text_color="#dfeaf8",
            anchor="w",
            wraplength=200,
        ).grid(row=1, column=0, padx=22, pady=(0, 12), sticky="w")

        nav_items = [
            "Dashboard",
            "Setup",
            "Orders",
            "Billing",
            "Menu",
            "Inventory",
            "Recipes",
            "Suppliers",
            "Purchases",
            "Waste",
            "Reports",
            "Account",
            "Logout",
        ]

        for index, page_name in enumerate(nav_items, start=2):
            button = SidebarButton(
                self.sidebar,
                text=page_name,
                command=lambda name=page_name: self.show_page(name),
            )
            button.grid(row=index, column=0, padx=14, pady=4, sticky="ew")
            self.nav_buttons[page_name] = button

        self.content_area = ctk.CTkFrame(self.root, corner_radius=0, fg_color="#f4f7fb")
        self.content_area.grid(row=0, column=1, sticky="nsew")
        self.content_area.grid_rowconfigure(0, weight=1)
        self.content_area.grid_columnconfigure(0, weight=1)

        self.pages = {
            "Dashboard": OwnerDashboardFrame(self.content_area, self),
            "Setup": SetupWizardFrame(self.content_area, self),
            "Orders": OrdersManagementPage(self.content_area, self),
            "Billing": BillingManagementPage(self.content_area, self),
            "Menu": MenuManagementPage(self.content_area, self),
            "Inventory": InventoryManagementPage(self.content_area, self),
            "Recipes": RecipeManagementPage(self.content_area, self),
            "Suppliers": SupplierDirectoryPage(self.content_area, self),
            "Purchases": PurchaseManagementPage(self.content_area, self),
            "Waste": WasteManagementPage(self.content_area, self),
            "Reports": ReportsPage(self.content_area, self),
            "Account": AccountManagementPage(self.content_area, self),
            "Logout": PlaceholderPage(self.content_area, "Logout"),
        }

        for page_name, page in self.pages.items():
            page.grid(row=0, column=0, sticky="nsew")
            if page_name != "Dashboard":
                page.grid_remove()

        default_page = "Dashboard"
        if session.current_cafe_id:
            status = get_setup_status(session.current_cafe_id)
            if not bool(status.get("quick_start_completed", False)):
                default_page = "Setup"
        self.show_page(default_page)

    def build_admin_shell(self):
        """Build a platform admin dashboard separate from café owner navigation."""
        self.clear_sidebar()

        self.sidebar = ctk.CTkFrame(self.root, width=260, corner_radius=0, fg_color="#111827")
        self.sidebar.grid_propagate(False)
        self.sidebar.grid(row=0, column=0, sticky="ns")
        self.sidebar.grid_rowconfigure(12, weight=1)

        ctk.CTkLabel(
            self.sidebar,
            text="CaféSync",
            font=("Segoe UI", 28, "bold"),
            text_color="#ffffff",
            anchor="w",
        ).grid(row=0, column=0, padx=22, pady=(22, 6), sticky="w")
        ctk.CTkLabel(
            self.sidebar,
            text="Platform Administration",
            font=("Segoe UI", 11, "normal"),
            text_color="#c1d7ff",
            wraplength=200,
        ).grid(row=1, column=0, padx=22, pady=(0, 18), sticky="w")

        nav_items = ["Dashboard", "Café Accounts", "Café Owners", "Platform Activity", "Settings", "Logout"]
        for index, page_name in enumerate(nav_items, start=2):
            button = SidebarButton(
                self.sidebar,
                text=page_name,
                command=lambda name=page_name: self.show_page(name),
            )
            button.grid(row=index, column=0, padx=14, pady=4, sticky="ew")
            self.nav_buttons[page_name] = button

        self.content_area = ctk.CTkFrame(self.root, corner_radius=0, fg_color="#f4f7fb")
        self.content_area.grid(row=0, column=1, sticky="nsew")
        self.content_area.grid_rowconfigure(0, weight=1)
        self.content_area.grid_columnconfigure(0, weight=1)

        self.pages = {
            "Dashboard": PlatformAdminDashboard(self.content_area, self),
            "Café Accounts": CafeAccountsPage(self.content_area, self),
            "Café Owners": CafeOwnersPage(self.content_area, self),
            "Platform Activity": PlatformActivityPage(self.content_area, self),
            "Settings": PlaceholderPage(self.content_area, "Settings"),
            "Logout": PlaceholderPage(self.content_area, "Logout"),
        }

        for name, page in self.pages.items():
            page.grid(row=0, column=0, sticky="nsew")
            if name != "Dashboard":
                page.grid_remove()

        self.show_page("Dashboard")

    def get_current_cafe_data(self):
        if session.current_cafe_id is None:
            return None
        cafe_dataframe = get_cafes_for_owner(session.current_user_id)
        if cafe_dataframe.empty:
            return None
        selected = cafe_dataframe[cafe_dataframe["cafe_id"].astype(str) == str(session.current_cafe_id)]
        if selected.empty:
            return None
        return selected.iloc[0].to_dict()

    def show_login(self):
        self.clear_sidebar()
        self.login_screen.grid()
        self.registration_screen.grid_remove()
        self.owner_dashboard.grid_remove()
        self.admin_dashboard.grid_remove()
        self.current_screen = "login"

    def show_registration(self):
        self.login_screen.grid_remove()
        self.registration_screen.grid()
        self.registration_screen.clear_message()
        self.current_screen = "registration"

    def show_page(self, name: str):
        if name == "Logout":
            self.logout()
            return

        if self.sidebar is None:
            return

        if name in {"Café Accounts", "Café Owners", "Platform Activity"}:
            if name == "Café Accounts" and not can_access_cafe_accounts(session.current_user_role):
                self.show_page("Dashboard")
                return
            if name == "Café Owners" and not can_access_cafe_owners(session.current_user_role):
                self.show_page("Dashboard")
                return
            if name == "Platform Activity" and not has_platform_activity_access(session.current_user_role):
                self.show_page("Dashboard")
                return

        for page_name, page in self.pages.items():
            if page_name == name:
                page.grid()
            else:
                page.grid_remove()

        for button_name, button in self.nav_buttons.items():
            button.set_selected(button_name == name)

    def handle_login(self):
        email = self.login_screen.email_entry.get().strip()
        password = self.login_screen.password_entry.get().strip()

        if not email or not password:
            self.login_screen.message_label.configure(text="Email and password are required.")
            return

        result = authenticate_user(email, password)
        if result is None:
            self.login_screen.message_label.configure(text="Invalid email or password.")
            return

        status_value = str(result.get("status", "inactive")).strip().lower()
        if status_value == "inactive":
            self.login_screen.message_label.configure(text="Your CaféSync account is currently inactive. Please contact the platform administrator.")
            return

        if result["role"] == "platform_admin":
            from modules.session import session
            session.login_session(result["user_id"], result["name"], result["role"])
            record_platform_activity(
                actor_id=result["user_id"],
                actor_name=result["name"],
                actor_role=result["role"],
                action="ADMIN_LOGIN",
                target_type="SYSTEM",
                target_id="PLATFORM",
                target_name="CaféSync Platform",
                status="SUCCESS",
                details="Platform Admin logged in successfully.",
            )
            self.login_screen.email_entry.delete(0, "end")
            self.login_screen.password_entry.delete(0, "end")
            self.login_screen.grid_remove()
            self.build_admin_shell()
            return

        if result["role"] == "cafe_owner":
            from modules.cafe_manager import get_cafes_for_owner
            owned_cafes = get_cafes_for_owner(result["user_id"])
            if owned_cafes.empty:
                self.login_screen.message_label.configure(text="No active café is associated with this owner.")
                return

            cafe = owned_cafes.iloc[0].to_dict()
            if str(cafe.get("status", "Inactive")).strip().lower() == "inactive":
                self.login_screen.message_label.configure(text="Your CaféSync account is currently inactive. Please contact the platform administrator.")
                return

            from modules.session import session
            session.login_session(result["user_id"], result["name"], result["role"], cafe["cafe_id"], cafe["cafe_name"])
            self.login_screen.email_entry.delete(0, "end")
            self.login_screen.password_entry.delete(0, "end")
            self.login_screen.grid_remove()
            self.build_owner_shell()
            return

        self.login_screen.message_label.configure(text="Access type not supported in this phase.")

    def handle_registration(self):
        owner_name = self.registration_screen.fields["owner_name"].get().strip()
        cafe_name = self.registration_screen.fields["cafe_name"].get().strip()
        email = self.registration_screen.fields["email"].get().strip()
        phone = self.registration_screen.fields["phone"].get().strip()
        password = self.registration_screen.fields["password"].get().strip()
        confirm_password = self.registration_screen.fields["confirm_password"].get().strip()
        location = self.registration_screen.fields["location"].get().strip()

        if not owner_name:
            self.registration_screen.message_label.configure(text="Please enter the owner name.")
            return
        if not cafe_name:
            self.registration_screen.message_label.configure(text="Please enter the café name.")
            return
        if not email:
            self.registration_screen.message_label.configure(text="Please enter your email address.")
            return
        if not phone:
            self.registration_screen.message_label.configure(text="Please enter your phone number.")
            return
        if not password:
            self.registration_screen.message_label.configure(text="Please enter a password.")
            return
        if not location:
            self.registration_screen.message_label.configure(text="Please enter the café location.")
            return

        if "@" not in email or "." not in email:
            self.registration_screen.message_label.configure(text="Please enter a valid email address.")
            return

        if len(phone.replace(" ", "").replace("-", "")) < 10:
            self.registration_screen.message_label.configure(text="Please enter a valid phone number.")
            return

        if password != confirm_password:
            self.registration_screen.message_label.configure(text="Passwords do not match.")
            return

        result = register_owner_account(owner_name, cafe_name, email, phone, password, location)
        if not result["success"]:
            record_platform_activity(
                actor_id="SYSTEM",
                actor_name="System",
                actor_role="system",
                action="CAFE_REGISTERED",
                target_type="CAFE",
                target_id=result.get("cafe_id", "UNKNOWN"),
                target_name=cafe_name,
                status="FAILED",
                details=result.get("message", "Registration failed."),
            )
            self.registration_screen.message_label.configure(text=result["message"])
            return

        record_platform_activity(
            actor_id=result.get("user_id", "SYSTEM"),
            actor_name=owner_name,
            actor_role="cafe_owner",
            action="CAFE_REGISTERED",
            target_type="CAFE",
            target_id=result.get("cafe_id", "UNKNOWN"),
            target_name=cafe_name,
            status="SUCCESS",
            details=f"New café account registered for {owner_name}.",
        )
        self.registration_screen.message_label.configure(text="Registration successful. Please login to continue.")
        self.registration_screen.message_label.configure(text_color="#197C3B")
        self.reset_registration_form()
        self.show_login()

    def reset_registration_form(self):
        for field in self.registration_screen.fields.values():
            field.delete(0, "end")

    def logout(self):
        from modules.session import session
        actor_id = session.current_user_id
        actor_name = session.current_user_name or "Platform Admin"
        actor_role = session.current_user_role or "platform_admin"
        session.logout()
        if actor_role == "platform_admin":
            record_platform_activity(
                actor_id=actor_id,
                actor_name=actor_name,
                actor_role=actor_role,
                action="ADMIN_LOGOUT",
                target_type="SYSTEM",
                target_id="PLATFORM",
                target_name="CaféSync Platform",
                status="SUCCESS",
                details="Platform Admin logged out successfully.",
            )
        self.clear_sidebar()
        self.login_screen.grid()
        self.registration_screen.grid_remove()
        self.owner_dashboard.grid_remove()
        self.admin_dashboard.grid_remove()
        self.current_screen = "login"

    def show_owner_dashboard(self):
        self.login_screen.grid_remove()
        self.build_owner_shell()

    def show_admin_dashboard(self):
        self.login_screen.grid_remove()
        self.build_admin_shell()

    def on_login_mode_change(self, value):
        self.login_screen.clear_message()


if __name__ == "__main__":
    app = CafeSyncApp()
    app.root.mainloop()

# End of file
