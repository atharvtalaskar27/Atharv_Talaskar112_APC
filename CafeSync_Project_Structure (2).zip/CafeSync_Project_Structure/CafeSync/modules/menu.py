"""Menu data access and management helpers for CaféSync.

This module keeps menu persistence compatible with the existing CSV-based design
and preserves older menu records while adding the fields required for the menu
management workflow.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pandas as pd

from modules.setup_manager import ensure_file_columns

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
MENU_PATH = DATA_DIR / "menu.csv"


def _menu_path():
    return Path(DATA_DIR) / "menu.csv"

MENU_COLUMNS = [
    "item_id",
    "cafe_id",
    "item_name",
    "name",
    "category",
    "description",
    "price",
    "selling_price",
    "is_available",
    "status",
    "created_at",
    "updated_at",
]

ALLOWED_CATEGORIES = [
    "Coffee",
    "Beverages",
    "Tea",
    "Snacks",
    "Sandwiches",
    "Pizza",
    "Desserts",
    "Other",
]


def _ensure_menu_file():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    ensure_file_columns("menu.csv", MENU_COLUMNS)

    path = _menu_path()
    if not path.exists():
        pd.DataFrame(columns=MENU_COLUMNS).to_csv(path, index=False)
        return pd.DataFrame(columns=MENU_COLUMNS)

    try:
        df = pd.read_csv(path)
    except Exception:
        return pd.DataFrame(columns=MENU_COLUMNS)

    for column in MENU_COLUMNS:
        if column not in df.columns:
            df[column] = ""

    if "item_name" not in df.columns and "name" in df.columns:
        df["item_name"] = df["name"]
    if "name" not in df.columns and "item_name" in df.columns:
        df["name"] = df["item_name"]
    if "price" not in df.columns and "selling_price" in df.columns:
        df["price"] = df["selling_price"]
    if "selling_price" not in df.columns and "price" in df.columns:
        df["selling_price"] = df["price"]
    if "is_available" not in df.columns:
        status_values = df["status"].fillna("").astype(str).str.lower()
        df["is_available"] = ~status_values.isin({"archived", "inactive", "unavailable", "false", "0", "no"})
    if "status" not in df.columns:
        df["status"] = df["is_available"].map(lambda value: "active" if value else "inactive")

    df = df.reindex(columns=MENU_COLUMNS)
    df.to_csv(path, index=False)
    return df


def _as_bool(value):
    if isinstance(value, bool):
        return value
    if value is None or pd.isna(value):
        return True
    if isinstance(value, (int, float)):
        return bool(value)
    text = str(value).strip().lower()
    if text in {"", "true", "1", "yes", "available", "active"}:
        return True
    if text in {"false", "0", "no", "unavailable", "inactive", "archived"}:
        return False
    return True


def _normalize_menu_record(record):
    item_name = str(record.get("item_name") or record.get("name") or "").strip()
    category = str(record.get("category") or "Other").strip() or "Other"
    description = str(record.get("description") or "").strip()
    raw_price = record.get("selling_price")
    if raw_price in (None, ""):
        raw_price = record.get("price")
    try:
        price = float(raw_price)
    except (TypeError, ValueError):
        price = 0.0

    is_available = _as_bool(record.get("is_available", True))
    status = str(record.get("status") or ("active" if is_available else "inactive")).strip().lower()
    if status == "archived":
        is_available = False
    if not status:
        status = "active" if is_available else "inactive"

    return {
        "item_id": str(record.get("item_id") or "").strip(),
        "cafe_id": str(record.get("cafe_id") or "").strip(),
        "item_name": item_name,
        "name": item_name,
        "category": category,
        "description": description,
        "price": float(price),
        "selling_price": float(price),
        "is_available": bool(is_available),
        "status": status,
        "created_at": str(record.get("created_at") or "").strip(),
        "updated_at": str(record.get("updated_at") or "").strip(),
    }


def _generate_menu_item_id():
    df = _ensure_menu_file()
    if df.empty:
        return "MI001"

    values = []
    for value in df["item_id"].fillna("").astype(str):
        if value.startswith("MI") and value[2:].isdigit():
            values.append(int(value[2:]))

    next_number = max(values, default=0) + 1
    return f"MI{next_number:03d}"


def _save_menu_df(df):
    df = df.copy()
    if "is_available" in df.columns:
        df["is_available"] = df["is_available"].astype(object)
    if "status" in df.columns:
        df["status"] = df["status"].astype(object)
    df = df.reindex(columns=MENU_COLUMNS)
    df.to_csv(_menu_path(), index=False)


def get_menu_item_by_id(cafe_id, item_id):
    df = _ensure_menu_file()
    if df.empty:
        return None
    matches = df[(df["cafe_id"].astype(str) == str(cafe_id)) & (df["item_id"].astype(str) == str(item_id))]
    if matches.empty:
        return None
    return _normalize_menu_record(matches.iloc[0].to_dict())


def list_menu_items(cafe_id, search="", category="All", availability="All"):
    df = _ensure_menu_file()
    if df.empty:
        return []

    records = df[df["cafe_id"].astype(str) == str(cafe_id)].copy()
    if records.empty:
        return []

    if search:
        term = str(search).strip().lower()
        records = records[
            records["item_name"].fillna("").astype(str).str.lower().str.contains(term, na=False)
            | records["category"].fillna("").astype(str).str.lower().str.contains(term, na=False)
            | records["description"].fillna("").astype(str).str.lower().str.contains(term, na=False)
        ]

    if category not in ("All", ""):
        records = records[records["category"].fillna("").astype(str).str.lower() == str(category).strip().lower()]

    if availability == "Available":
        records = records[records["is_available"].apply(_as_bool)]
    elif availability == "Unavailable":
        records = records[~records["is_available"].apply(_as_bool)]

    records = records.sort_values(by=["item_name", "item_id"], kind="mergesort", na_position="last").reset_index(drop=True)
    return [_normalize_menu_record(row.to_dict()) for _, row in records.iterrows()]


def get_menu_summary(cafe_id):
    rows = list_menu_items(cafe_id)
    total = len(rows)
    available = sum(1 for row in rows if row["is_available"])
    unavailable = total - available
    categories = sorted({row["category"] for row in rows if row.get("category")})
    return {
        "total_items": total,
        "available_items": available,
        "unavailable_items": unavailable,
        "category_count": len(categories),
        "categories": categories,
    }


def add_menu_item(cafe_id, item_name, category, selling_price, description="", availability=True):
    cafe_id = str(cafe_id or "").strip()
    item_name = str(item_name or "").strip()
    category = str(category or "").strip() or "Other"
    description = str(description or "").strip()

    if not cafe_id:
        return {"success": False, "message": "No active café found."}
    if not item_name:
        return {"success": False, "message": "Item name is required."}
    if not category:
        return {"success": False, "message": "Category is required."}

    try:
        price_value = float(selling_price)
    except (TypeError, ValueError):
        return {"success": False, "message": "Please enter a valid selling price."}
    if price_value <= 0:
        return {"success": False, "message": "Selling price must be greater than zero."}

    df = _ensure_menu_file()
    duplicate = df[
        (df["cafe_id"].astype(str) == str(cafe_id))
        & (df["item_name"].fillna("").astype(str).str.lower() == item_name.lower())
    ]
    if not duplicate.empty:
        return {"success": False, "message": "This item already exists for this café."}

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    menu_item_id = _generate_menu_item_id()
    new_row = {
        "item_id": menu_item_id,
        "cafe_id": cafe_id,
        "item_name": item_name,
        "name": item_name,
        "category": category,
        "description": description,
        "price": float(price_value),
        "selling_price": float(price_value),
        "is_available": bool(availability),
        "status": "active" if bool(availability) else "inactive",
        "created_at": timestamp,
        "updated_at": timestamp,
    }
    row_df = pd.DataFrame([new_row], columns=MENU_COLUMNS)
    df = pd.concat([df.reindex(columns=MENU_COLUMNS), row_df], ignore_index=True, sort=False)
    _save_menu_df(df)

    return {"success": True, "message": "Menu item added successfully.", "item_id": menu_item_id, "menu_item": _normalize_menu_record(new_row)}


def update_menu_item(cafe_id, item_id, item_name=None, category=None, selling_price=None, description=None):
    cafe_id = str(cafe_id or "").strip()
    item_id = str(item_id or "").strip()
    if not cafe_id or not item_id:
        return {"success": False, "message": "Missing café or menu item information."}

    df = _ensure_menu_file()
    mask = (df["cafe_id"].astype(str) == cafe_id) & (df["item_id"].astype(str) == item_id)
    if not mask.any():
        return {"success": False, "message": "Menu item not found for this café."}

    item_name = str(item_name).strip() if item_name is not None else df.loc[mask, "item_name"].iloc[0]
    category = str(category).strip() if category is not None else df.loc[mask, "category"].iloc[0]
    description = str(description).strip() if description is not None else str(df.loc[mask, "description"].iloc[0])
    price_value = float(selling_price) if selling_price is not None else float(df.loc[mask, "selling_price"].fillna(df.loc[mask, "price"].fillna(0)).iloc[0])

    if not item_name:
        return {"success": False, "message": "Item name is required."}
    if not category:
        return {"success": False, "message": "Category is required."}
    if price_value <= 0:
        return {"success": False, "message": "Selling price must be greater than zero."}

    duplicate_mask = (df["cafe_id"].astype(str) == cafe_id) & (df["item_id"].astype(str) != item_id) & (df["item_name"].fillna("").astype(str).str.lower() == item_name.lower())
    if duplicate_mask.any():
        return {"success": False, "message": "Another item with this name already exists in this café."}

    df.loc[mask, "item_name"] = item_name
    df.loc[mask, "name"] = item_name
    df.loc[mask, "category"] = category
    df.loc[mask, "description"] = description
    df.loc[mask, "price"] = float(price_value)
    df.loc[mask, "selling_price"] = float(price_value)
    df.loc[mask, "updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    _save_menu_df(df)

    menu_item = get_menu_item_by_id(cafe_id, item_id)
    return {"success": True, "message": "Menu item updated successfully.", "menu_item": menu_item}


def toggle_item_availability(cafe_id, item_id, is_available=None):
    cafe_id = str(cafe_id or "").strip()
    item_id = str(item_id or "").strip()
    if not cafe_id or not item_id:
        return {"success": False, "message": "Missing café or menu item information."}

    df = _ensure_menu_file()
    mask = (df["cafe_id"].astype(str) == cafe_id) & (df["item_id"].astype(str) == item_id)
    if not mask.any():
        return {"success": False, "message": "Menu item not found for this café."}

    current_value = _as_bool(df.loc[mask, "is_available"].iloc[0])
    next_value = bool(is_available) if is_available is not None else not current_value
    df["is_available"] = df["is_available"].astype(object)
    df.loc[mask, "is_available"] = bool(next_value)
    df.loc[mask, "status"] = "active" if next_value else "inactive"
    df.loc[mask, "updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    _save_menu_df(df)

    menu_item = get_menu_item_by_id(cafe_id, item_id)
    return {"success": True, "message": "Availability updated successfully.", "menu_item": menu_item}


def archive_menu_item(cafe_id, item_id):
    cafe_id = str(cafe_id or "").strip()
    item_id = str(item_id or "").strip()
    if not cafe_id or not item_id:
        return {"success": False, "message": "Missing café or menu item information."}

    df = _ensure_menu_file()
    mask = (df["cafe_id"].astype(str) == cafe_id) & (df["item_id"].astype(str) == item_id)
    if not mask.any():
        return {"success": False, "message": "Menu item not found for this café."}

    df["is_available"] = df["is_available"].astype(object)
    df.loc[mask, "is_available"] = False
    df.loc[mask, "status"] = "archived"
    df.loc[mask, "updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    _save_menu_df(df)

    menu_item = get_menu_item_by_id(cafe_id, item_id)
    return {"success": True, "message": "Menu item archived successfully.", "menu_item": menu_item}


def delete_menu_item(cafe_id, item_id):
    return archive_menu_item(cafe_id, item_id)


__all__ = [
    "ALLOWED_CATEGORIES",
    "DATA_DIR",
    "MENU_PATH",
    "add_menu_item",
    "archive_menu_item",
    "delete_menu_item",
    "get_menu_item_by_id",
    "get_menu_summary",
    "list_menu_items",
    "toggle_item_availability",
    "update_menu_item",
]
