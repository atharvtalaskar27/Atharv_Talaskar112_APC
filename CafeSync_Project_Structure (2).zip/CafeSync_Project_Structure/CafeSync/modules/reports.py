"""Reporting and business-insights helpers for CaféSync.

The report layer reads the existing CSV data sources directly and keeps all
calculations aligned with the project's current order, billing, inventory,
purchase, recipe and waste models.
"""

from __future__ import annotations

from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation
from pathlib import Path

import pandas as pd

from modules.billing import list_bills, list_payments
from modules.inventory import list_ingredients, list_stock_movements
from modules.menu import list_menu_items
from modules.orders import list_orders
from modules.purchases import list_purchases
from modules.recipes import estimate_recipe_cost, list_recipes
from modules.waste import list_waste_entries

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"


def _safe_float(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _parse_date(value):
    if value is None or str(value).strip() == "":
        return None
    text = str(value).strip()
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%d-%m-%Y"):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            continue
    try:
        parsed = pd.to_datetime(text, errors="raise")
        if hasattr(parsed, "to_pydatetime"):
            return parsed.to_pydatetime()
    except Exception:
        return None
    return None


def _resolve_date_range(preset="Last 30 Days", start_date=None, end_date=None):
    today = datetime.now()

    if preset == "Today":
        start = datetime(today.year, today.month, today.day)
        end = start + timedelta(days=1) - timedelta(seconds=1)
    elif preset == "Yesterday":
        day = today - timedelta(days=1)
        start = datetime(day.year, day.month, day.day)
        end = start + timedelta(days=1) - timedelta(seconds=1)
    elif preset == "Last 7 Days":
        start = today - timedelta(days=6)
        start = datetime(start.year, start.month, start.day)
        end = datetime(today.year, today.month, today.day, 23, 59, 59)
    elif preset == "Last 30 Days":
        start = today - timedelta(days=29)
        start = datetime(start.year, start.month, start.day)
        end = datetime(today.year, today.month, today.day, 23, 59, 59)
    elif preset == "This Month":
        start = datetime(today.year, today.month, 1)
        end = datetime(today.year, today.month, 28) if today.month == 2 else datetime(today.year, today.month + 1, 1) - timedelta(seconds=1) if today.month < 12 else datetime(today.year + 1, 1, 1) - timedelta(seconds=1)
    elif preset == "Custom Range":
        start = _parse_date(start_date)
        end = _parse_date(end_date)
        if start is None:
            start = datetime(today.year, today.month, today.day)
        else:
            start = start.replace(hour=0, minute=0, second=0, microsecond=0)
        if end is None:
            end = datetime(today.year, today.month, today.day, 23, 59, 59)
        else:
            end = end.replace(hour=23, minute=59, second=59, microsecond=0)
    else:
        start = today - timedelta(days=29)
        start = datetime(start.year, start.month, start.day)
        end = datetime(today.year, today.month, today.day, 23, 59, 59)

    return start, end


def _within_range(value, start_dt, end_dt):
    if value is None or str(value).strip() == "":
        return False
    parsed = _parse_date(value)
    if parsed is None:
        return False
    return start_dt <= parsed <= end_dt


def _read_csv_frame(path_name):
    path = DATA_DIR / path_name
    if not path.exists():
        return pd.DataFrame()
    try:
        return pd.read_csv(path)
    except Exception:
        return pd.DataFrame()


def _filter_orders_for_range(cafe_id, start_dt, end_dt):
    orders_df = _read_csv_frame("orders.csv")
    if orders_df.empty:
        return pd.DataFrame()
    filtered = orders_df[orders_df["cafe_id"].astype(str) == str(cafe_id)].copy()
    if filtered.empty:
        return filtered
    filtered = filtered[filtered["created_at"].fillna("").astype(str).apply(lambda value: _within_range(value, start_dt, end_dt))]
    return filtered


def _filter_bills_for_range(cafe_id, start_dt, end_dt):
    bills_df = _read_csv_frame("bills.csv")
    if bills_df.empty:
        return pd.DataFrame()
    filtered = bills_df[bills_df["cafe_id"].astype(str) == str(cafe_id)].copy()
    if filtered.empty:
        return filtered
    filtered = filtered[filtered["issued_at"].fillna("").astype(str).apply(lambda value: _within_range(value, start_dt, end_dt))]
    return filtered


def _filter_payments_for_range(cafe_id, start_dt, end_dt):
    payments_df = _read_csv_frame("payments.csv")
    if payments_df.empty:
        return pd.DataFrame()
    filtered = payments_df[payments_df["cafe_id"].astype(str) == str(cafe_id)].copy()
    if filtered.empty:
        return filtered
    filtered = filtered[filtered["payment_date"].fillna("").astype(str).apply(lambda value: _within_range(value, start_dt, end_dt))]
    return filtered


def _filter_waste_for_range(cafe_id, start_dt, end_dt):
    waste = list_waste_entries(cafe_id)
    return [entry for entry in waste if _within_range(entry.get("occurred_at"), start_dt, end_dt)]


def _sum_total(values):
    total = Decimal("0")
    for value in values:
        if value is None or str(value).strip() == "":
            continue
        try:
            total += Decimal(str(value))
        except (InvalidOperation, TypeError, ValueError):
            continue
    return float(total)


def get_overview_report(cafe_id, preset="Last 30 Days", start_date=None, end_date=None):
    cafe_id = str(cafe_id or "").strip()
    if not cafe_id:
        return {"error": "No active café is selected."}

    start_dt, end_dt = _resolve_date_range(preset=preset, start_date=start_date, end_date=end_date)
    orders = [entry for entry in list_orders(cafe_id) if entry.get("order_status") == "Completed" and _within_range(entry.get("created_at"), start_dt, end_dt)]
    completed_count = len(orders)
    gross_sales = _sum_total([entry.get("total_amount") for entry in orders])
    bills = [entry for entry in list_bills(cafe_id) if _within_range(entry.get("issued_at"), start_dt, end_dt)]
    discounts = _sum_total([entry.get("discount_amount") for entry in bills])
    payments = [entry for entry in list_payments(cafe_id) if _within_range(entry.get("payment_date"), start_dt, end_dt)]
    collected = _sum_total([entry.get("amount") for entry in payments])
    outstanding = _sum_total([entry.get("balance_due") for entry in bills])
    average_order_value = gross_sales / completed_count if completed_count else None

    ingredients = list_ingredients(cafe_id)
    low_stock_count = sum(1 for ingredient in ingredients if float(ingredient.get("current_stock") or 0) <= float(ingredient.get("minimum_stock") or 0))

    waste_entries = _filter_waste_for_range(cafe_id, start_dt, end_dt)
    waste_cost = _sum_total([entry.get("estimated_total_cost") for entry in waste_entries if entry.get("estimated_total_cost") is not None])

    return {
        "report": "Overview",
        "period": {
            "preset": preset,
            "start": start_dt.strftime("%Y-%m-%d %H:%M:%S"),
            "end": end_dt.strftime("%Y-%m-%d %H:%M:%S"),
        },
        "metrics": {
            "completed_order_count": completed_count,
            "gross_sales": gross_sales if completed_count else None,
            "discounts": discounts if bills else None,
            "net_sales": gross_sales - discounts if completed_count or bills else None,
            "payments_collected": collected if payments else None,
            "outstanding_balance": outstanding if bills else None,
            "average_order_value": average_order_value,
            "low_stock_ingredient_count": low_stock_count,
            "recorded_waste_cost": waste_cost if waste_entries else None,
        },
    }


def get_sales_report(cafe_id, preset="Last 30 Days", start_date=None, end_date=None):
    cafe_id = str(cafe_id or "").strip()
    if not cafe_id:
        return {"error": "No active café is selected."}

    start_dt, end_dt = _resolve_date_range(preset=preset, start_date=start_date, end_date=end_date)
    order_rows = _filter_orders_for_range(cafe_id, start_dt, end_dt)
    completed_orders = order_rows[order_rows["order_status"].fillna("").astype(str).str.lower() == "completed"].copy()

    trend = []
    if not completed_orders.empty:
        completed_orders["date_key"] = completed_orders["created_at"].fillna("").astype(str).str.slice(0, 10)
        daily = completed_orders.groupby("date_key", as_index=False).agg(sales=("total_amount", "sum"), orders=("order_id", "count"))
        for _, row in daily.sort_values("date_key").iterrows():
            trend.append({"date": str(row["date_key"]), "sales": _safe_float(row.get("sales"), 0.0), "orders": int(row.get("orders") or 0)})

    order_items_df = _read_csv_frame("order_items.csv")
    item_sales = []
    if not order_items_df.empty:
        filtered_items = order_items_df[order_items_df["cafe_id"].astype(str) == cafe_id].copy()
        if not filtered_items.empty:
            filtered_items = filtered_items[filtered_items["order_id"].astype(str).isin(completed_orders["order_id"].astype(str))]
            if not filtered_items.empty:
                summary = filtered_items.groupby(["menu_item_id", "item_name_snapshot"], as_index=False).agg(quantity=("quantity", "sum"), sales=("line_total", "sum"))
                summary = summary.sort_values("sales", ascending=False)
                item_sales = [{"menu_item_id": str(row["menu_item_id"]), "item_name": str(row["item_name_snapshot"]), "quantity": _safe_float(row.get("quantity"), 0.0), "sales": _safe_float(row.get("sales"), 0.0)} for _, row in summary.iterrows()]

    bills = _filter_bills_for_range(cafe_id, start_dt, end_dt)
    discount_total = float(bills["discount_amount"].fillna(0).astype(float).sum()) if not bills.empty else 0.0
    payment_summary = []
    payments_df = _filter_payments_for_range(cafe_id, start_dt, end_dt)
    if not payments_df.empty:
        payment_summary = [{"method": str(row["payment_method"] or "Other"), "amount": _safe_float(row.get("amount"), 0.0)} for _, row in payments_df.groupby("payment_method", as_index=False)["amount"].sum().iterrows()]
    refunds_total = None

    average_order_value = (float(completed_orders["total_amount"].fillna(0).astype(float).sum()) / len(completed_orders)) if not completed_orders.empty else None

    return {
        "report": "Sales",
        "period": {"preset": preset, "start": start_dt.strftime("%Y-%m-%d %H:%M:%S"), "end": end_dt.strftime("%Y-%m-%d %H:%M:%S")},
        "sales_trend": trend,
        "menu_item_sales": item_sales,
        "average_order_value": average_order_value,
        "discount_total": discount_total,
        "refund_total": refunds_total,
        "payment_summary": payment_summary,
    }


def get_menu_cost_report(cafe_id, preset="Last 30 Days", start_date=None, end_date=None):
    cafe_id = str(cafe_id or "").strip()
    if not cafe_id:
        return {"error": "No active café is selected."}

    start_dt, end_dt = _resolve_date_range(preset=preset, start_date=start_date, end_date=end_date)
    order_rows = _filter_orders_for_range(cafe_id, start_dt, end_dt)
    completed_order_ids = set(order_rows[order_rows["order_status"].fillna("").astype(str).str.lower() == "completed"]["order_id"].astype(str))
    order_items_df = _read_csv_frame("order_items.csv")
    menu_rows = list_menu_items(cafe_id)
    menu_lookup = {str(item["item_id"]): item for item in menu_rows}

    sold_by_item = []
    missing_recipe = []
    if not order_items_df.empty:
        filtered = order_items_df[order_items_df["cafe_id"].astype(str) == cafe_id].copy()
        filtered = filtered[filtered["order_id"].astype(str).isin(completed_order_ids)]
        if not filtered.empty:
            summary = filtered.groupby(["menu_item_id", "item_name_snapshot"], as_index=False).agg(quantity=("quantity", "sum"), sales=("line_total", "sum"))
            for _, row in summary.sort_values("sales", ascending=False).iterrows():
                menu_item_id = str(row["menu_item_id"])
                sold_quantity = float(row.get("quantity") or 0)
                sales_value = float(row.get("sales") or 0)
                recipe = next((item for item in list_recipes(cafe_id) if item.get("menu_item_id") == menu_item_id), None)
                recipe_cost = None
                profit = None
                if recipe is not None:
                    cost_result = estimate_recipe_cost(cafe_id, recipe["recipe_id"])
                    recipe_cost = cost_result.get("estimated_ingredient_cost")
                    if recipe_cost is not None:
                        profit = sales_value - (float(recipe_cost) * sold_quantity)
                else:
                    missing_recipe.append({"menu_item_id": menu_item_id, "item_name": str(row["item_name_snapshot"]), "reason": "No recipe recorded"})
                sold_by_item.append({
                    "menu_item_id": menu_item_id,
                    "item_name": str(row["item_name_snapshot"]),
                    "quantity_sold": sold_quantity,
                    "sales_value": sales_value,
                    "estimated_cost_per_serving": recipe_cost,
                    "estimated_ingredient_cost": float(recipe_cost) * sold_quantity if recipe_cost is not None else None,
                    "estimated_gross_profit": profit,
                })

    return {
        "report": "Menu & Cost",
        "period": {"preset": preset, "start": start_dt.strftime("%Y-%m-%d %H:%M:%S"), "end": end_dt.strftime("%Y-%m-%d %H:%M:%S")},
        "best_sellers": sorted(sold_by_item, key=lambda row: row["quantity_sold"], reverse=True)[:10],
        "sales_by_item": sorted(sold_by_item, key=lambda row: row["sales_value"], reverse=True),
        "missing_recipe_items": missing_recipe,
    }


def get_inventory_report(cafe_id, preset="Last 30 Days", start_date=None, end_date=None):
    cafe_id = str(cafe_id or "").strip()
    if not cafe_id:
        return {"error": "No active café is selected."}

    start_dt, end_dt = _resolve_date_range(preset=preset, start_date=start_date, end_date=end_date)
    ingredients = list_ingredients(cafe_id)
    low_stock = [item for item in ingredients if float(item.get("current_stock") or 0) <= float(item.get("minimum_stock") or 0)]
    out_of_stock = [item for item in ingredients if float(item.get("current_stock") or 0) <= 0]
    stock_movements = [entry for entry in list_stock_movements(cafe_id) if _within_range(entry.get("created_at"), start_dt, end_dt)]
    movement_summary = {}
    for entry in stock_movements:
        movement_summary[entry.get("movement_type", "Unknown")] = movement_summary.get(entry.get("movement_type", "Unknown"), 0) + 1

    return {
        "report": "Inventory",
        "period": {"preset": preset, "start": start_dt.strftime("%Y-%m-%d %H:%M:%S"), "end": end_dt.strftime("%Y-%m-%d %H:%M:%S")},
        "current_stock": ingredients,
        "low_stock": low_stock,
        "out_of_stock": out_of_stock,
        "stock_movement_history": stock_movements,
        "movement_summary": movement_summary,
    }


def get_purchases_report(cafe_id, preset="Last 30 Days", start_date=None, end_date=None):
    cafe_id = str(cafe_id or "").strip()
    if not cafe_id:
        return {"error": "No active café is selected."}

    start_dt, end_dt = _resolve_date_range(preset=preset, start_date=start_date, end_date=end_date)
    purchases = [entry for entry in list_purchases(cafe_id) if _within_range(entry.get("created_at"), start_dt, end_dt)]
    ordered = [entry for entry in purchases if str(entry.get("status") or "Draft").lower() == "ordered"]
    partially_received = [entry for entry in purchases if str(entry.get("status") or "Draft").lower() == "partially received"]
    received = [entry for entry in purchases if str(entry.get("status") or "Draft").lower() == "received"]
    cancelled = [entry for entry in purchases if str(entry.get("status") or "Draft").lower() == "cancelled"]

    purchase_total = _sum_total([entry.get("subtotal") for entry in purchases])
    supplier_summary = {}
    for purchase in purchases:
        supplier_key = purchase.get("supplier_id") or "Unknown" 
        supplier_summary[supplier_key] = supplier_summary.get(supplier_key, 0.0) + float(purchase.get("subtotal") or 0)

    return {
        "report": "Purchases",
        "period": {"preset": preset, "start": start_dt.strftime("%Y-%m-%d %H:%M:%S"), "end": end_dt.strftime("%Y-%m-%d %H:%M:%S")},
        "purchases": purchases,
        "purchase_total_value": purchase_total,
        "ordered": ordered,
        "partially_received": partially_received,
        "received": received,
        "cancelled": cancelled,
        "by_supplier": [{"supplier_id": supplier, "total": value} for supplier, value in supplier_summary.items()],
    }


def get_waste_report(cafe_id, preset="Last 30 Days", start_date=None, end_date=None):
    cafe_id = str(cafe_id or "").strip()
    if not cafe_id:
        return {"error": "No active café is selected."}

    start_dt, end_dt = _resolve_date_range(preset=preset, start_date=start_date, end_date=end_date)
    entries = [entry for entry in list_waste_entries(cafe_id) if _within_range(entry.get("occurred_at"), start_dt, end_dt)]
    by_ingredient = {}
    by_reason = {}
    for entry in entries:
        ingredient_name = str(entry.get("ingredient_name") or entry.get("ingredient_id") or "Unknown")
        by_ingredient[ingredient_name] = by_ingredient.get(ingredient_name, 0.0) + float(entry.get("quantity") or 0)
        reason = str(entry.get("reason") or "Other")
        by_reason[reason] = by_reason.get(reason, 0.0) + float(entry.get("quantity") or 0)

    waste_cost = _sum_total([entry.get("estimated_total_cost") for entry in entries if entry.get("estimated_total_cost") is not None])
    return {
        "report": "Waste",
        "period": {"preset": preset, "start": start_dt.strftime("%Y-%m-%d %H:%M:%S"), "end": end_dt.strftime("%Y-%m-%d %H:%M:%S")},
        "entries": entries,
        "by_ingredient": [{"ingredient": ingredient, "quantity": quantity} for ingredient, quantity in by_ingredient.items()],
        "by_reason": [{"reason": reason, "quantity": quantity} for reason, quantity in by_reason.items()],
        "estimated_total_cost": waste_cost if entries else None,
    }


def export_report_csv(report_name, rows, file_path):
    if rows is None:
        rows = []
    df = pd.DataFrame(rows)
    output = Path(file_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output, index=False)
    return {"success": True, "path": str(output), "rows_exported": len(df.index)}


__all__ = [
    "export_report_csv",
    "get_inventory_report",
    "get_menu_cost_report",
    "get_overview_report",
    "get_purchases_report",
    "get_sales_report",
    "get_waste_report",
    "_resolve_date_range",
]
