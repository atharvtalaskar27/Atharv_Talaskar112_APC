"""Utilities for café creation, lookup, and ownership validation.

This module centralizes café-related rules so the application can keep a clear
owner-to-café relationship while preserving strict data isolation.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd


BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
CAFE_FILE = DATA_DIR / "cafes.csv"
USER_FILE = DATA_DIR / "users.csv"


def ensure_csv_files():
    """Create empty CSV files if they do not exist."""
    CAFE_FILE.parent.mkdir(parents=True, exist_ok=True)

    if not CAFE_FILE.exists():
        pd.DataFrame(
            columns=[
                "cafe_id",
                "owner_id",
                "cafe_name",
                "location",
                "phone",
                "status",
                "created_at",
            ]
        ).to_csv(CAFE_FILE, index=False)

    if not USER_FILE.exists():
        pd.DataFrame(
            columns=[
                "user_id",
                "name",
                "email",
                "phone",
                "password",
                "role",
                "status",
                "created_at",
            ]
        ).to_csv(USER_FILE, index=False)


ensure_csv_files()


def generate_cafe_id():
    """Generate a unique café ID in the format C###."""
    cafes = pd.read_csv(CAFE_FILE) if CAFE_FILE.exists() else pd.DataFrame()
    if cafes.empty:
        return "C001"

    numbers = []
    for value in cafes["cafe_id"].astype(str):
        if value.startswith("C") and value[1:].isdigit():
            numbers.append(int(value[1:]))

    next_number = max(numbers, default=0) + 1
    return f"C{next_number:03d}"


def get_all_cafes():
    """Return all café rows from the CSV file."""
    if not CAFE_FILE.exists():
        return pd.DataFrame(columns=[
            "cafe_id",
            "owner_id",
            "cafe_name",
            "location",
            "phone",
            "status",
            "created_at",
        ])
    return pd.read_csv(CAFE_FILE)


def get_cafe_by_id(cafe_id):
    cafes = get_all_cafes()
    if cafes.empty:
        return None
    result = cafes[cafes["cafe_id"].astype(str) == str(cafe_id)]
    if result.empty:
        return None
    return result.iloc[0].to_dict()


def get_cafes_for_owner(user_id):
    """Return every café linked to an owner."""
    cafes = get_all_cafes()
    if cafes.empty:
        return pd.DataFrame(columns=[
            "cafe_id",
            "owner_id",
            "cafe_name",
            "location",
            "phone",
            "status",
            "created_at",
        ])
    return cafes[cafes["owner_id"].astype(str) == str(user_id)].reset_index(drop=True)


def create_cafe(owner_id, cafe_name, location, phone):
    """Create a café record and return the new café ID."""
    cafes = get_all_cafes()
    café_id = generate_cafe_id()
    new_row = {
        "cafe_id": café_id,
        "owner_id": owner_id,
        "cafe_name": cafe_name,
        "location": location,
        "phone": phone,
        "status": "Active",
        "created_at": pd.Timestamp.now().strftime("%Y-%m-%d"),
    }
    cafes = pd.concat([cafes, pd.DataFrame([new_row])], ignore_index=True)
    cafes.to_csv(CAFE_FILE, index=False)
    return café_id


def get_cafe_information(cafe_id):
    """Return cafe details with a safe dictionary format."""
    cafe = get_cafe_by_id(cafe_id)
    if cafe is None:
        return None
    return cafe


def activate_cafe(cafe_id):
    cafes = get_all_cafes()
    if cafes.empty:
        return False
    mask = cafes["cafe_id"].astype(str) == str(cafe_id)
    if not mask.any():
        return False
    cafes.loc[mask, "status"] = "Active"
    cafes.to_csv(CAFE_FILE, index=False)
    return True


def deactivate_cafe(cafe_id):
    cafes = get_all_cafes()
    if cafes.empty:
        return False
    mask = cafes["cafe_id"].astype(str) == str(cafe_id)
    if not mask.any():
        return False
    cafes.loc[mask, "status"] = "Inactive"
    cafes.to_csv(CAFE_FILE, index=False)
    return True


def verify_owner_owns_cafe(user_id, cafe_id):
    """Check whether the user owns the given café."""
    cafe = get_cafe_by_id(cafe_id)
    if cafe is None:
        return False
    return str(cafe["owner_id"]) == str(user_id)


def verify_cafe_access(user_id, cafe_id):
    """Return True if the user can access the café.

    Platform admin has platform-wide access. Café owners can only access their
    own cafés.
    """
    user_id_text = str(user_id).strip()
    if user_id_text.lower() == "platform_admin" or user_id_text == "U001":
        return True

    if not cafe_id:
        return False

    cafe = get_cafe_by_id(cafe_id)
    if cafe is None:
        return False

    return str(cafe["owner_id"]) == str(user_id)
