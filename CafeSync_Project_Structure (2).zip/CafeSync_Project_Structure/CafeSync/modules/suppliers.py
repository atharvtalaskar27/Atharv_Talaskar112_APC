"""Supplier directory management for CaféSync."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
import re

import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
SUPPLIERS_PATH = DATA_DIR / "suppliers.csv"

SUPPLIER_COLUMNS = [
    "supplier_id",
    "cafe_id",
    "supplier_name",
    "contact_person",
    "phone",
    "email",
    "address",
    "category",
    "notes",
    "is_active",
    "created_at",
    "updated_at",
]

VALID_CATEGORIES = [
    "Coffee and Beverages",
    "Dairy",
    "Bakery",
    "Vegetables",
    "General Ingredients",
    "Packaging",
    "Other",
]

CATEGORY_ALIASES = {
    "coffee and beverages": "Coffee and Beverages",
    "coffee and beverage": "Coffee and Beverages",
    "dairy": "Dairy",
    "bakery": "Bakery",
    "vegetables": "Vegetables",
    "general ingredients": "General Ingredients",
    "general ingredient": "General Ingredients",
    "packaging": "Packaging",
    "other": "Other",
}


def _ensure_data_dir():
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def _atomic_write(frame, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temp_path, index=False)
    temp_path.replace(path)


def _read_suppliers_df():
    _ensure_data_dir()
    if not SUPPLIERS_PATH.exists():
        empty = pd.DataFrame(columns=SUPPLIER_COLUMNS)
        _atomic_write(empty, SUPPLIERS_PATH)
        return empty
    try:
        df = pd.read_csv(SUPPLIERS_PATH)
    except Exception:
        return pd.DataFrame(columns=SUPPLIER_COLUMNS)
    for column in SUPPLIER_COLUMNS:
        if column not in df.columns:
            df[column] = ""
    df = df.reindex(columns=SUPPLIER_COLUMNS)
    _atomic_write(df, SUPPLIERS_PATH)
    return df


def _generate_supplier_id():
    df = _read_suppliers_df()
    if df.empty:
        return "S001"
    values = []
    for value in df["supplier_id"].fillna("").astype(str):
        if value.startswith("S") and value[1:].isdigit():
            values.append(int(value[1:]))
    return f"S{max(values, default=0) + 1:03d}"


def _is_valid_phone(value):
    if not value or not str(value).strip():
        return True
    digits = re.sub(r"\D", "", str(value).strip())
    return len(digits) >= 10


def _is_valid_email(value):
    if not value or not str(value).strip():
        return True
    return bool(re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", str(value).strip()))


def _normalize_category(value):
    raw = str(value or "Other").strip() or "Other"
    return CATEGORY_ALIASES.get(raw.lower(), raw)


def _normalize_supplier_row(row):
    return {
        "supplier_id": str(row.get("supplier_id") or "").strip(),
        "cafe_id": str(row.get("cafe_id") or "").strip(),
        "supplier_name": str(row.get("supplier_name") or "").strip(),
        "contact_person": str(row.get("contact_person") or "").strip(),
        "phone": str(row.get("phone") or "").strip(),
        "email": str(row.get("email") or "").strip(),
        "address": str(row.get("address") or "").strip(),
        "category": _normalize_category(row.get("category") or "Other"),
        "notes": str(row.get("notes") or "").strip(),
        "is_active": bool(str(row.get("is_active") or "true").strip().lower() in {"true", "1", "yes", "active"}),
        "created_at": str(row.get("created_at") or "").strip(),
        "updated_at": str(row.get("updated_at") or "").strip(),
    }


def list_suppliers(cafe_id, search="", status="All", category="All"):
    cafe_id = str(cafe_id or "").strip()
    df = _read_suppliers_df()
    if df.empty:
        return []
    filtered = df[df["cafe_id"].astype(str) == cafe_id].copy()
    if filtered.empty:
        return []
    if search:
        term = str(search).strip().lower()
        filtered = filtered[
            filtered["supplier_name"].fillna("").astype(str).str.lower().str.contains(term, na=False)
            | filtered["contact_person"].fillna("").astype(str).str.lower().str.contains(term, na=False)
            | filtered["category"].fillna("").astype(str).str.lower().str.contains(term, na=False)
        ]
    if status != "All":
        want_active = status.lower() == "active"
        filtered = filtered[filtered["is_active"].astype(str).str.lower().isin({"true", "1", "yes", "active"}) == want_active]
    if category != "All":
        filtered = filtered[filtered["category"].fillna("").astype(str).str.lower() == str(category).lower()]
    return [_normalize_supplier_row(row.to_dict()) for _, row in filtered.sort_values(by=["supplier_name"], kind="mergesort").iterrows()]


def get_supplier_by_id(cafe_id, supplier_id):
    cafe_id = str(cafe_id or "").strip()
    supplier_id = str(supplier_id or "").strip()
    df = _read_suppliers_df()
    if df.empty:
        return None
    match = df[(df["cafe_id"].astype(str) == cafe_id) & (df["supplier_id"].astype(str) == supplier_id)]
    if match.empty:
        return None
    return _normalize_supplier_row(match.iloc[0].to_dict())


def add_supplier(cafe_id, supplier_name, contact_person="", phone="", email="", address="", category="General ingredients", notes="", is_active=True):
    cafe_id = str(cafe_id or "").strip()
    supplier_name = str(supplier_name or "").strip()
    if not cafe_id:
        return {"success": False, "message": "No active café is selected."}
    if not supplier_name:
        return {"success": False, "message": "Supplier name is required."}
    if phone and not _is_valid_phone(phone):
        return {"success": False, "message": "Please enter a valid phone number when provided."}
    if email and not _is_valid_email(email):
        return {"success": False, "message": "Please enter a valid email when provided."}

    df = _read_suppliers_df()
    duplicate = df[(df["cafe_id"].astype(str) == cafe_id) & (df["supplier_name"].fillna("").astype(str).str.lower() == supplier_name.lower())]
    if not duplicate.empty:
        return {"success": False, "message": "This supplier already exists for this café."}

    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    record = {
        "supplier_id": _generate_supplier_id(),
        "cafe_id": cafe_id,
        "supplier_name": supplier_name,
        "contact_person": str(contact_person or "").strip(),
        "phone": str(phone).strip(),
        "email": str(email or "").strip(),
        "address": str(address or "").strip(),
        "category": _normalize_category(category or "General Ingredients"),
        "notes": str(notes or "").strip(),
        "is_active": bool(is_active),
        "created_at": now,
        "updated_at": now,
    }
    df = pd.concat([df.reindex(columns=SUPPLIER_COLUMNS), pd.DataFrame([record], columns=SUPPLIER_COLUMNS)], ignore_index=True, sort=False)
    _atomic_write(df, SUPPLIERS_PATH)
    return {"success": True, "message": "Supplier added successfully.", "supplier": _normalize_supplier_row(record)}


def update_supplier(cafe_id, supplier_id, **kwargs):
    cafe_id = str(cafe_id or "").strip()
    supplier_id = str(supplier_id or "").strip()
    if not cafe_id or not supplier_id:
        return {"success": False, "message": "Missing café or supplier information."}

    df = _read_suppliers_df()
    mask = (df["cafe_id"].astype(str) == cafe_id) & (df["supplier_id"].astype(str) == supplier_id)
    if not mask.any():
        return {"success": False, "message": "Supplier not found for this café."}

    supplier_name = str(kwargs.get("supplier_name") or df.loc[mask, "supplier_name"].iloc[0]).strip()
    if not supplier_name:
        return {"success": False, "message": "Supplier name is required."}
    phone = str(kwargs.get("phone") if kwargs.get("phone") is not None else df.loc[mask, "phone"].iloc[0]).strip()
    if phone and not _is_valid_phone(phone):
        return {"success": False, "message": "Please enter a valid phone number when provided."}
    email = str(kwargs.get("email") if kwargs.get("email") is not None else df.loc[mask, "email"].iloc[0]).strip()
    if email and not _is_valid_email(email):
        return {"success": False, "message": "Please enter a valid email when provided."}
    category = _normalize_category(kwargs.get("category") or df.loc[mask, "category"].iloc[0] or "General Ingredients")

    duplicate = df[(df["cafe_id"].astype(str) == cafe_id) & (df["supplier_id"].astype(str) != supplier_id) & (df["supplier_name"].fillna("").astype(str).str.lower() == supplier_name.lower())]
    if not duplicate.empty:
        return {"success": False, "message": "Another supplier with this name already exists for this café."}

    df.loc[mask, "supplier_name"] = supplier_name
    df.loc[mask, "contact_person"] = str(kwargs.get("contact_person") if kwargs.get("contact_person") is not None else df.loc[mask, "contact_person"].iloc[0]).strip()
    df.loc[mask, "phone"] = phone
    df.loc[mask, "email"] = email
    df.loc[mask, "address"] = str(kwargs.get("address") if kwargs.get("address") is not None else df.loc[mask, "address"].iloc[0]).strip()
    df.loc[mask, "category"] = category
    df.loc[mask, "notes"] = str(kwargs.get("notes") if kwargs.get("notes") is not None else df.loc[mask, "notes"].iloc[0]).strip()
    df.loc[mask, "is_active"] = bool(kwargs.get("is_active") if kwargs.get("is_active") is not None else str(df.loc[mask, "is_active"].iloc[0]).strip().lower() in {"true", "1", "yes", "active"})
    df.loc[mask, "updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    _atomic_write(df, SUPPLIERS_PATH)
    return {"success": True, "message": "Supplier updated successfully.", "supplier": get_supplier_by_id(cafe_id, supplier_id)}


def deactivate_supplier(cafe_id, supplier_id):
    cafe_id = str(cafe_id or "").strip()
    supplier_id = str(supplier_id or "").strip()
    supplier = get_supplier_by_id(cafe_id, supplier_id)
    if supplier is None:
        return {"success": False, "message": "Supplier not found for this café."}

    df = _read_suppliers_df()
    mask = (df["cafe_id"].astype(str) == cafe_id) & (df["supplier_id"].astype(str) == supplier_id)
    df.loc[mask, "is_active"] = False
    df.loc[mask, "updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    _atomic_write(df, SUPPLIERS_PATH)
    return {"success": True, "message": "Supplier deactivated successfully.", "supplier": get_supplier_by_id(cafe_id, supplier_id)}


def reactivate_supplier(cafe_id, supplier_id):
    cafe_id = str(cafe_id or "").strip()
    supplier_id = str(supplier_id or "").strip()
    supplier = get_supplier_by_id(cafe_id, supplier_id)
    if supplier is None:
        return {"success": False, "message": "Supplier not found for this café."}

    df = _read_suppliers_df()
    mask = (df["cafe_id"].astype(str) == cafe_id) & (df["supplier_id"].astype(str) == supplier_id)
    df.loc[mask, "is_active"] = True
    df.loc[mask, "updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    _atomic_write(df, SUPPLIERS_PATH)
    return {"success": True, "message": "Supplier reactivated successfully.", "supplier": get_supplier_by_id(cafe_id, supplier_id)}


__all__ = [
    "VALID_CATEGORIES",
    "add_supplier",
    "deactivate_supplier",
    "get_supplier_by_id",
    "list_suppliers",
    "reactivate_supplier",
    "update_supplier",
]
