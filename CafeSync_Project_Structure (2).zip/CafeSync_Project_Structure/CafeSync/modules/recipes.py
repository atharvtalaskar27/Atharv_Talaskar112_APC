"""Recipe and recipe-ingredient management for CaféSync."""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path

import pandas as pd

from modules.inventory import get_ingredient_by_id, list_ingredients
from modules.menu import get_menu_item_by_id, list_menu_items

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
RECIPES_PATH = DATA_DIR / "recipes.csv"
RECIPE_INGREDIENTS_PATH = DATA_DIR / "recipe_ingredients.csv"

RECIPE_COLUMNS = [
    "recipe_id",
    "cafe_id",
    "menu_item_id",
    "created_at",
    "updated_at",
    "is_complete",
]

RECIPE_INGREDIENT_COLUMNS = [
    "recipe_ingredient_id",
    "cafe_id",
    "recipe_id",
    "ingredient_id",
    "ingredient_name",
    "quantity_required",
    "unit",
    "created_at",
    "updated_at",
]

UNIT_ALIASES = {
    "g": "g",
    "gram": "g",
    "grams": "g",
    "kg": "kg",
    "kilogram": "kg",
    "kilograms": "kg",
    "ml": "ml",
    "millilitre": "ml",
    "milliliter": "ml",
    "millilitres": "ml",
    "milliliters": "ml",
    "l": "litre",
    "liter": "litre",
    "litre": "litre",
    "litres": "litre",
    "liters": "litre",
    "piece": "pcs",
    "pieces": "pcs",
    "pcs": "pcs",
    "pc": "pcs",
}


def _ensure_data_dir():
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def _atomic_write(frame, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temp_path, index=False)
    temp_path.replace(path)


def _read_recipes_df():
    _ensure_data_dir()
    if not RECIPES_PATH.exists():
        empty = pd.DataFrame(columns=RECIPE_COLUMNS)
        _atomic_write(empty, RECIPES_PATH)
        return empty
    try:
        df = pd.read_csv(RECIPES_PATH)
    except Exception:
        return pd.DataFrame(columns=RECIPE_COLUMNS)
    for column in RECIPE_COLUMNS:
        if column not in df.columns:
            df[column] = ""
    return df.reindex(columns=RECIPE_COLUMNS)


def _read_recipe_ingredients_df():
    _ensure_data_dir()
    if not RECIPE_INGREDIENTS_PATH.exists():
        empty = pd.DataFrame(columns=RECIPE_INGREDIENT_COLUMNS)
        _atomic_write(empty, RECIPE_INGREDIENTS_PATH)
        return empty
    try:
        df = pd.read_csv(RECIPE_INGREDIENTS_PATH)
    except Exception:
        return pd.DataFrame(columns=RECIPE_INGREDIENT_COLUMNS)
    for column in RECIPE_INGREDIENT_COLUMNS:
        if column not in df.columns:
            df[column] = ""
    return df.reindex(columns=RECIPE_INGREDIENT_COLUMNS)


def _canonical_unit(value):
    raw = str(value or "").strip().lower()
    if not raw:
        raise ValueError("Unit is required.")
    canonical = UNIT_ALIASES.get(raw)
    if canonical is None:
        raise ValueError(f"Unsupported unit '{value}'.")
    return canonical


def _generate_recipe_id():
    df = _read_recipes_df()
    if df.empty:
        return "R001"
    values = []
    for value in df["recipe_id"].fillna("").astype(str):
        if value.startswith("R") and value[1:].isdigit():
            values.append(int(value[1:]))
    return f"R{max(values, default=0) + 1:03d}"


def _generate_recipe_ingredient_id():
    df = _read_recipe_ingredients_df()
    if df.empty:
        return "RI001"
    values = []
    for value in df["recipe_ingredient_id"].fillna("").astype(str):
        if value.startswith("RI") and value[2:].isdigit():
            values.append(int(value[2:]))
    return f"RI{max(values, default=0) + 1:03d}"


def _decimal(value):
    if value is None or value == "":
        raise ValueError("Value is missing.")
    try:
        return Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError("Invalid numeric value.")


def _convert_quantity(value, from_unit, to_unit):
    from_unit = _canonical_unit(from_unit)
    to_unit = _canonical_unit(to_unit)
    if from_unit == to_unit:
        return Decimal(str(value))
    mapping = {
        ("kg", "g"): Decimal("1000"),
        ("g", "kg"): Decimal("0.001"),
        ("litre", "ml"): Decimal("1000"),
        ("ml", "litre"): Decimal("0.001"),
    }
    factor = mapping.get((from_unit, to_unit))
    if factor is None:
        raise ValueError(f"Incompatible units: {from_unit} and {to_unit}.")
    return Decimal(str(value)) * factor


def _resolve_ingredient(cafe_id, entry):
    if not isinstance(entry, dict):
        return None
    ingredient_id = str(entry.get("ingredient_id") or "").strip()
    name = str(entry.get("ingredient_name") or entry.get("name") or "").strip()
    if ingredient_id:
        ingredient = get_ingredient_by_id(cafe_id, ingredient_id)
        if ingredient:
            return ingredient
    if name:
        for ingredient in list_ingredients(cafe_id):
            if ingredient["name"].lower() == name.lower():
                return ingredient
    return None


def _recipe_row(row):
    recipe = row.to_dict()
    recipe["recipe_id"] = str(recipe.get("recipe_id") or "").strip()
    recipe["cafe_id"] = str(recipe.get("cafe_id") or "").strip()
    recipe["menu_item_id"] = str(recipe.get("menu_item_id") or "").strip()
    recipe["is_complete"] = bool(str(recipe.get("is_complete") or "false").strip().lower() in {"true", "1", "yes"})
    return recipe


def _recipe_lookup(cafe_id, recipe_id):
    cafe_id = str(cafe_id or "").strip()
    recipe_id = str(recipe_id or "").strip()
    df = _read_recipes_df()
    if df.empty:
        return None
    match = df[(df["cafe_id"].astype(str) == cafe_id) & (df["recipe_id"].astype(str) == recipe_id)]
    if match.empty:
        return None
    recipe = _recipe_row(match.iloc[0])
    menu_item = get_menu_item_by_id(cafe_id, recipe["menu_item_id"])
    recipe["menu_item_name"] = menu_item["item_name"] if menu_item else "Unknown item"
    recipe["menu_item_category"] = menu_item["category"] if menu_item else "Other"
    recipe["ingredients"] = list_recipe_ingredients(cafe_id, recipe_id)
    return recipe


def list_recipes(cafe_id, search="", category="All", include_costs=False):
    cafe_id = str(cafe_id or "").strip()
    df = _read_recipes_df()
    if df.empty:
        return []
    filtered = df[df["cafe_id"].astype(str) == cafe_id].copy()
    if filtered.empty:
        return []

    if search:
        term = str(search).strip().lower()
        menu_map = {item["item_id"]: item for item in list_menu_items(cafe_id)}
        filtered = filtered[
            filtered["recipe_id"].fillna("").astype(str).str.lower().str.contains(term, na=False)
            | filtered["menu_item_id"].fillna("").astype(str).str.lower().str.contains(term, na=False)
            | filtered["menu_item_id"].apply(lambda value: str(menu_map.get(str(value), {}).get("item_name", "")).lower().find(term) >= 0)
        ]

    if category != "All":
        menu_map = {item["item_id"]: item for item in list_menu_items(cafe_id)}
        filtered = filtered[filtered["menu_item_id"].apply(lambda value: menu_map.get(str(value), {}).get("category") == category)]

    results = []
    for _, row in filtered.sort_values(by=["updated_at", "recipe_id"], ascending=[False, False], kind="mergesort").iterrows():
        recipe = _recipe_row(row)
        menu_item = get_menu_item_by_id(cafe_id, recipe["menu_item_id"])
        recipe["menu_item_name"] = menu_item["item_name"] if menu_item else "Unknown item"
        recipe["menu_item_category"] = menu_item["category"] if menu_item else "Other"
        recipe["ingredient_count"] = len(list_recipe_ingredients(cafe_id, recipe["recipe_id"]))
        if include_costs:
            recipe["estimated_ingredient_cost"] = estimate_recipe_cost(cafe_id, recipe["recipe_id"]).get("estimated_ingredient_cost")
        results.append(recipe)
    return results


def get_recipe_by_id(cafe_id, recipe_id):
    recipe = _recipe_lookup(cafe_id, recipe_id)
    if recipe is None:
        return None
    recipe["ingredients"] = list_recipe_ingredients(cafe_id, recipe_id)
    return recipe


def list_recipe_ingredients(cafe_id, recipe_id):
    cafe_id = str(cafe_id or "").strip()
    recipe_id = str(recipe_id or "").strip()
    df = _read_recipe_ingredients_df()
    if df.empty:
        return []
    filtered = df[(df["cafe_id"].astype(str) == cafe_id) & (df["recipe_id"].astype(str) == recipe_id)].copy()
    if filtered.empty:
        return []
    results = []
    for _, row in filtered.sort_values(by=["ingredient_name", "recipe_ingredient_id"], kind="mergesort").iterrows():
        ingredient = get_ingredient_by_id(cafe_id, row["ingredient_id"])
        entry = row.to_dict()
        entry["ingredient_name"] = ingredient["name"] if ingredient else str(row.get("ingredient_name") or "Unknown ingredient")
        entry["unit"] = str(row.get("unit") or (ingredient["unit"] if ingredient else "g")).strip() or "g"
        entry["quantity_required"] = float(row.get("quantity_required") or 0)
        results.append(entry)
    return results


def add_recipe(cafe_id, menu_item_id, ingredient_lines):
    cafe_id = str(cafe_id or "").strip()
    menu_item_id = str(menu_item_id or "").strip()
    if not cafe_id:
        return {"success": False, "message": "No active café is selected."}
    if not menu_item_id:
        return {"success": False, "message": "Menu item is required."}
    menu_item = get_menu_item_by_id(cafe_id, menu_item_id)
    if menu_item is None:
        return {"success": False, "message": "Menu item does not exist for this café."}
    if not isinstance(ingredient_lines, list) or not ingredient_lines:
        return {"success": False, "message": "Add at least one ingredient line to the recipe."}

    recipes_df = _read_recipes_df()
    if any(str(row.get("cafe_id")) == cafe_id and str(row.get("menu_item_id")) == menu_item_id for _, row in recipes_df.iterrows()):
        return {"success": False, "message": "A recipe already exists for this menu item."}

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    recipe_id = _generate_recipe_id()
    recipes_df = pd.concat([
        recipes_df.reindex(columns=RECIPE_COLUMNS),
        pd.DataFrame([{
            "recipe_id": recipe_id,
            "cafe_id": cafe_id,
            "menu_item_id": menu_item_id,
            "created_at": timestamp,
            "updated_at": timestamp,
            "is_complete": False,
        }], columns=RECIPE_COLUMNS)
    ], ignore_index=True, sort=False)
    _atomic_write(recipes_df, RECIPES_PATH)

    lines_df = _read_recipe_ingredients_df()
    seen_ingredients = set()
    for entry in ingredient_lines:
        if not isinstance(entry, dict):
            return {"success": False, "message": "Ingredient line entries must be dictionaries."}
        ingredient = _resolve_ingredient(cafe_id, entry)
        if ingredient is None:
            return {"success": False, "message": "Ingredient not found or not available for this café."}
        ingredient_id = ingredient["ingredient_id"]
        if ingredient_id in seen_ingredients:
            return {"success": False, "message": "Duplicate ingredients are not allowed in a recipe."}
        seen_ingredients.add(ingredient_id)

        try:
            quantity = _decimal(entry.get("quantity_required"))
        except ValueError:
            return {"success": False, "message": f"Quantity for {ingredient['name']} must be a valid number."}
        if quantity <= 0:
            return {"success": False, "message": f"Quantity for {ingredient['name']} must be greater than zero."}

        unit = str(entry.get("unit") or ingredient["unit"]).strip() or ingredient["unit"]
        try:
            _convert_quantity(quantity, unit, ingredient["unit"])
        except ValueError:
            return {"success": False, "message": f"Unit '{unit}' is incompatible with ingredient '{ingredient['name']}' ({ingredient['unit']})."}

        lines_df = pd.concat([
            lines_df.reindex(columns=RECIPE_INGREDIENT_COLUMNS),
            pd.DataFrame([{
                "recipe_ingredient_id": _generate_recipe_ingredient_id(),
                "cafe_id": cafe_id,
                "recipe_id": recipe_id,
                "ingredient_id": ingredient_id,
                "ingredient_name": ingredient["name"],
                "quantity_required": float(quantity),
                "unit": _canonical_unit(unit),
                "created_at": timestamp,
                "updated_at": timestamp,
            }], columns=RECIPE_INGREDIENT_COLUMNS)
        ], ignore_index=True, sort=False)
    _atomic_write(lines_df, RECIPE_INGREDIENTS_PATH)
    completed = set_recipe_complete(cafe_id, recipe_id, True)
    if not completed["success"]:
        return {"success": False, "message": completed["message"]}
    return {"success": True, "message": "Recipe created successfully.", "recipe": get_recipe_by_id(cafe_id, recipe_id)}


def update_recipe(cafe_id, recipe_id, ingredient_lines):
    cafe_id = str(cafe_id or "").strip()
    recipe_id = str(recipe_id or "").strip()
    if not recipe_id:
        return {"success": False, "message": "Recipe ID is required."}
    if not ingredient_lines:
        return {"success": False, "message": "At least one ingredient line is required."}

    recipe = get_recipe_by_id(cafe_id, recipe_id)
    if recipe is None:
        return {"success": False, "message": "Recipe not found for this café."}

    lines_df = _read_recipe_ingredients_df()
    mask = (lines_df["cafe_id"].astype(str) == cafe_id) & (lines_df["recipe_id"].astype(str) == recipe_id)
    lines_df = lines_df[~mask].copy()
    seen_ingredients = set()

    for entry in ingredient_lines:
        ingredient = _resolve_ingredient(cafe_id, entry)
        if ingredient is None:
            return {"success": False, "message": "Ingredient not found or not available for this café."}
        ingredient_id = ingredient["ingredient_id"]
        if ingredient_id in seen_ingredients:
            return {"success": False, "message": "Duplicate ingredients are not allowed in a recipe."}
        seen_ingredients.add(ingredient_id)

        try:
            quantity = _decimal(entry.get("quantity_required"))
        except ValueError:
            return {"success": False, "message": f"Quantity for {ingredient['name']} must be a valid number."}
        if quantity <= 0:
            return {"success": False, "message": f"Quantity for {ingredient['name']} must be greater than zero."}

        unit = str(entry.get("unit") or ingredient["unit"]).strip() or ingredient["unit"]
        try:
            _convert_quantity(quantity, unit, ingredient["unit"])
        except ValueError:
            return {"success": False, "message": f"Unit '{unit}' is incompatible with ingredient '{ingredient['name']}' ({ingredient['unit']})."}
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        lines_df = pd.concat([
            lines_df.reindex(columns=RECIPE_INGREDIENT_COLUMNS),
            pd.DataFrame([{
                "recipe_ingredient_id": _generate_recipe_ingredient_id(),
                "cafe_id": cafe_id,
                "recipe_id": recipe_id,
                "ingredient_id": ingredient_id,
                "ingredient_name": ingredient["name"],
                "quantity_required": float(quantity),
                "unit": _canonical_unit(unit),
                "created_at": timestamp,
                "updated_at": timestamp,
            }], columns=RECIPE_INGREDIENT_COLUMNS)
        ], ignore_index=True, sort=False)

    _atomic_write(lines_df, RECIPE_INGREDIENTS_PATH)
    recipes_df = _read_recipes_df()
    mask = (recipes_df["cafe_id"].astype(str) == cafe_id) & (recipes_df["recipe_id"].astype(str) == recipe_id)
    recipes_df.loc[mask, "is_complete"] = True
    recipes_df.loc[mask, "updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    _atomic_write(recipes_df, RECIPES_PATH)
    return {"success": True, "message": "Recipe updated successfully.", "recipe": get_recipe_by_id(cafe_id, recipe_id)}


def estimate_recipe_cost(cafe_id, recipe_id):
    recipe = _recipe_lookup(cafe_id, recipe_id)
    if recipe is None:
        return {"success": False, "message": "Recipe not found.", "estimated_ingredient_cost": None, "cost_status": "Cost unavailable"}

    ingredient_lines = list_recipe_ingredients(cafe_id, recipe_id)
    if not ingredient_lines:
        return {
            "success": True,
            "menu_item_id": recipe["menu_item_id"],
            "estimated_ingredient_cost": None,
            "cost_status": "Cost unavailable",
        }

    total = Decimal("0")
    cost_available = True
    for entry in ingredient_lines:
        ingredient = get_ingredient_by_id(cafe_id, entry.get("ingredient_id") or "")
        if ingredient is None:
            cost_available = False
            continue

        unit_cost = ingredient.get("unit_cost")
        if unit_cost in (None, ""):
            cost_available = False
            continue

        try:
            ingredient_cost = Decimal(str(unit_cost))
            quantity_required = Decimal(str(entry.get("quantity_required") or 0))
            if quantity_required <= 0:
                cost_available = False
                continue
            scaled = _convert_quantity(quantity_required, entry.get("unit") or ingredient["unit"], ingredient["unit"])
            total += scaled * ingredient_cost
        except (InvalidOperation, TypeError, ValueError):
            cost_available = False

    return {
        "success": True,
        "menu_item_id": recipe["menu_item_id"],
        "estimated_ingredient_cost": float(total) if cost_available else None,
        "cost_status": "Cost unavailable" if not cost_available else "Available",
    }


def set_recipe_complete(cafe_id, recipe_id, is_complete=True):
    cafe_id = str(cafe_id or "").strip()
    recipe_id = str(recipe_id or "").strip()
    recipes_df = _read_recipes_df()
    mask = (recipes_df["cafe_id"].astype(str) == cafe_id) & (recipes_df["recipe_id"].astype(str) == recipe_id)
    if not mask.any():
        return {"success": False, "message": "Recipe not found for this café."}
    recipes_df.loc[mask, "is_complete"] = bool(is_complete)
    recipes_df.loc[mask, "updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    _atomic_write(recipes_df, RECIPES_PATH)
    return {"success": True, "message": "Recipe status updated.", "recipe": get_recipe_by_id(cafe_id, recipe_id)}


def get_recipe_dashboard(cafe_id):
    recipes = list_recipes(cafe_id)
    total = len(recipes)
    complete = sum(1 for recipe in recipes if recipe.get("is_complete"))
    return {
        "total_recipes": total,
        "complete_recipes": complete,
        "incomplete_recipes": total - complete,
    }


__all__ = [
    "add_recipe",
    "estimate_recipe_cost",
    "get_recipe_by_id",
    "get_recipe_dashboard",
    "list_recipe_ingredients",
    "list_recipes",
    "set_recipe_complete",
    "update_recipe",
]
