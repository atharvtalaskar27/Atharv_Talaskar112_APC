"""Platform-level café account management for the CaféSync SaaS prototype.

This module keeps CSV-based storage logic separate from the UI and exposes a
simple service layer that can later be swapped with a database-backed repository
without changing the view layer.
"""

from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

import pandas as pd

from modules.setup_manager import get_setup_status

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
CAFE_FILE = DATA_DIR / "cafes.csv"
USER_FILE = DATA_DIR / "users.csv"
ACTIVITY_FILE = DATA_DIR / "platform_activity.csv"


def _ensure_files():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not CAFE_FILE.exists():
        pd.DataFrame(
            columns=[
                "cafe_id",
                "owner_id",
                "cafe_name",
                "location",
                "phone",
                "status",
                "created_at",
                "cafe_type",
                "opening_date",
                "opening_time",
                "closing_time",
                "setup_completed",
                "setup_progress",
            ]
        ).to_csv(CAFE_FILE, index=False)

    if not USER_FILE.exists():
        pd.DataFrame(
            columns=[
                "user_id",
                "name",
                "email",
                "phone",
                "password",
                "role",
                "status",
                "created_at",
            ]
        ).to_csv(USER_FILE, index=False)

    if not ACTIVITY_FILE.exists():
        pd.DataFrame(
            columns=["timestamp", "message", "actor_id", "actor_name", "category"]
        ).to_csv(ACTIVITY_FILE, index=False)


_ensure_files()


def _safe_read_csv(path: Path):
    if not path.exists():
        return pd.DataFrame()
    try:
        return pd.read_csv(path)
    except Exception:
        return pd.DataFrame()


def _normalize_status(value):
    status = str(value or "Inactive").strip()
    return "Active" if status.lower() == "active" else "Inactive"


def _parse_created_at(value):
    if pd.isna(value) or value == "":
        return ""
    text = str(value).strip()
    try:
        parsed = pd.to_datetime(text, errors="raise")
        return parsed.strftime("%d %b %Y")
    except Exception:
        return text


def _get_owner_lookup():
    users = _safe_read_csv(USER_FILE)
    lookup = {}
    if users.empty:
        return lookup
    for _, row in users.iterrows():
        user_id = str(row.get("user_id", "")).strip()
        if user_id:
            lookup[user_id] = row.to_dict()
    return lookup


def _canonical_cafe_row(row, owner_lookup):
    cafe_id = str(row.get("cafe_id", "")).strip()
    owner_id = str(row.get("owner_id", "")).strip()
    owner = owner_lookup.get(owner_id, {})
    setup_status = get_setup_status(cafe_id)
    progress = int(setup_status.get("setup_progress", 0) or 0)
    status = _normalize_status(row.get("status", "Inactive"))
    return {
        "cafe_id": cafe_id,
        "cafe_name": str(row.get("cafe_name", "")).strip() or "Unnamed Café",
        "owner_id": owner_id,
        "owner_name": str(owner.get("name", "Unknown Owner")).strip() or "Unknown Owner",
        "owner_email": str(owner.get("email", "")).strip(),
        "location": str(row.get("location", "")).strip(),
        "phone": str(row.get("phone", "")).strip(),
        "status": status,
        "created_at": _parse_created_at(row.get("created_at", "")),
        "setup_progress": progress,
        "setup_label": "Setup complete" if progress >= 100 else "Setup incomplete",
        "setup_status": "Complete" if progress >= 100 else "Incomplete",
        "needs_attention": status == "Inactive" or progress < 100,
    }


def get_cafe_account_summary():
    """Return platform-level café counts using actual stored data."""
    cafes = _safe_read_csv(CAFE_FILE)
    if cafes.empty:
        return {
            "total_cafes": 0,
            "active": 0,
            "inactive": 0,
            "setup_incomplete": 0,
        }

    total = len(cafes)
    active = int((cafes["status"].astype(str).str.lower() == "active").sum()) if "status" in cafes.columns else 0
    inactive = total - active
    setup_incomplete = 0
    for _, row in cafes.iterrows():
        cafe_id = str(row.get("cafe_id", "")).strip()
        progress = int(get_setup_status(cafe_id).get("setup_progress", 0) or 0)
        if progress < 100:
            setup_incomplete += 1

    return {
        "total_cafes": total,
        "active": active,
        "inactive": inactive,
        "setup_incomplete": setup_incomplete,
    }


def list_cafe_accounts(search="", status_filter="All", setup_filter="All", sort_order="Newest"):
    """Return a list of platform café records ready for the admin UI."""
    cafes = _safe_read_csv(CAFE_FILE)
    if cafes.empty:
        return []

    owner_lookup = _get_owner_lookup()
    rows = []
    for _, row in cafes.iterrows():
        cafe_id = str(row.get("cafe_id", "")).strip()
        if not cafe_id:
            continue
        normalized = _canonical_cafe_row(row, owner_lookup)
        rows.append(normalized)

    if search:
        query = search.lower()
        rows = [
            row for row in rows
            if query in row["cafe_name"].lower()
            or query in row["owner_name"].lower()
            or query in row["owner_email"].lower()
            or query in row["cafe_id"].lower()
        ]

    if status_filter != "All":
        rows = [row for row in rows if row["status"] == status_filter]

    if setup_filter != "All":
        if setup_filter == "Complete":
            rows = [row for row in rows if row["setup_progress"] >= 100]
        else:
            rows = [row for row in rows if row["setup_progress"] < 100]

    def created_sort_key(item):
        value = item.get("created_at", "")
        try:
            return datetime.strptime(value, "%d %b %Y")
        except ValueError:
            return datetime.min

    if sort_order == "Oldest":
        rows.sort(key=lambda item: created_sort_key(item))
    elif sort_order == "Name A-Z":
        rows.sort(key=lambda item: item["cafe_name"].lower())
    elif sort_order == "Name Z-A":
        rows.sort(key=lambda item: item["cafe_name"].lower(), reverse=True)
    else:
        rows.sort(key=lambda item: created_sort_key(item), reverse=True)

    return rows


def get_cafe_account_detail(cafe_id):
    """Return the full platform detail payload for a single café."""
    cafes = _safe_read_csv(CAFE_FILE)
    if cafes.empty:
        return None
    match = cafes[cafes["cafe_id"].astype(str) == str(cafe_id)]
    if match.empty:
        return None

    owner_lookup = _get_owner_lookup()
    row = match.iloc[0]
    normalized = _canonical_cafe_row(row, owner_lookup)
    setup = get_setup_status(cafe_id)
    status_text = "Setup complete" if setup.get("setup_progress", 0) >= 100 else "Setup incomplete"
    return {
        **normalized,
        "setup": setup,
        "setup_text": status_text,
        "profile_complete": setup.get("profile_complete", False),
        "menu_complete": setup.get("menu_complete", False),
        "ingredients_complete": setup.get("ingredients_complete", False),
        "recipes_complete": setup.get("recipes_complete", False),
        "opening_stock_complete": setup.get("opening_stock_complete", False),
        "suppliers_complete": setup.get("suppliers_complete", False),
    }


def update_cafe_account_status(cafe_id, status):
    """Persist a café status change while preserving all other data."""
    cafes = _safe_read_csv(CAFE_FILE)
    if cafes.empty:
        return False

    mask = cafes["cafe_id"].astype(str) == str(cafe_id)
    if not mask.any():
        return False

    target = "Active" if str(status).strip().lower() == "active" else "Inactive"
    cafes.loc[mask, "status"] = target
    cafes.to_csv(CAFE_FILE, index=False)
    return True


def log_platform_activity(message, actor_id=None, actor_name="Platform Admin", category="platform_admin"):
    """Record an admin action in the simple CSV audit log.

    This function remains backwards-compatible with the older platform_activity CSV
    format while the new structured audit service handles the canonical schema.
    """
    _ensure_files()
    log_df = _safe_read_csv(ACTIVITY_FILE)
    new_row = {
        "timestamp": pd.Timestamp.now().strftime("%d %b %Y %H:%M"),
        "message": str(message).strip(),
        "actor_id": str(actor_id or ""),
        "actor_name": str(actor_name or "Platform Admin"),
        "category": str(category or "platform_admin"),
    }
    if set(["activity_id", "timestamp", "actor_id", "actor_name", "actor_role", "action", "target_type", "target_id", "target_name", "status", "details"]).issubset(log_df.columns):
        return True
    log_df = pd.concat([log_df, pd.DataFrame([new_row])], ignore_index=True)
    log_df.to_csv(ACTIVITY_FILE, index=False)
    return True


def deactivate_cafe_account(cafe_id, actor_id=None, actor_name="Platform Admin"):
    """Deactivate a café account without deleting any data."""
    detail = get_cafe_account_detail(cafe_id)
    if detail is None:
        return {"success": False, "message": "Café account not found."}

    if not update_cafe_account_status(cafe_id, "Inactive"):
        return {"success": False, "message": "Unable to deactivate this café account."}

    log_platform_activity(
        f"Platform Admin deactivated café {detail['cafe_id']} ({detail['cafe_name']}).",
        actor_id=actor_id,
        actor_name=actor_name,
        category="account_status",
    )
    return {"success": True, "message": "Café account deactivated successfully."}


def reactivate_cafe_account(cafe_id, actor_id=None, actor_name="Platform Admin"):
    """Reactivate an inactive café account without altering persisted data."""
    detail = get_cafe_account_detail(cafe_id)
    if detail is None:
        return {"success": False, "message": "Café account not found."}

    if not update_cafe_account_status(cafe_id, "Active"):
        return {"success": False, "message": "Unable to reactivate this café account."}

    log_platform_activity(
        f"Platform Admin reactivated café {detail['cafe_id']} ({detail['cafe_name']}).",
        actor_id=actor_id,
        actor_name=actor_name,
        category="account_status",
    )
    return {"success": True, "message": "Café account reactivated successfully."}


def can_access_cafe_accounts(role):
    """Return whether the current user may manage the platform café accounts."""
    return str(role or "").strip().lower() == "platform_admin"
