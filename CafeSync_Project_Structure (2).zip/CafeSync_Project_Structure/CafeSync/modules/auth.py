"""Authentication and registration logic for platform admin and café owners.

This module keeps the registration and login rules simple and CSV-based so the
project remains file-driven and compatible with the academic prototype.
"""

from __future__ import annotations

import re
from pathlib import Path

import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
USER_FILE = DATA_DIR / "users.csv"
CAFE_FILE = DATA_DIR / "cafes.csv"


def _is_valid_email(value):
    """Return True when a value matches a basic email pattern."""
    if value is None:
        return False
    return bool(re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", str(value).strip()))


def _is_valid_phone(value):
    """Return True for a plausible mobile/landline number."""
    if value is None:
        return False
    digits = re.sub(r"\D", "", str(value).strip())
    return 10 <= len(digits) <= 15


def ensure_user_file():
    """Create the users.csv file if it is missing."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not USER_FILE.exists():
        pd.DataFrame(
            columns=[
                "user_id",
                "name",
                "email",
                "phone",
                "password",
                "role",
                "status",
                "created_at",
            ]
        ).to_csv(USER_FILE, index=False)


ensure_user_file()


def generate_user_id():
    """Generate a unique user ID in the format U###."""
    users = pd.read_csv(USER_FILE) if USER_FILE.exists() else pd.DataFrame()
    if users.empty:
        return "U001"

    numbers = []
    for value in users["user_id"].astype(str):
        if value.startswith("U") and value[1:].isdigit():
            numbers.append(int(value[1:]))

    next_number = max(numbers, default=0) + 1
    return f"U{next_number:03d}"


def get_user_by_email(email):
    """Fetch a user record by email address."""
    users = pd.read_csv(USER_FILE) if USER_FILE.exists() else pd.DataFrame()
    if users.empty:
        return None
    matches = users[users["email"].astype(str).str.lower() == str(email).strip().lower()]
    if matches.empty:
        return None
    return matches.iloc[0].to_dict()


def authenticate_user(email, password):
    """Authenticate a user using CSV-based records.

    Returns a dictionary if validated; otherwise None.
    """
    user = get_user_by_email(email)
    if user is None:
        return None

    if str(user.get("password", "")) != str(password):
        return None

    if str(user.get("status", "Inactive")).strip().lower() == "inactive":
        return {
            "user_id": user["user_id"],
            "name": user["name"],
            "role": user["role"],
            "status": "inactive",
        }

    return {
        "user_id": user["user_id"],
        "name": user["name"],
        "role": user["role"],
        "status": "active",
    }


def register_owner_account(owner_name, cafe_name, email, phone, password, location):
    """Create a café owner and an initial café linked to that owner."""
    users = pd.read_csv(USER_FILE) if USER_FILE.exists() else pd.DataFrame()
    if not owner_name or not cafe_name or not email or not phone or not password or not location:
        return {"success": False, "message": "All fields are required."}

    if not _is_valid_email(email):
        return {"success": False, "message": "Please enter a valid email address."}

    if not _is_valid_phone(phone):
        return {"success": False, "message": "Please enter a valid phone number."}

    if not get_user_by_email(email) is None:
        return {"success": False, "message": "An account with this email already exists."}

    user_id = generate_user_id()
    created_at = pd.Timestamp.now().strftime("%Y-%m-%d")

    user_record = {
        "user_id": user_id,
        "name": owner_name,
        "email": email,
        "phone": phone,
        "password": password,
        "role": "cafe_owner",
        "status": "Active",
        "created_at": created_at,
    }

    users = pd.concat([users, pd.DataFrame([user_record])], ignore_index=True)
    users.to_csv(USER_FILE, index=False)

    from modules.cafe_manager import create_cafe

    cafe_id = create_cafe(user_id, cafe_name, location, phone)

    return {
        "success": True,
        "user_id": user_id,
        "cafe_id": cafe_id,
        "message": "Account created successfully.",
    }


def create_demo_admin():
    """Create a demo platform admin account if it does not exist."""
    users = pd.read_csv(USER_FILE) if USER_FILE.exists() else pd.DataFrame()
    if users.empty or not any(str(email).lower() == "admin@cafesync.com" for email in users["email"].astype(str).str.lower()):
        admin_record = {
            "user_id": "U001",
            "name": "Platform Admin",
            "email": "admin@cafesync.com",
            "phone": "9999999999",
            "password": "admin123",
            "role": "platform_admin",
            "status": "Active",
            "created_at": pd.Timestamp.now().strftime("%Y-%m-%d"),
        }
        users = pd.concat([users, pd.DataFrame([admin_record])], ignore_index=True)
        users.to_csv(USER_FILE, index=False)


create_demo_admin()
