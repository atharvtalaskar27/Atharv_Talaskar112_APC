"""Entry point for the CaféSync desktop application."""

from modules.ui_components import CafeSyncApp


def main():
    app = CafeSyncApp()
    app.root.mainloop()


if __name__ == "__main__":
    main()
