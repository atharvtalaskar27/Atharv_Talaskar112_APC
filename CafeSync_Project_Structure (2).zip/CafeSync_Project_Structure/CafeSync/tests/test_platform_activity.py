import unittest

from modules.platform_activity import (
    get_platform_activity_summary,
    list_platform_activity,
    record_platform_activity,
)


class TestPlatformActivity(unittest.TestCase):
    def test_record_and_list_activity(self):
        record = record_platform_activity(
            actor_id="U001",
            actor_name="Platform Admin",
            actor_role="platform_admin",
            action="DEACTIVATE_CAFE",
            target_type="CAFE",
            target_id="CAFE-999",
            target_name="Sample Test Café",
            status="SUCCESS",
            details="Café account deactivated by Platform Admin.",
        )
        self.assertTrue(record["activity_id"].startswith("ACT-"))
        entries = list_platform_activity(search="Sample Test Café")
        self.assertTrue(any(item["target_name"] == "Sample Test Café" for item in entries))
        summary = get_platform_activity_summary()
        self.assertGreaterEqual(summary["total"], 1)


if __name__ == "__main__":
    unittest.main()
