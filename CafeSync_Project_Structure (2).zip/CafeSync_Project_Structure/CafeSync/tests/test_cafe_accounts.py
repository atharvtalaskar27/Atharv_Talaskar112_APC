import unittest

from modules.cafe_accounts import get_cafe_account_summary, list_cafe_accounts


class TestCafeAccounts(unittest.TestCase):
    def test_summary_and_search(self):
        summary = get_cafe_account_summary()
        self.assertIn("total_cafes", summary)
        self.assertGreaterEqual(summary["total_cafes"], 1)

        rows = list_cafe_accounts(search="Kolhapur")
        self.assertTrue(any(row["cafe_name"].lower().startswith("kolhapur") for row in rows))


if __name__ == "__main__":
    unittest.main()
