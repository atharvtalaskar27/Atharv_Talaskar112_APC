import pandas as pd
import unittest

from modules import cafe_owners
from modules import auth


class TestOwnerAccount(unittest.TestCase):
    def setUp(self):
        self.temp_users = self._temp_path / "users.csv"
        self.temp_cafes = self._temp_path / "cafes.csv"
        self._seed_data()

    @property
    def _temp_path(self):
        import tempfile
        from pathlib import Path

        return Path(tempfile.mkdtemp())

    def _seed_data(self):
        users = pd.DataFrame([
            {"user_id": "U002", "name": "Owner A", "email": "ownera@test.com", "phone": "9999999999", "password": "1234", "role": "cafe_owner", "status": "Active", "created_at": "2026-09-17"},
            {"user_id": "U003", "name": "Owner B", "email": "ownerb@test.com", "phone": "8888888888", "password": "1234", "role": "cafe_owner", "status": "Active", "created_at": "2026-09-17"},
        ])
        cafes = pd.DataFrame([
            {"cafe_id": "C001", "owner_id": "U002", "cafe_name": "Kolhapur Coffee House", "location": "Kolhapur", "phone": "9999999999", "status": "Active", "created_at": "2026-09-17", "cafe_type": "", "opening_date": "", "opening_time": "", "closing_time": "", "setup_completed": True, "setup_progress": 100.0, "quick_start_completed": True, "quick_start_progress": 100.0, "optional_setup_progress": 0.0, "onboarding_dismissed": False, "feature_readiness": "{}"},
            {"cafe_id": "C002", "owner_id": "U003", "cafe_name": "Pune Brew Café", "location": "Pune", "phone": "8888888888", "status": "Active", "created_at": "2026-09-17", "cafe_type": "", "opening_date": "", "opening_time": "", "closing_time": "", "setup_completed": True, "setup_progress": 100.0, "quick_start_completed": True, "quick_start_progress": 100.0, "optional_setup_progress": 0.0, "onboarding_dismissed": False, "feature_readiness": "{}"},
        ])
        users.to_csv(self.temp_users, index=False)
        cafes.to_csv(self.temp_cafes, index=False)
        cafe_owners.USER_FILE = self.temp_users
        cafe_owners.CAFE_FILE = self.temp_cafes
        auth.USER_FILE = self.temp_users

    def test_load_and_persist_owner_profile_and_cafe(self):
        snapshot = cafe_owners.get_owner_account_snapshot(user_id="U002", cafe_id="C001")
        self.assertEqual(snapshot["owner_name"], "Owner A")
        self.assertEqual(snapshot["cafe_name"], "Kolhapur Coffee House")

        result = cafe_owners.update_owner_profile("U002", full_name="Owner A Updated", email="owner_a_updated@test.com", phone="7777777777")
        self.assertTrue(result["success"], result.get("message"))

        updated = cafe_owners.get_owner_account_snapshot("U002", "C001")
        self.assertEqual(updated["owner_name"], "Owner A Updated")
        self.assertEqual(updated["email"], "owner_a_updated@test.com")
        self.assertEqual(updated["phone"], "7777777777")

        cafe_result = cafe_owners.update_cafe_profile("U002", "C001", cafe_name="Updated Café", location="Satara", phone="7777777777")
        self.assertTrue(cafe_result["success"], cafe_result.get("message"))
        current_cafe = cafe_owners.get_owner_account_snapshot("U002", "C001")
        self.assertEqual(current_cafe["cafe_name"], "Updated Café")
        self.assertEqual(current_cafe["cafe_id"], "C001")

    def test_owner_cannot_change_role_or_other_cafe(self):
        failed_role = cafe_owners.update_owner_profile("U002", full_name="Changed", email="owner_a_role@test.com", role="platform_admin")
        self.assertFalse(failed_role["success"])

        duplicate_email = cafe_owners.update_owner_profile("U002", full_name="Changed", email="ownerb@test.com")
        self.assertFalse(duplicate_email["success"])

        cross_cafe = cafe_owners.update_cafe_profile("U002", "C002", cafe_name="Unauthorized change")
        self.assertFalse(cross_cafe["success"])


if __name__ == "__main__":
    unittest.main()
