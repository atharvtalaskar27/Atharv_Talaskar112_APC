import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import pandas as pd

from modules import inventory
from modules import orders


class TestInventoryManagement(unittest.TestCase):
    def test_add_update_and_stock_movement_flow(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            data_dir = Path(tmp_dir)
            inventory.DATA_DIR = data_dir
            inventory.INVENTORY_PATH = data_dir / "inventory.csv"
            inventory.MOVEMENTS_PATH = data_dir / "inventory_movements.csv"

            ingredient = inventory.add_ingredient(
                cafe_id="C101",
                name="Coffee Beans",
                unit="kg",
                minimum_stock=2,
                unit_cost=18.50,
            )
            self.assertTrue(ingredient["success"])
            self.assertEqual(ingredient["ingredient"]["current_stock"], 0)

            opening = inventory.record_stock_movement(
                cafe_id="C101",
                ingredient_id=ingredient["ingredient"]["ingredient_id"],
                movement_type="opening_stock",
                quantity=5,
                unit="kg",
                reason="Initial stock",
                actor_id="owner-1",
            )
            self.assertTrue(opening["success"])
            self.assertEqual(opening["ingredient"]["current_stock"], 5)

            increase = inventory.record_stock_movement(
                cafe_id="C101",
                ingredient_id=ingredient["ingredient"]["ingredient_id"],
                movement_type="manual_stock_increase",
                quantity=1.5,
                unit="kg",
                reason="Restock",
                actor_id="owner-1",
            )
            self.assertTrue(increase["success"])
            self.assertEqual(float(increase["ingredient"]["current_stock"]), 6.5)

            decrease = inventory.record_stock_movement(
                cafe_id="C101",
                ingredient_id=ingredient["ingredient"]["ingredient_id"],
                movement_type="manual_stock_decrease",
                quantity=2,
                unit="kg",
                reason="Usage",
                actor_id="owner-1",
            )
            self.assertTrue(decrease["success"])
            self.assertEqual(float(decrease["ingredient"]["current_stock"]), 4.5)

            status = inventory.get_stock_status(4.5, 2)
            self.assertEqual(status, "In stock")

            dashboard = inventory.get_inventory_dashboard("C101")
            self.assertEqual(dashboard["total_ingredients"], 1)
            self.assertEqual(dashboard["out_of_stock_ingredients"], 0)
            self.assertEqual(dashboard["low_stock_ingredients"], 0)
            self.assertGreater(dashboard["inventory_value"], 0)

    def test_reject_invalid_quantities_and_incompatible_units(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            data_dir = Path(tmp_dir)
            inventory.DATA_DIR = data_dir
            inventory.INVENTORY_PATH = data_dir / "inventory.csv"
            inventory.MOVEMENTS_PATH = data_dir / "inventory_movements.csv"

            ingredient = inventory.add_ingredient(
                cafe_id="C101",
                name="Milk",
                unit="litre",
                minimum_stock=3,
                unit_cost=80,
            )
            ingredient_id = ingredient["ingredient"]["ingredient_id"]

            invalid_qty = inventory.record_stock_movement(
                cafe_id="C101",
                ingredient_id=ingredient_id,
                movement_type="manual_stock_decrease",
                quantity=1,
                unit="litre",
                reason="Usage",
                actor_id="owner-1",
            )
            self.assertFalse(invalid_qty["success"])

            invalid_unit = inventory.record_stock_movement(
                cafe_id="C101",
                ingredient_id=ingredient_id,
                movement_type="manual_stock_increase",
                quantity=2,
                unit="pcs",
                reason="Restock",
                actor_id="owner-1",
            )
            self.assertFalse(invalid_unit["success"])

            missing_reason = inventory.record_stock_movement(
                cafe_id="C101",
                ingredient_id=ingredient_id,
                movement_type="manual_stock_increase",
                quantity=2,
                unit="litre",
                reason="",
                actor_id="owner-1",
            )
            self.assertFalse(missing_reason["success"])

    def test_tenant_isolation_and_persistence(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            data_dir = Path(tmp_dir)
            inventory.DATA_DIR = data_dir
            inventory.INVENTORY_PATH = data_dir / "inventory.csv"
            inventory.MOVEMENTS_PATH = data_dir / "inventory_movements.csv"

            first = inventory.add_ingredient("C101", "Coffee Beans", "kg", 2, 18.5)
            second = inventory.add_ingredient("C202", "Sugar", "kg", 1, 12.0)

            self.assertTrue(first["success"])
            self.assertTrue(second["success"])

            inventory.record_stock_movement(
                "C101",
                first["ingredient"]["ingredient_id"],
                "opening_stock",
                5,
                "kg",
                "Opening stock",
                "owner-1",
            )
            inventory.record_stock_movement(
                "C202",
                second["ingredient"]["ingredient_id"],
                "opening_stock",
                8,
                "kg",
                "Opening stock",
                "owner-2",
            )

            cafe_one = inventory.list_ingredients("C101")
            cafe_two = inventory.list_ingredients("C202")
            self.assertEqual(len(cafe_one), 1)
            self.assertEqual(len(cafe_two), 1)
            self.assertEqual(cafe_one[0]["name"], "Coffee Beans")
            self.assertEqual(cafe_two[0]["name"], "Sugar")

            dashboard_one = inventory.get_inventory_dashboard("C101")
            self.assertEqual(dashboard_one["total_ingredients"], 1)
            self.assertEqual(float(dashboard_one["inventory_value"]), 92.5)

            reloaded = inventory.list_ingredients("C101")
            self.assertEqual(len(reloaded), 1)

    def test_no_automatic_order_deduction(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            data_dir = Path(tmp_dir)
            inventory.DATA_DIR = data_dir
            inventory.INVENTORY_PATH = data_dir / "inventory.csv"
            inventory.MOVEMENTS_PATH = data_dir / "inventory_movements.csv"

            menu_data_dir = data_dir
            orders.DATA_DIR = data_dir
            orders.ORDERS_PATH = data_dir / "orders.csv"
            orders.ORDER_ITEMS_PATH = data_dir / "order_items.csv"

            from modules import menu

            menu.DATA_DIR = data_dir
            menu.MENU_PATH = data_dir / "menu.csv"
            menu.add_menu_item("C101", "Cappuccino", "Coffee", 120)
            created = orders.create_order("C101", [{"menu_item_id": "MI001", "quantity": 2}])
            self.assertTrue(created["success"])

            ingredient = inventory.add_ingredient("C101", "Coffee Beans", "kg", 2, 10)
            inventory.record_stock_movement("C101", ingredient["ingredient"]["ingredient_id"], "opening_stock", 10, "kg", "Opening", "owner-1")

            rows = inventory.list_ingredients("C101")
            self.assertEqual(len(rows), 1)
            self.assertEqual(float(rows[0]["current_stock"]), 10)


if __name__ == "__main__":
    unittest.main()
