import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import pandas as pd

from modules import setup_manager
from modules.ui_components import SetupWizardFrame


class TestOnboarding(unittest.TestCase):
    def test_setup_wizard_component_exists(self):
        self.assertTrue(callable(SetupWizardFrame))

    def test_quick_start_requires_only_profile_and_keeps_optional_progress_separate(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            data_dir = Path(tmp_dir)
            cafes = pd.DataFrame(
                [{
                    "cafe_id": "C100",
                    "owner_id": "U100",
                    "cafe_name": "Quick Start Café",
                    "location": "Pune",
                    "phone": "9999999999",
                    "status": "Active",
                    "created_at": "2026-10-16",
                    "setup_completed": False,
                    "setup_progress": 0,
                }]
            )
            cafes.to_csv(data_dir / "cafes.csv", index=False)
            for file_name, columns in setup_manager.CSV_FILES.items():
                pd.DataFrame(columns=columns).to_csv(data_dir / f"{file_name}.csv", index=False)

            with patch.object(setup_manager, "DATA_DIR", data_dir):
                status = setup_manager.get_setup_status("C100")

            self.assertTrue(status["quick_start_completed"])
            self.assertEqual(status["quick_start_progress"], 100)
            self.assertEqual(status["optional_setup_progress"], 0)
            self.assertEqual(status["setup_progress"], 100)

    def test_onboarding_state_is_tenant_isolated(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            data_dir = Path(tmp_dir)
            cafes = pd.DataFrame([
                {"cafe_id": "C101", "owner_id": "U101", "cafe_name": "Owned A", "location": "A", "phone": "9999999999", "status": "Active", "created_at": "2026-10-16", "setup_completed": False, "setup_progress": 0},
                {"cafe_id": "C102", "owner_id": "U102", "cafe_name": "", "location": "", "phone": "8888888888", "status": "Active", "created_at": "2026-10-16", "setup_completed": False, "setup_progress": 0},
            ])
            cafes.to_csv(data_dir / "cafes.csv", index=False)
            for file_name, columns in setup_manager.CSV_FILES.items():
                pd.DataFrame(columns=columns).to_csv(data_dir / f"{file_name}.csv", index=False)

            with patch.object(setup_manager, "DATA_DIR", data_dir):
                status_a = setup_manager.get_setup_status("C101")
                status_b = setup_manager.get_setup_status("C102")

            self.assertTrue(status_a["quick_start_completed"])
            self.assertFalse(status_b["quick_start_completed"])


if __name__ == "__main__":
    unittest.main()
