import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import pandas as pd

from modules import setup_manager


class TestCafeDataValidation(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.data_dir = Path(self.temp_dir.name)
        self.data_dir.mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_invalid_numeric_and_email_values_are_rejected(self):
        for file_name, columns in setup_manager.CSV_FILES.items():
            pd.DataFrame(columns=columns).to_csv(self.data_dir / f"{file_name}.csv", index=False)

        with patch.object(setup_manager, "DATA_DIR", self.data_dir):
            menu_result = setup_manager.save_menu_item("C001", "Latte", "Coffee", -10)
            ingredient_result = setup_manager.save_ingredient("C001", "Coffee Beans", "kg", -5)
            supplier_result = setup_manager.save_supplier("C001", "Acme Supplies", "9876543210", "bad-email", "Coffee")

            self.assertFalse(menu_result["success"], "Negative menu price should be rejected.")
            self.assertFalse(ingredient_result["success"], "Negative minimum stock should be rejected.")
            self.assertFalse(supplier_result["success"], "Invalid supplier email should be rejected.")


if __name__ == "__main__":
    unittest.main()
