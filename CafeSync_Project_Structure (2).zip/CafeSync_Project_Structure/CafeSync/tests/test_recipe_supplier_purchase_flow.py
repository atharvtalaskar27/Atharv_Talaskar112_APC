import tempfile
import unittest
from pathlib import Path

from modules import inventory, menu, purchases, recipes, suppliers


class TestRecipeSupplierPurchaseWorkflow(unittest.TestCase):
    def test_recipe_cost_and_tenant_isolation(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            data_dir = Path(tmp_dir)
            menu.DATA_DIR = data_dir
            menu.MENU_PATH = data_dir / "menu.csv"
            inventory.DATA_DIR = data_dir
            inventory.INVENTORY_PATH = data_dir / "inventory.csv"
            inventory.MOVEMENTS_PATH = data_dir / "inventory_movements.csv"
            recipes.DATA_DIR = data_dir
            recipes.RECIPES_PATH = data_dir / "recipes.csv"
            recipes.RECIPE_INGREDIENTS_PATH = data_dir / "recipe_ingredients.csv"

            menu.add_menu_item("C101", "Cappuccino", "Coffee", 220)
            inventory.add_ingredient("C101", "Coffee Beans", "kg", 2, 18.5)
            inventory.add_ingredient("C101", "Milk", "litre", 3, 60)
            inventory.add_ingredient("C202", "Milk", "litre", 1, 60)

            recipe = recipes.add_recipe(
                cafe_id="C101",
                menu_item_id="MI001",
                ingredient_lines=[
                    {"ingredient_name": "Coffee Beans", "quantity_required": 0.18, "unit": "kg"},
                    {"ingredient_name": "Milk", "quantity_required": 0.25, "unit": "litre"},
                ],
            )
            self.assertTrue(recipe["success"])
            estimate = recipes.estimate_recipe_cost("C101", recipe["recipe"]["recipe_id"])
            self.assertGreater(estimate["estimated_ingredient_cost"], 0)
            self.assertEqual(estimate["menu_item_id"], "MI001")

            bad_recipe = recipes.add_recipe(
                cafe_id="C101",
                menu_item_id="MI001",
                ingredient_lines=[
                    {"ingredient_name": "Milk", "quantity_required": 0.25, "unit": "litre"},
                    {"ingredient_name": "Milk", "quantity_required": 0.4, "unit": "litre"},
                ],
            )
            self.assertFalse(bad_recipe["success"])

    def test_supplier_directory_and_filtering(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            data_dir = Path(tmp_dir)
            suppliers.DATA_DIR = data_dir
            suppliers.SUPPLIERS_PATH = data_dir / "suppliers.csv"
            supplier = suppliers.add_supplier(
                cafe_id="C101",
                supplier_name="North Valley Dairy",
                contact_person="Asha",
                phone="9876543210",
                email="asha@example.com",
                address="22 Market Street",
                category="Dairy",
            )
            self.assertTrue(supplier["success"])
            listed = suppliers.list_suppliers("C101", search="North")
            self.assertEqual(len(listed), 1)

            duplicate = suppliers.add_supplier(
                cafe_id="C101",
                supplier_name="North Valley Dairy",
                contact_person="Asha",
                phone="9876543210",
                email="asha@example.com",
                address="22 Market Street",
                category="Dairy",
            )
            self.assertFalse(duplicate["success"])

    def test_purchase_receive_and_duplicate_receipt_guard(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            data_dir = Path(tmp_dir)
            menu.DATA_DIR = data_dir
            menu.MENU_PATH = data_dir / "menu.csv"
            inventory.DATA_DIR = data_dir
            inventory.INVENTORY_PATH = data_dir / "inventory.csv"
            inventory.MOVEMENTS_PATH = data_dir / "inventory_movements.csv"
            suppliers.DATA_DIR = data_dir
            suppliers.SUPPLIERS_PATH = data_dir / "suppliers.csv"
            purchases.DATA_DIR = data_dir
            purchases.PURCHASES_PATH = data_dir / "purchases.csv"
            purchases.PURCHASE_ITEMS_PATH = data_dir / "purchase_items.csv"

            inventory.add_ingredient("C101", "Coffee Beans", "kg", 2, 18.5)
            supplier = suppliers.add_supplier("C101", "Bean Supply Co", "Asha", "9876543210", "asha@example.com", "22 Market Street", "Coffee and beverages")
            self.assertTrue(supplier["success"])

            purchase = purchases.create_purchase(
                cafe_id="C101",
                supplier_id=supplier["supplier"]["supplier_id"],
                expected_date="2026-10-20",
                items=[
                    {"ingredient_name": "Coffee Beans", "ordered_quantity": 10, "unit": "kg", "unit_cost": 20},
                ],
                notes="Initial bean order",
            )
            self.assertTrue(purchase["success"])
            self.assertEqual(purchase["purchase"]["status"], "Draft")

            ordered = purchases.update_purchase_status("C101", purchase["purchase"]["purchase_id"], "Ordered")
            self.assertTrue(ordered["success"])

            receipt = purchases.record_receipt(
                cafe_id="C101",
                purchase_id=purchase["purchase"]["purchase_id"],
                received_items=[{"ingredient_name": "Coffee Beans", "quantity_received": 6, "unit": "kg"}],
                actor_id="owner-1",
            )
            self.assertTrue(receipt["success"])
            self.assertEqual(receipt["purchase"]["status"], "Partially Received")
            ingredient_after_partial = inventory.get_ingredient_by_id("C101", "I001")
            self.assertEqual(float(ingredient_after_partial["current_stock"]), 6)

            duplicate = purchases.record_receipt(
                cafe_id="C101",
                purchase_id=purchase["purchase"]["purchase_id"],
                received_items=[{"ingredient_name": "Coffee Beans", "quantity_received": 6, "unit": "kg"}],
                actor_id="owner-1",
            )
            self.assertFalse(duplicate["success"])

            final_receipt = purchases.record_receipt(
                cafe_id="C101",
                purchase_id=purchase["purchase"]["purchase_id"],
                received_items=[{"ingredient_name": "Coffee Beans", "quantity_received": 4, "unit": "kg"}],
                actor_id="owner-1",
            )
            self.assertTrue(final_receipt["success"])
            self.assertEqual(final_receipt["purchase"]["status"], "Received")
            ingredient_final = inventory.get_ingredient_by_id("C101", "I001")
            self.assertEqual(float(ingredient_final["current_stock"]), 10)

    def test_two_cafe_isolation(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            data_dir = Path(tmp_dir)
            suppliers.DATA_DIR = data_dir
            suppliers.SUPPLIERS_PATH = data_dir / "suppliers.csv"
            purchases.DATA_DIR = data_dir
            purchases.PURCHASES_PATH = data_dir / "purchases.csv"
            purchases.PURCHASE_ITEMS_PATH = data_dir / "purchase_items.csv"
            inventory.DATA_DIR = data_dir
            inventory.INVENTORY_PATH = data_dir / "inventory.csv"
            inventory.MOVEMENTS_PATH = data_dir / "inventory_movements.csv"

            inventory.add_ingredient("C101", "Coffee Beans", "kg", 2, 18.5)
            inventory.add_ingredient("C202", "Sugar", "kg", 1, 10)
            s1 = suppliers.add_supplier("C101", "Bean Supply", "Asha", "9876543210", "asha@example.com", "22 Market Street", "Coffee and beverages")
            s2 = suppliers.add_supplier("C202", "Sugar Supply", "Ravi", "9898989898", "ravi@example.com", "92 East Road", "Bakery")
            self.assertTrue(s1["success"])
            self.assertTrue(s2["success"])

            purchase = purchases.create_purchase("C101", s1["supplier"]["supplier_id"], expected_date="2026-10-20", items=[{"ingredient_name": "Coffee Beans", "ordered_quantity": 5, "unit": "kg", "unit_cost": 20}])
            self.assertTrue(purchase["success"])
            other = purchases.list_purchases("C202")
            self.assertEqual(len(other), 0)


if __name__ == "__main__":
    unittest.main()
