import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import pandas as pd

from modules import menu as menu_module


class TestMenuManagement(unittest.TestCase):
    def test_add_list_edit_and_toggle_menu_items(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            data_dir = Path(tmp_dir)
            data_dir.mkdir(exist_ok=True)
            menu_path = data_dir / "menu.csv"
            pd.DataFrame(columns=[
                "item_id",
                "cafe_id",
                "item_name",
                "category",
                "description",
                "price",
                "selling_price",
                "is_available",
                "status",
                "created_at",
                "updated_at",
            ]).to_csv(menu_path, index=False)

            with patch.object(menu_module, "DATA_DIR", data_dir):
                created = menu_module.add_menu_item(
                    cafe_id="C101",
                    item_name="Cappuccino",
                    category="Coffee",
                    selling_price=120,
                    description="Classic espresso",
                )
                self.assertTrue(created["success"])

                second = menu_module.add_menu_item(
                    cafe_id="C101",
                    item_name="Cold Coffee",
                    category="Beverages",
                    selling_price=150,
                    description="Iced coffee",
                )
                self.assertTrue(second["success"])

                rows = menu_module.list_menu_items(cafe_id="C101", search="Cold", category="All", availability="All")
                self.assertEqual(len(rows), 1)
                self.assertEqual(rows[0]["item_name"], "Cold Coffee")

                item_id = created["item_id"]
                updated = menu_module.update_menu_item(
                    cafe_id="C101",
                    item_id=item_id,
                    item_name="Cappuccino Deluxe",
                    category="Coffee",
                    selling_price=135,
                    description="Espresso + foam",
                )
                self.assertTrue(updated["success"])
                self.assertEqual(updated["menu_item"]["item_name"], "Cappuccino Deluxe")

                toggled = menu_module.toggle_item_availability(cafe_id="C101", item_id=item_id)
                self.assertTrue(toggled["success"])
                self.assertFalse(toggled["menu_item"]["is_available"])

                invalid = menu_module.add_menu_item(
                    cafe_id="C101",
                    item_name="",
                    category="Coffee",
                    selling_price=10,
                )
                self.assertFalse(invalid["success"])

    def test_data_is_isolated_by_cafe(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            data_dir = Path(tmp_dir)
            menu_path = data_dir / "menu.csv"
            pd.DataFrame(columns=[
                "item_id",
                "cafe_id",
                "item_name",
                "category",
                "description",
                "price",
                "selling_price",
                "is_available",
                "status",
                "created_at",
                "updated_at",
            ]).to_csv(menu_path, index=False)

            with patch.object(menu_module, "DATA_DIR", data_dir):
                menu_module.add_menu_item("C101", "Cappuccino", "Coffee", 120)
                menu_module.add_menu_item("C202", "Tea", "Tea", 80)

                owned = menu_module.list_menu_items("C101")
                other = menu_module.list_menu_items("C202")

                self.assertEqual(len(owned), 1)
                self.assertEqual(len(other), 1)
                self.assertEqual(owned[0]["item_name"], "Cappuccino")
                self.assertEqual(other[0]["item_name"], "Tea")


if __name__ == "__main__":
    unittest.main()
