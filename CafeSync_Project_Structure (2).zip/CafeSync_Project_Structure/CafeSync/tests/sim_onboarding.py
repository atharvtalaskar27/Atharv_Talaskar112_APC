from modules.auth import register_owner_account
from modules.setup_manager import (
    get_setup_status,
    update_cafe_profile,
    save_menu_item,
    save_ingredient,
    save_recipe,
    update_opening_stock,
    save_supplier,
)

print('Registering owner and cafe...')
res = register_owner_account('Sim Owner', 'Sim Cafe', 'sim@example.com', '9999999999', 'simpass', 'Sim Location')
print('Registration result:', res)
cafe_id = res.get('cafe_id')

print('\nInitial status:')
print(get_setup_status(cafe_id))

print('\nUpdate profile (adds cafe_type optional)...')
update_cafe_profile(cafe_id, 'Sim Cafe', 'Sim Location', '9999999999', 'Coffee', '2026-09-17', '08:00', '20:00')
print(get_setup_status(cafe_id))

print('\nAdd menu item...')
save_menu_item(cafe_id, 'Espresso', 'Coffee', 120)
print(get_setup_status(cafe_id))

print('\nAdd ingredient...')
save_ingredient(cafe_id, 'Coffee Beans', 'kg', 1)
print(get_setup_status(cafe_id))

print('\nAdd recipe...')
menu = None
from modules.setup_manager import get_menu_for_cafe
menu = get_menu_for_cafe(cafe_id)
if not menu.empty:
    item_id = menu.iloc[0]['item_id']
    save_recipe(cafe_id, item_id, 'Coffee Beans', 0.02, 'kg')
print(get_setup_status(cafe_id))

print('\nSet opening stock...')
update_opening_stock(cafe_id, 'Coffee Beans', 5, 'kg')
print(get_setup_status(cafe_id))

print('\nAdd supplier...')
save_supplier(cafe_id, 'Local Beans', '8888888888', 'beans@local', 'Food')
print(get_setup_status(cafe_id))

print('\nFinal status:')
print(get_setup_status(cafe_id))
