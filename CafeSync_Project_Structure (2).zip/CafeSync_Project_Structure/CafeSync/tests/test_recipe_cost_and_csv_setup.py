import tempfile
import unittest
from pathlib import Path

from modules import inventory, menu, recipes, setup_manager


class TestRecipeCostRecursionAndCSVSetup(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.data_dir = Path(self.temp_dir.name)

        menu.DATA_DIR = self.data_dir
        menu.MENU_PATH = self.data_dir / "menu.csv"
        inventory.DATA_DIR = self.data_dir
        inventory.INVENTORY_PATH = self.data_dir / "inventory.csv"
        inventory.MOVEMENTS_PATH = self.data_dir / "inventory_movements.csv"
        recipes.DATA_DIR = self.data_dir
        recipes.RECIPES_PATH = self.data_dir / "recipes.csv"
        recipes.RECIPE_INGREDIENTS_PATH = self.data_dir / "recipe_ingredients.csv"
        setup_manager.DATA_DIR = self.data_dir

    def tearDown(self):
        self.temp_dir.cleanup()

    def _seed_recipe(self, cafe_id="C101"):
        menu.add_menu_item(cafe_id, "Cappuccino", "Coffee", 220)
        inventory.add_ingredient(cafe_id, "Coffee Beans", "kg", 2, 18.5)
        inventory.add_ingredient(cafe_id, "Milk", "litre", 3, 60)
        recipe = recipes.add_recipe(
            cafe_id=cafe_id,
            menu_item_id="MI001",
            ingredient_lines=[
                {"ingredient_name": "Coffee Beans", "quantity_required": 0.18, "unit": "kg"},
                {"ingredient_name": "Milk", "quantity_required": 0.25, "unit": "litre"},
            ],
        )
        self.assertTrue(recipe["success"])
        return recipe["recipe"]

    def test_get_recipe_by_id_does_not_calculate_cost(self):
        recipe = self._seed_recipe()
        fetched = recipes.get_recipe_by_id("C101", recipe["recipe_id"])
        self.assertIsNotNone(fetched)
        self.assertIsNone(fetched.get("estimated_ingredient_cost"))
        self.assertEqual(len(fetched["ingredients"]), 2)

    def test_estimate_recipe_cost_works_without_recursion(self):
        recipe = self._seed_recipe()
        estimate = recipes.estimate_recipe_cost("C101", recipe["recipe_id"])
        self.assertEqual(estimate["cost_status"], "Available")
        self.assertGreater(estimate["estimated_ingredient_cost"], 0)

    def test_list_recipes_handles_costs_without_recursive_reentry(self):
        self._seed_recipe()
        rows = recipes.list_recipes("C101")
        self.assertEqual(len(rows), 1)
        self.assertIsNone(rows[0].get("estimated_ingredient_cost"))

        priced = recipes.list_recipes("C101", include_costs=True)
        self.assertGreater(priced[0]["estimated_ingredient_cost"], 0)

    def test_dashboard_loading_for_empty_and_populated_cafe(self):
        empty = recipes.get_recipe_dashboard("C999")
        self.assertEqual(empty, {"total_recipes": 0, "complete_recipes": 0, "incomplete_recipes": 0})

        self._seed_recipe("C111")
        dashboard = recipes.get_recipe_dashboard("C111")
        self.assertEqual(dashboard["total_recipes"], 1)
        self.assertEqual(dashboard["complete_recipes"], 1)
        self.assertEqual(dashboard["incomplete_recipes"], 0)

    def test_missing_ingredient_cost_marked_unavailable(self):
        menu.add_menu_item("C102", "Latte", "Coffee", 180)
        inventory.add_ingredient("C102", "Milk", "litre", 1, "")
        recipe = recipes.add_recipe(
            cafe_id="C102",
            menu_item_id="MI001",
            ingredient_lines=[{"ingredient_name": "Milk", "quantity_required": 0.5, "unit": "litre"}],
        )
        self.assertTrue(recipe["success"])
        estimate = recipes.estimate_recipe_cost("C102", recipe["recipe"]["recipe_id"])
        self.assertIsNone(estimate["estimated_ingredient_cost"])
        self.assertEqual(estimate["cost_status"], "Cost unavailable")

    def test_incompatible_units_are_rejected_without_zero_cost(self):
        menu.add_menu_item("C103", "Tea", "Tea", 120)
        inventory.add_ingredient("C103", "Tea Leaves", "kg", 1, 40)
        recipe = recipes.add_recipe(
            cafe_id="C103",
            menu_item_id="MI001",
            ingredient_lines=[{"ingredient_name": "Tea Leaves", "quantity_required": 2, "unit": "kg"}],
        )
        self.assertTrue(recipe["success"])

        ingredient_df = recipes._read_recipe_ingredients_df()
        ingredient_df.loc[ingredient_df["recipe_id"] == recipe["recipe"]["recipe_id"], "unit"] = "pcs"
        recipes._atomic_write(ingredient_df, recipes.RECIPE_INGREDIENTS_PATH)

        estimate = recipes.estimate_recipe_cost("C103", recipe["recipe"]["recipe_id"])
        self.assertIsNone(estimate["estimated_ingredient_cost"])
        self.assertEqual(estimate["cost_status"], "Cost unavailable")

    def test_ensure_file_columns_backs_up_malformed_csv(self):
        malformed_path = self.data_dir / "recipes.csv"
        malformed_path.write_text("this is not a real csv file\n", encoding="utf-8")

        frame = setup_manager.ensure_file_columns("recipes.csv", ["recipe_id", "cafe_id", "menu_item_id"])
        self.assertListEqual(list(frame.columns), ["recipe_id", "cafe_id", "menu_item_id"])
        backup_matches = list(self.data_dir.glob("recipes.csv*.bak")) + list(self.data_dir.glob("recipes.csv.*.bak"))
        self.assertTrue(backup_matches)


if __name__ == "__main__":
    unittest.main()
