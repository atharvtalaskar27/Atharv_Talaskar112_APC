import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import pandas as pd

from modules import menu
from modules import orders


class TestOrdersManagement(unittest.TestCase):
    def test_create_order_and_summary(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            data_dir = Path(tmp_dir)
            data_dir.mkdir(exist_ok=True)

            menu.DATA_DIR = data_dir
            menu.MENU_PATH = data_dir / "menu.csv"
            orders.DATA_DIR = data_dir
            orders.ORDERS_PATH = data_dir / "orders.csv"
            orders.ORDER_ITEMS_PATH = data_dir / "order_items.csv"

            menu.add_menu_item("C101", "Cappuccino", "Coffee", 120, "Warm cappuccino")
            menu.add_menu_item("C101", "Cold Coffee", "Beverages", 150, "Iced coffee")

            result = orders.create_order(
                cafe_id="C101",
                items=[
                    {"menu_item_id": "MI001", "quantity": 2},
                    {"menu_item_id": "MI002", "quantity": 1},
                ],
            )
            self.assertTrue(result["success"])
            self.assertEqual(result["order"]["total_amount"], 390)
            self.assertEqual(result["order"]["item_count"], 3)

            summary = orders.get_order_summary("C101")
            self.assertEqual(summary["total_orders"], 1)
            self.assertEqual(summary["today_orders"], 1)
            self.assertEqual(summary["today_sales"], 390)
            self.assertEqual(summary["average_order_value"], 390)

    def test_reject_invalid_order_and_cancel(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            data_dir = Path(tmp_dir)
            menu.DATA_DIR = data_dir
            menu.MENU_PATH = data_dir / "menu.csv"
            orders.DATA_DIR = data_dir
            orders.ORDERS_PATH = data_dir / "orders.csv"
            orders.ORDER_ITEMS_PATH = data_dir / "order_items.csv"

            menu.add_menu_item("C101", "Cappuccino", "Coffee", 120)
            invalid = orders.create_order(cafe_id="C101", items=[{"menu_item_id": "MI001", "quantity": 0}])
            self.assertFalse(invalid["success"])

            created = orders.create_order(cafe_id="C101", items=[{"menu_item_id": "MI001", "quantity": 1}])
            cancelled = orders.cancel_order(cafe_id="C101", order_id=created["order"]["order_id"])
            self.assertTrue(cancelled["success"])
            self.assertEqual(cancelled["order"]["order_status"], "Cancelled")

            summary = orders.get_order_summary("C101")
            self.assertEqual(summary["total_orders"], 1)
            self.assertEqual(summary["today_sales"], 0)

    def test_tenant_isolation(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            data_dir = Path(tmp_dir)
            menu.DATA_DIR = data_dir
            menu.MENU_PATH = data_dir / "menu.csv"
            orders.DATA_DIR = data_dir
            orders.ORDERS_PATH = data_dir / "orders.csv"
            orders.ORDER_ITEMS_PATH = data_dir / "order_items.csv"

            menu.add_menu_item("C101", "Latte", "Coffee", 110)
            menu.add_menu_item("C202", "Mocha", "Coffee", 130)

            orders.create_order(cafe_id="C101", items=[{"menu_item_id": "MI001", "quantity": 2}])
            orders.create_order(cafe_id="C202", items=[{"menu_item_id": "MI002", "quantity": 1}])

            cafe_one_orders = orders.list_orders(cafe_id="C101")
            cafe_two_orders = orders.list_orders(cafe_id="C202")

            self.assertEqual(len(cafe_one_orders), 1)
            self.assertEqual(len(cafe_two_orders), 1)
            self.assertEqual(cafe_one_orders[0]["order_status"], "Completed")
            self.assertEqual(cafe_two_orders[0]["order_status"], "Completed")


if __name__ == "__main__":
    unittest.main()
