import tempfile
import unittest
from pathlib import Path

from modules import inventory, purchases, suppliers


class TestSupplierPurchaseRules(unittest.TestCase):
    def test_supplier_allows_optional_contact_fields_and_reactivation(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            data_dir = Path(tmp_dir)
            suppliers.DATA_DIR = data_dir
            suppliers.SUPPLIERS_PATH = data_dir / "suppliers.csv"

            result = suppliers.add_supplier(
                cafe_id="C101",
                supplier_name="North Valley Dairy",
                contact_person="Asha",
                phone="",
                email="",
                address="22 Market Street",
                category="Dairy",
            )
            self.assertTrue(result["success"])

            deactivate = suppliers.deactivate_supplier("C101", result["supplier"]["supplier_id"])
            self.assertTrue(deactivate["success"])

            reactivate = suppliers.reactivate_supplier("C101", result["supplier"]["supplier_id"])
            self.assertTrue(reactivate["success"])
            self.assertTrue(reactivate["supplier"]["is_active"])

    def test_purchase_status_transitions_and_receipt_guard(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            data_dir = Path(tmp_dir)
            inventory.DATA_DIR = data_dir
            inventory.INVENTORY_PATH = data_dir / "inventory.csv"
            inventory.MOVEMENTS_PATH = data_dir / "inventory_movements.csv"
            suppliers.DATA_DIR = data_dir
            suppliers.SUPPLIERS_PATH = data_dir / "suppliers.csv"
            purchases.DATA_DIR = data_dir
            purchases.PURCHASES_PATH = data_dir / "purchases.csv"
            purchases.PURCHASE_ITEMS_PATH = data_dir / "purchase_items.csv"

            inventory.add_ingredient("C101", "Coffee Beans", "kg", 2, 18.5)
            supplier = suppliers.add_supplier(
                "C101",
                "Bean Supply Co",
                "Asha",
                "",
                "",
                "22 Market Street",
                "Coffee and beverages",
            )
            purchase = purchases.create_purchase(
                cafe_id="C101",
                supplier_id=supplier["supplier"]["supplier_id"],
                expected_date="2026-10-20",
                items=[{"ingredient_name": "Coffee Beans", "ordered_quantity": 10, "unit": "kg", "unit_cost": 20}],
            )
            self.assertTrue(purchase["success"])

            invalid = purchases.update_purchase_status("C101", purchase["purchase"]["purchase_id"], "Received")
            self.assertFalse(invalid["success"])

            ordered = purchases.update_purchase_status("C101", purchase["purchase"]["purchase_id"], "Ordered")
            self.assertTrue(ordered["success"])

            receipt = purchases.record_receipt(
                cafe_id="C101",
                purchase_id=purchase["purchase"]["purchase_id"],
                received_items=[{"ingredient_name": "Coffee Beans", "quantity_received": 5, "unit": "kg"}],
                actor_id="owner-1",
            )
            self.assertTrue(receipt["success"])

            cancelled = purchases.update_purchase_status("C101", purchase["purchase"]["purchase_id"], "Cancelled")
            self.assertFalse(cancelled["success"])


if __name__ == "__main__":
    unittest.main()
