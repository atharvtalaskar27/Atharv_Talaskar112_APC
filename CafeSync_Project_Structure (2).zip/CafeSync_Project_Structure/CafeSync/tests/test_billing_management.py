import tempfile
import unittest
from pathlib import Path

from modules import billing
from modules import menu
from modules import orders


class TestBillingManagement(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.data_dir = Path(self.temp_dir.name)

        menu.DATA_DIR = self.data_dir
        menu.MENU_PATH = self.data_dir / "menu.csv"
        orders.DATA_DIR = self.data_dir
        orders.ORDERS_PATH = self.data_dir / "orders.csv"
        orders.ORDER_ITEMS_PATH = self.data_dir / "order_items.csv"

        billing.DATA_DIR = self.data_dir
        billing.BILLS_PATH = self.data_dir / "bills.csv"
        billing.PAYMENTS_PATH = self.data_dir / "payments.csv"

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_generate_bill_and_payments(self):
        menu.add_menu_item("C101", "Cappuccino", "Coffee", 120, "Warm cappuccino")
        menu.add_menu_item("C101", "Cold Coffee", "Beverages", 150, "Iced coffee")
        created = orders.create_order("C101", [{"menu_item_id": "MI001", "quantity": 2}, {"menu_item_id": "MI002", "quantity": 1}])

        bill = billing.create_bill_from_order("C101", created["order"]["order_id"])
        self.assertTrue(bill["success"])
        self.assertEqual(bill["bill"]["total_amount"], 390.0)
        self.assertEqual(bill["bill"]["amount_paid"], 0.0)
        self.assertEqual(bill["bill"]["payment_status"], "Pending")

        paid = billing.record_payment("C101", bill["bill"]["bill_id"], 200, "Cash", reference="REF-100")
        self.assertTrue(paid["success"])
        self.assertEqual(paid["bill"]["amount_paid"], 200.0)
        self.assertEqual(paid["bill"]["balance_due"], 190.0)
        self.assertEqual(paid["bill"]["payment_status"], "Partially Paid")

        partial = billing.record_payment("C101", bill["bill"]["bill_id"], 190, "UPI", reference="REF-200")
        self.assertTrue(partial["success"])
        self.assertEqual(partial["bill"]["amount_paid"], 390.0)
        self.assertEqual(partial["bill"]["balance_due"], 0.0)
        self.assertEqual(partial["bill"]["payment_status"], "Paid")

    def test_reject_duplicate_bill_and_invalid_payment(self):
        menu.add_menu_item("C101", "Cappuccino", "Coffee", 120)
        created = orders.create_order("C101", [{"menu_item_id": "MI001", "quantity": 1}])

        first = billing.create_bill_from_order("C101", created["order"]["order_id"])
        second = billing.create_bill_from_order("C101", created["order"]["order_id"])
        self.assertTrue(first["success"])
        self.assertFalse(second["success"])

        bad = billing.record_payment("C101", first["bill"]["bill_id"], 0, "Cash")
        self.assertFalse(bad["success"])

        over = billing.record_payment("C101", first["bill"]["bill_id"], 500, "Card")
        self.assertFalse(over["success"])

    def test_tenant_isolation_and_cancelled_order_rejection(self):
        menu.add_menu_item("C101", "Latte", "Coffee", 110)
        menu.add_menu_item("C202", "Mocha", "Coffee", 130)

        first = orders.create_order("C101", [{"menu_item_id": "MI001", "quantity": 2}])
        second = orders.create_order("C202", [{"menu_item_id": "MI002", "quantity": 1}])

        bill_one = billing.create_bill_from_order("C101", first["order"]["order_id"])
        bill_two = billing.create_bill_from_order("C202", second["order"]["order_id"])
        self.assertTrue(bill_one["success"])
        self.assertTrue(bill_two["success"])

        self.assertEqual(len(billing.list_bills("C101")), 1)
        self.assertEqual(len(billing.list_bills("C202")), 1)

        cancelled = orders.cancel_order("C101", first["order"]["order_id"])
        self.assertTrue(cancelled["success"])

        blocked = billing.create_bill_from_order("C101", first["order"]["order_id"])
        self.assertFalse(blocked["success"])


if __name__ == "__main__":
    unittest.main()
