import unittest

from modules.cafe_owners import can_access_cafe_owners, get_owner_summary, list_owner_accounts


class TestCafeOwners(unittest.TestCase):
    def test_owner_summary_and_search(self):
        summary = get_owner_summary()
        self.assertIn("total_owners", summary)
        self.assertGreaterEqual(summary["total_owners"], 1)

        owners = list_owner_accounts(search="Atharv")
        self.assertTrue(any(owner["name"].lower().startswith("atharv") for owner in owners))

    def test_platform_admin_access_gate(self):
        self.assertTrue(can_access_cafe_owners("platform_admin"))
        self.assertFalse(can_access_cafe_owners("cafe_owner"))


if __name__ == "__main__":
    unittest.main()
