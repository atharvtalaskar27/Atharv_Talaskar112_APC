import tempfile
import unittest
from pathlib import Path

from modules import inventory, waste


class TestWasteManagement(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.data_dir = Path(self.temp_dir.name)
        inventory.DATA_DIR = self.data_dir
        inventory.INVENTORY_PATH = self.data_dir / "inventory.csv"
        inventory.MOVEMENTS_PATH = self.data_dir / "inventory_movements.csv"
        waste.DATA_DIR = self.data_dir
        waste.WASTE_PATH = self.data_dir / "waste.csv"

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_record_waste_reduces_stock_and_tracks_cost(self):
        ingredient = inventory.add_ingredient("C101", "Milk", "litre", 2, 40)
        ingredient_id = ingredient["ingredient"]["ingredient_id"]
        inventory.record_stock_movement(
            "C101",
            ingredient_id,
            "opening_stock",
            10,
            "litre",
            "Opening stock",
            "owner-1",
        )

        result = waste.record_waste(
            cafe_id="C101",
            ingredient_id=ingredient_id,
            quantity=1.5,
            unit="litre",
            reason="Expired / Spoiled",
            occurred_at="2026-10-20 09:00:00",
            recorded_by="owner-1",
            notes="Milk expired before breakfast service.",
        )

        self.assertTrue(result["success"], result.get("message"))
        self.assertEqual(float(result["waste"]["estimated_total_cost"]), 60.0)
        self.assertEqual(result["movement"]["reference"], f"WASTE:{result['waste']['waste_id']}")
        self.assertEqual(result["waste"]["stock_movement_id"], result["movement"]["movement_id"])

        updated = inventory.get_ingredient_by_id("C101", ingredient_id)
        self.assertEqual(float(updated["current_stock"]), 8.5)

    def test_reject_invalid_waste_and_duplicate_submissions(self):
        ingredient = inventory.add_ingredient("C101", "Coffee Beans", "kg", 2, 18.5)
        ingredient_id = ingredient["ingredient"]["ingredient_id"]
        inventory.record_stock_movement(
            "C101",
            ingredient_id,
            "opening_stock",
            5,
            "kg",
            "Opening stock",
            "owner-1",
        )

        invalid = waste.record_waste(
            cafe_id="C101",
            ingredient_id=ingredient_id,
            quantity=0,
            unit="kg",
            reason="Over-prepared",
            recorded_by="owner-1",
        )
        self.assertFalse(invalid["success"])

        first = waste.record_waste(
            cafe_id="C101",
            ingredient_id=ingredient_id,
            quantity=1,
            unit="kg",
            reason="Over-prepared",
            occurred_at="2026-10-20 08:00:00",
            recorded_by="owner-1",
            operation_id="op-duplicate-1",
        )
        self.assertTrue(first["success"])

        second = waste.record_waste(
            cafe_id="C101",
            ingredient_id=ingredient_id,
            quantity=1,
            unit="kg",
            reason="Over-prepared",
            occurred_at="2026-10-20 08:00:00",
            recorded_by="owner-1",
            operation_id="op-duplicate-1",
        )
        self.assertFalse(second["success"])

        updated = inventory.get_ingredient_by_id("C101", ingredient_id)
        self.assertEqual(float(updated["current_stock"]), 4.0)


if __name__ == "__main__":
    unittest.main()
